const _0x4dd947 = _0x3609;
(function (_0x5c74e0, _0x1c9258) {
    const _0x24c414 = _0x3609, _0x34ec31 = _0x5c74e0();
    while (!![]) {
        try {
            const _0x522858 = -parseInt(_0x24c414(0x16c)) / (0x6a6 + 0x2219 + -0x28be) + parseInt(_0x24c414(0x16f)) / (0x200d + 0x224 + -0x222f) * (parseInt(_0x24c414(0x170)) / (0x7 * 0x2bd + -0x23 * -0x4b + 0x1d69 * -0x1)) + parseInt(_0x24c414(0x16a)) / (0x1bf * 0x6 + 0x131c * 0x2 + -0x1f * 0x192) + -parseInt(_0x24c414(0x14b)) / (-0xd0a * 0x1 + -0x6b * -0x55 + -0x1678) + parseInt(_0x24c414(0x15d)) / (0x269c + 0x8e * -0x11 + -0x1d28) + -parseInt(_0x24c414(0x149)) / (0x1 * 0xd75 + -0x1ed * -0x12 + 0x156 * -0x24) * (parseInt(_0x24c414(0x14e)) / (-0xc1e + 0x9f0 + 0x236)) + parseInt(_0x24c414(0x160)) / (0x1d63 + 0xab7 + -0x2811);
            if (_0x522858 === _0x1c9258)
                break;
            else
                _0x34ec31['push'](_0x34ec31['shift']());
        } catch (_0x18bf66) {
            _0x34ec31['push'](_0x34ec31['shift']());
        }
    }
}(_0x42aa, 0x5d6a * -0x3 + 0x1 * 0xcd86 + 0x53df3));
function _0x3609(_0x2199e9, _0x33b740) {
    _0x2199e9 = _0x2199e9 - (0x8a4 + -0x5 * -0x290 + 0x1 * -0x1442);
    const _0x531004 = _0x42aa();
    let _0x2ac072 = _0x531004[_0x2199e9];
    return _0x2ac072;
}
const crypto = require(_0x4dd947(0x150)), License = require(_0x4dd947(0x174) + _0x4dd947(0x13a)), KeyManager = require(_0x4dd947(0x132) + _0x4dd947(0x157) + 'r');
function _0x42aa() {
    const _0x2b2883 = [
        '../config/',
        'MYvTR',
        'No\x20active\x20',
        'toString',
        'rification',
        'Key',
        'iMTyD',
        'ubUFB',
        'license',
        'DmvrR',
        'dQrfq',
        'verifyLice',
        'update',
        'sign',
        'licenseKey',
        'license\x20fo',
        'NLkrn',
        'zcQMO',
        '\x20Error:',
        'sha256',
        'Invalid\x20li',
        'und',
        'base64',
        '7Fzfsup',
        'message',
        '1396145ocKngH',
        'LTPGX',
        'ature',
        '599008GJqYLZ',
        'inactive',
        'crypto',
        'verify',
        'getPrivate',
        'from',
        'end',
        'exports',
        'THbAn',
        'key-manage',
        'utf8',
        'WDili',
        'saveLicens',
        'getPublicK',
        'createVeri',
        '1437834RvXNbD',
        'create',
        'nseData',
        '1254528SDaBQd',
        'createSign',
        'pired',
        'OBGHL',
        'stringify',
        'parse',
        'signLicens',
        'fLdSp',
        'checkActiv',
        'License\x20ex',
        '2301788KfLlNK',
        'expiresAt',
        '426692zPFEES',
        'cense\x20sign',
        'License\x20Ve',
        '20uflmYP',
        '45219dbtsgf',
        'error',
        'eLicense',
        'tLurF',
        '../models/',
        'findOne',
        'active'
    ];
    _0x42aa = function () {
        return _0x2b2883;
    };
    return _0x42aa();
}
class LicenseService {
    static [_0x4dd947(0x15b) + 'ey']() {
        const _0x12227a = _0x4dd947;
        return KeyManager[_0x12227a(0x15b) + 'ey']();
    }
    static [_0x4dd947(0x152) + _0x4dd947(0x137)]() {
        const _0x2a416a = _0x4dd947;
        return KeyManager[_0x2a416a(0x152) + _0x2a416a(0x137)]();
    }
    static [_0x4dd947(0x13d) + _0x4dd947(0x15f)](_0x268e97) {
        const _0x3b3ec2 = _0x4dd947, _0x5a2146 = {
                'WDili': _0x3b3ec2(0x148),
                'MYvTR': _0x3b3ec2(0x158),
                'NLkrn': _0x3b3ec2(0x145),
                'iMTyD': _0x3b3ec2(0x146) + _0x3b3ec2(0x16d) + _0x3b3ec2(0x14d),
                'LTPGX': function (_0x3463b4, _0xf21d9a) {
                    return _0x3463b4 < _0xf21d9a;
                },
                'DmvrR': _0x3b3ec2(0x169) + _0x3b3ec2(0x162),
                'tLurF': _0x3b3ec2(0x16e) + _0x3b3ec2(0x136) + _0x3b3ec2(0x144)
            };
        try {
            const _0x565586 = this[_0x3b3ec2(0x15b) + 'ey'](), _0x554a31 = JSON[_0x3b3ec2(0x165)](Buffer[_0x3b3ec2(0x153)](_0x268e97, _0x5a2146[_0x3b3ec2(0x159)])[_0x3b3ec2(0x135)](_0x5a2146[_0x3b3ec2(0x133)])), {
                    data: _0x454043,
                    signature: _0x2bd34a
                } = _0x554a31, _0xaedbd = crypto[_0x3b3ec2(0x15c) + 'fy'](_0x5a2146[_0x3b3ec2(0x142)]);
            _0xaedbd[_0x3b3ec2(0x13e)](JSON[_0x3b3ec2(0x164)](_0x454043)), _0xaedbd[_0x3b3ec2(0x154)]();
            const _0x25d217 = _0xaedbd[_0x3b3ec2(0x151)](_0x565586, _0x2bd34a, _0x5a2146[_0x3b3ec2(0x159)]);
            if (!_0x25d217)
                throw new Error(_0x5a2146[_0x3b3ec2(0x138)]);
            const _0x3cf73b = new Date(_0x454043[_0x3b3ec2(0x16b)]);
            if (_0x5a2146[_0x3b3ec2(0x14c)](_0x3cf73b, new Date()))
                throw new Error(_0x5a2146[_0x3b3ec2(0x13b)]);
            return {
                'isValid': !![],
                'expiresAt': _0x3cf73b,
                'data': _0x454043
            };
        } catch (_0x4ce2f3) {
            return console[_0x3b3ec2(0x171)](_0x5a2146[_0x3b3ec2(0x173)], _0x4ce2f3[_0x3b3ec2(0x14a)]), {
                'isValid': ![],
                'error': _0x4ce2f3[_0x3b3ec2(0x14a)]
            };
        }
    }
    static [_0x4dd947(0x166) + 'e'](_0x46905c) {
        const _0x221ebd = _0x4dd947, _0x867913 = {
                'fLdSp': _0x221ebd(0x145),
                'dQrfq': _0x221ebd(0x148)
            }, _0x58025a = this[_0x221ebd(0x152) + _0x221ebd(0x137)](), _0x533d1d = crypto[_0x221ebd(0x161)](_0x867913[_0x221ebd(0x167)]);
        _0x533d1d[_0x221ebd(0x13e)](JSON[_0x221ebd(0x164)](_0x46905c)), _0x533d1d[_0x221ebd(0x154)]();
        const _0x49adce = _0x533d1d[_0x221ebd(0x13f)](_0x58025a, _0x867913[_0x221ebd(0x13c)]);
        return Buffer[_0x221ebd(0x153)](JSON[_0x221ebd(0x164)]({
            'data': _0x46905c,
            'signature': _0x49adce
        }))[_0x221ebd(0x135)](_0x867913[_0x221ebd(0x13c)]);
    }
    static async [_0x4dd947(0x15a) + 'e'](_0x547490, _0x1cf46b) {
        const _0x26cf13 = _0x4dd947, _0x3995ea = {
                'OBGHL': _0x26cf13(0x14f),
                'THbAn': _0x26cf13(0x176)
            };
        return await License[_0x26cf13(0x13e)]({ 'status': _0x3995ea[_0x26cf13(0x163)] }, { 'where': { 'status': _0x3995ea[_0x26cf13(0x156)] } }), await License[_0x26cf13(0x15e)]({
            'licenseKey': _0x547490,
            'expiresAt': _0x1cf46b,
            'status': _0x3995ea[_0x26cf13(0x156)]
        });
    }
    static async [_0x4dd947(0x168) + _0x4dd947(0x172)]() {
        const _0x292591 = _0x4dd947, _0x362692 = {
                'ubUFB': _0x292591(0x176),
                'zcQMO': _0x292591(0x134) + _0x292591(0x141) + _0x292591(0x147)
            }, _0x14970c = await License[_0x292591(0x175)]({ 'where': { 'status': _0x362692[_0x292591(0x139)] } });
        if (!_0x14970c)
            return {
                'isValid': ![],
                'error': _0x362692[_0x292591(0x143)]
            };
        return this[_0x292591(0x13d) + _0x292591(0x15f)](_0x14970c[_0x292591(0x140)]);
    }
}
module[_0x4dd947(0x155)] = LicenseService;