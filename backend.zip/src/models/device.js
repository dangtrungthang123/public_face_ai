function _0x173b(_0x40ba9e, _0x197524) {
    _0x40ba9e = _0x40ba9e - (-0x5e * 0x4f + -0x44 * 0x13 + 0x2381);
    const _0x377830 = _0x37f6();
    let _0x21ce5e = _0x377830[_0x40ba9e];
    return _0x21ce5e;
}
function _0x37f6() {
    const _0x17269c = [
        'New\x20Device',
        '7695NtFohw',
        'NOW',
        '3317010hIImhA',
        'offline',
        'DATE',
        'ENUM',
        'online',
        'database',
        '9650LyoacZ',
        '1897629XwSYKo',
        'STRING',
        'Device',
        'sequelize',
        'devices',
        'exports',
        '1536442LiXEQv',
        '44303RziOMm',
        'define',
        '195NCXrqj',
        '648nWlOBB',
        '1yPNrPm',
        '1806013yHLtDE',
        '../config/',
        '76368IDefGS'
    ];
    _0x37f6 = function () {
        return _0x17269c;
    };
    return _0x37f6();
}
const _0x1cfcf9 = _0x173b;
(function (_0x26fa49, _0x5f10bd) {
    const _0x33e163 = _0x173b, _0x10c48b = _0x26fa49();
    while (!![]) {
        try {
            const _0x4b9d9f = parseInt(_0x33e163(0x184)) / (-0x23e + -0x13d9 + -0x2c3 * -0x8) * (parseInt(_0x33e163(0x17f)) / (-0xb * 0x263 + 0x1 * -0x1e01 + 0x3844)) + parseInt(_0x33e163(0x179)) / (0x1d5c + 0x8 * -0x384 + -0x139) + -parseInt(_0x33e163(0x187)) / (-0xa5e + 0x4 * 0x8bf + -0xc4d * 0x2) * (-parseInt(_0x33e163(0x182)) / (0x18e2 + -0x3 * 0xa66 + 0x1 * 0x655)) + -parseInt(_0x33e163(0x18b)) / (0x1ebd + 0x9 * -0x1e9 + -0xd86) + parseInt(_0x33e163(0x180)) / (0x11fe + 0x9d * -0x2a + 0x11d * 0x7) * (-parseInt(_0x33e163(0x183)) / (0x289 + -0x11f1 * -0x1 + -0x2 * 0xa39)) + -parseInt(_0x33e163(0x189)) / (0x2563 + 0x19a3 * -0x1 + 0xbb7 * -0x1) * (parseInt(_0x33e163(0x178)) / (-0x22f6 + -0x19aa + 0x3caa)) + parseInt(_0x33e163(0x185)) / (0x1db9 + 0x2 * 0x75b + 0x2c64 * -0x1);
            if (_0x4b9d9f === _0x5f10bd)
                break;
            else
                _0x10c48b['push'](_0x10c48b['shift']());
        } catch (_0x23afe1) {
            _0x10c48b['push'](_0x10c48b['shift']());
        }
    }
}(_0x37f6, -0xb4609 + 0x6ec1 + 0x113be8));
const {DataTypes} = require(_0x1cfcf9(0x17c)), sequelize = require(_0x1cfcf9(0x186) + _0x1cfcf9(0x177)), Device = sequelize[_0x1cfcf9(0x181)](_0x1cfcf9(0x17b), {
        'sn': {
            'type': DataTypes[_0x1cfcf9(0x17a)],
            'primaryKey': !![],
            'allowNull': ![]
        },
        'name': {
            'type': DataTypes[_0x1cfcf9(0x17a)],
            'defaultValue': _0x1cfcf9(0x188)
        },
        'status': {
            'type': DataTypes[_0x1cfcf9(0x175)](_0x1cfcf9(0x176), _0x1cfcf9(0x173)),
            'defaultValue': _0x1cfcf9(0x173)
        },
        'last_seen': {
            'type': DataTypes[_0x1cfcf9(0x174)],
            'defaultValue': DataTypes[_0x1cfcf9(0x18a)]
        },
        'ip_address': {
            'type': DataTypes[_0x1cfcf9(0x17a)],
            'allowNull': !![]
        }
    }, {
        'tableName': _0x1cfcf9(0x17d),
        'timestamps': !![]
    });
module[_0x1cfcf9(0x17e)] = Device;