function _0x44be() {
    const _0x3e0323 = [
        'ding',
        'define',
        'UUID',
        'cessed',
        '5749112lxsiCz',
        'DATE',
        'exports',
        'NOW',
        'g,\x201\x20=\x20pro',
        'STRING',
        '693hOanJS',
        'SessionPen',
        'database',
        '0\x20=\x20pendin',
        '957530sYItFT',
        'dings',
        '6RHSfKI',
        'UUIDV4',
        '34prWneP',
        'sequelize',
        '10108tqarIz',
        '8561142IPxqty',
        '24466540LcTRbL',
        '../config/',
        'INTEGER',
        '4604915IxqkMA',
        '46560zbFQxS'
    ];
    _0x44be = function () {
        return _0x3e0323;
    };
    return _0x44be();
}
const _0x137e1f = _0x3c4d;
(function (_0x374842, _0x238ce9) {
    const _0x562418 = _0x3c4d, _0x30fd61 = _0x374842();
    while (!![]) {
        try {
            const _0x1568f4 = parseInt(_0x562418(0x135)) / (-0x9a + -0xdaf + -0x3b * -0x3e) * (parseInt(_0x562418(0x12d)) / (-0xd6 + -0x1faa + 0x1041 * 0x2)) + parseInt(_0x562418(0x125)) / (-0x2 * 0x20a + -0x18d3 + 0x1cea) * (-parseInt(_0x562418(0x12f)) / (0x12f2 + 0x1 * 0x143b + -0x2729)) + parseInt(_0x562418(0x129)) / (0xd2 * 0x8 + 0x12c4 + -0x1f * 0xd1) * (parseInt(_0x562418(0x12b)) / (-0x1a7b * 0x1 + 0x1729 + 0x358)) + -parseInt(_0x562418(0x134)) / (0x397 * 0x1 + 0x1fdf + -0x236f) + -parseInt(_0x562418(0x13a)) / (-0x97 * 0x25 + 0x1 * -0x55f + 0x1b3a) + -parseInt(_0x562418(0x130)) / (-0x1490 + -0x1 * -0x161d + -0x184) + parseInt(_0x562418(0x131)) / (0x4ac * -0x6 + 0x2 * -0x135c + 0xa6 * 0x67);
            if (_0x1568f4 === _0x238ce9)
                break;
            else
                _0x30fd61['push'](_0x30fd61['shift']());
        } catch (_0x38c84c) {
            _0x30fd61['push'](_0x30fd61['shift']());
        }
    }
}(_0x44be, 0x77b73 + -0xcc117 + 0xd2df1));
function _0x3c4d(_0x38a63b, _0xfa405d) {
    _0x38a63b = _0x38a63b - (0x1 * 0x1aad + 0xd38 + -0x26c5);
    const _0x32340c = _0x44be();
    let _0x5c759f = _0x32340c[_0x38a63b];
    return _0x5c759f;
}
const {DataTypes} = require(_0x137e1f(0x12e)), sequelize = require(_0x137e1f(0x132) + _0x137e1f(0x127)), SessionPending = sequelize[_0x137e1f(0x137)](_0x137e1f(0x126) + _0x137e1f(0x136), {
        'id': {
            'type': DataTypes[_0x137e1f(0x138)],
            'defaultValue': DataTypes[_0x137e1f(0x12c)],
            'primaryKey': !![]
        },
        'sn': {
            'type': DataTypes[_0x137e1f(0x124)],
            'allowNull': !![]
        },
        'sessionId': {
            'type': DataTypes[_0x137e1f(0x124)],
            'allowNull': ![]
        },
        'dateCreated': {
            'type': DataTypes[_0x137e1f(0x120)],
            'defaultValue': DataTypes[_0x137e1f(0x122)]
        },
        'status': {
            'type': DataTypes[_0x137e1f(0x133)],
            'defaultValue': 0x0,
            'comment': _0x137e1f(0x128) + _0x137e1f(0x123) + _0x137e1f(0x139)
        }
    }, {
        'tableName': _0x137e1f(0x126) + _0x137e1f(0x12a),
        'timestamps': !![]
    });
module[_0x137e1f(0x121)] = SessionPending;