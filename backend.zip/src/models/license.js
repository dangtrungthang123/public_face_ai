function _0x50c6() {
    const _0x1b146b = [
        '256693PJcnBm',
        'DATE',
        'UUIDV4',
        'TEXT',
        'active',
        '5908600Yvcwcp',
        'database',
        '969228KtiVmb',
        'define',
        'UUID',
        'sequelize',
        '72JYCEDQ',
        '../config/',
        'licenses',
        '1791369BvwuoM',
        'License',
        '1455HFuivo',
        'exports',
        '259899yJFXNW',
        '217658KyXTAp',
        '2QNWrIv',
        '1148jOKssd',
        'STRING'
    ];
    _0x50c6 = function () {
        return _0x1b146b;
    };
    return _0x50c6();
}
const _0x13f411 = _0x3d5e;
function _0x3d5e(_0x4a7165, _0x5f4d06) {
    _0x4a7165 = _0x4a7165 - (0x9 * -0x1f2 + -0x9 * -0x117 + 0x969);
    const _0x12e3a6 = _0x50c6();
    let _0x5a908a = _0x12e3a6[_0x4a7165];
    return _0x5a908a;
}
(function (_0x2ba06f, _0x76f455) {
    const _0x3d7ffe = _0x3d5e, _0x18c7d4 = _0x2ba06f();
    while (!![]) {
        try {
            const _0xca2ced = -parseInt(_0x3d7ffe(0x1b6)) / (-0x2403 + -0x475 + 0x2879 * 0x1) * (-parseInt(_0x3d7ffe(0x1ca)) / (0x1bb * -0x13 + -0x1 * -0x4cf + 0x1c14)) + parseInt(_0x3d7ffe(0x1c8)) / (0x2f * -0x12 + 0xf4 * -0x8 + 0xaf1) + -parseInt(_0x3d7ffe(0x1cb)) / (0x25d7 + 0x526 * 0x4 + 0x5 * -0xbaf) * (-parseInt(_0x3d7ffe(0x1c6)) / (0x2 * -0x38b + -0x3 * -0x529 + -0x860)) + -parseInt(_0x3d7ffe(0x1bd)) / (-0x1411 + -0x2603 + 0x3a1a) + -parseInt(_0x3d7ffe(0x1c9)) / (-0x7a3 + 0x822 + 0x3c * -0x2) * (-parseInt(_0x3d7ffe(0x1c1)) / (-0x1 * 0x1b59 + 0x1451 + 0x710)) + parseInt(_0x3d7ffe(0x1c4)) / (-0x2063 + 0x1e * -0x131 + 0x442a) + -parseInt(_0x3d7ffe(0x1bb)) / (-0x18ae + -0x462 + 0x12a * 0x19);
            if (_0xca2ced === _0x76f455)
                break;
            else
                _0x18c7d4['push'](_0x18c7d4['shift']());
        } catch (_0x4082ff) {
            _0x18c7d4['push'](_0x18c7d4['shift']());
        }
    }
}(_0x50c6, -0x13c48 + -0x2c6ef * -0x1 + 0xcc4d));
const {DataTypes} = require(_0x13f411(0x1c0)), sequelize = require(_0x13f411(0x1c2) + _0x13f411(0x1bc)), License = sequelize[_0x13f411(0x1be)](_0x13f411(0x1c5), {
        'id': {
            'type': DataTypes[_0x13f411(0x1bf)],
            'defaultValue': DataTypes[_0x13f411(0x1b8)],
            'primaryKey': !![]
        },
        'licenseKey': {
            'type': DataTypes[_0x13f411(0x1b9)],
            'allowNull': ![]
        },
        'status': {
            'type': DataTypes[_0x13f411(0x1cc)],
            'defaultValue': _0x13f411(0x1ba)
        },
        'expiresAt': {
            'type': DataTypes[_0x13f411(0x1b7)],
            'allowNull': ![]
        }
    }, {
        'tableName': _0x13f411(0x1c3),
        'timestamps': !![]
    });
module[_0x13f411(0x1c7)] = License;