const _0x4795da = _0xc9a1;
function _0xc9a1(_0x3aa68b, _0x31b3ab) {
    _0x3aa68b = _0x3aa68b - (-0x25a3 + 0xbf0 + 0x3 * 0x8b5);
    const _0x19141b = _0x2811();
    let _0x410db1 = _0x19141b[_0x3aa68b];
    return _0x410db1;
}
function _0x2811() {
    const _0x3abdf = [
        '70582OxYejp',
        'NODE_ENV',
        'xtqNT',
        's/sun.api.',
        'Get\x20All\x20Se',
        'tIKcn',
        '922365kJEtAo',
        'deleteSess',
        'Gleav',
        'GSScc',
        'service',
        '44933460FQnYKB',
        'essions',
        'nVpev',
        'sion',
        'Session\x20de',
        'ding',
        '220134FBTfUT',
        '30006wSrtEs',
        'getAllSess',
        'json',
        'Create\x20Ses',
        'trOuk',
        '\x20session\x20f',
        'leted\x20succ',
        'Delete\x20Ses',
        'ssions\x20Err',
        '2561344XbYNII',
        'ion',
        'body',
        'status',
        'mxDkL',
        'exports',
        'nDnfQ',
        'yLICk',
        'or:',
        'rrwtd',
        '2200wOhmNR',
        'DESC',
        '57qUdoDo',
        'qllHK',
        'ound',
        '../service',
        'error',
        '../models/',
        'qGNjl',
        'dateCreate',
        'sessionId\x20',
        'rKRfo',
        'HPLub',
        'QazHT',
        'create',
        'ions',
        'env',
        'query',
        'sion\x20Error',
        'is\x20require',
        'NFtfi',
        'sessionpen',
        'delete\x20ses',
        '771386BhHPqZ',
        'essfully',
        'findOne',
        'create\x20ses',
        'No\x20pending',
        'INLjA',
        'findAll',
        'retrieve\x20s',
        'guvXE',
        'eated\x20succ',
        'createSess',
        '161dKhXST',
        'HDsyg',
        'destroy',
        'Session\x20cr',
        'chuzW',
        'Failed\x20to\x20',
        'developmen',
        'message'
    ];
    _0x2811 = function () {
        return _0x3abdf;
    };
    return _0x2811();
}
(function (_0xfc9d4f, _0x5727db) {
    const _0xbce242 = _0xc9a1, _0x497bff = _0xfc9d4f();
    while (!![]) {
        try {
            const _0x124853 = -parseInt(_0xbce242(0xb3)) / (-0x8ad * 0x3 + 0x1 * -0x2232 + 0x3c3a) + parseInt(_0xbce242(0x77)) / (0x165b + -0x1f4b + 0x8f2) * (-parseInt(_0xbce242(0x9e)) / (-0xf4c + -0x11 * 0x3c + 0x1 * 0x134b)) + -parseInt(_0xbce242(0x92)) / (-0xb * -0x243 + 0x1251 + -0x2b2e) + -parseInt(_0xbce242(0x7d)) / (-0x191a + 0x1 * -0x3df + 0x2 * 0xe7f) + -parseInt(_0xbce242(0x88)) / (0x1 * 0xc16 + -0xda6 * 0x1 + -0x3a * -0x7) * (parseInt(_0xbce242(0x6f)) / (-0x56 * -0x6a + 0x38 * -0xa6 + -0x11 * -0xb)) + parseInt(_0xbce242(0x9c)) / (-0x25d3 + -0x1 * -0x14ca + -0x11 * -0x101) * (-parseInt(_0xbce242(0x89)) / (0x164b * 0x1 + -0x65b * -0x2 + -0x22f8)) + parseInt(_0xbce242(0x82)) / (-0x1630 + 0x230a + -0xcd0);
            if (_0x124853 === _0x5727db)
                break;
            else
                _0x497bff['push'](_0x497bff['shift']());
        } catch (_0x4ee19a) {
            _0x497bff['push'](_0x497bff['shift']());
        }
    }
}(_0x2811, 0xc4a03 + 0x51e9b + -0xa4c99));
const SessionPending = require(_0x4795da(0xa3) + _0x4795da(0xb1) + _0x4795da(0x87)), {callNotifyMessage} = require(_0x4795da(0xa1) + _0x4795da(0x7a) + _0x4795da(0x81));
class SessionPendingController {
    static async [_0x4795da(0x8a) + _0x4795da(0xab)](_0x88937c, _0xa98f6) {
        const _0xef6a9c = _0x4795da, _0x4a4506 = {
                'chuzW': function (_0x4834ad, _0x19cb5f) {
                    return _0x4834ad !== _0x19cb5f;
                },
                'rrwtd': function (_0x2ba494, _0x3bbbba) {
                    return _0x2ba494(_0x3bbbba);
                },
                'HPLub': _0xef6a9c(0xa5) + 'd',
                'nVpev': _0xef6a9c(0x9d),
                'HDsyg': _0xef6a9c(0x7b) + _0xef6a9c(0x91) + _0xef6a9c(0x9a),
                'qGNjl': _0xef6a9c(0x74) + _0xef6a9c(0xba) + _0xef6a9c(0x83)
            };
        try {
            const {status: _0x21956f} = _0x88937c[_0xef6a9c(0xad)], _0x12cf3d = {};
            _0x4a4506[_0xef6a9c(0x73)](_0x21956f, undefined) && (_0x12cf3d[_0xef6a9c(0x95)] = _0x4a4506[_0xef6a9c(0x9b)](parseInt, _0x21956f));
            const _0xcc74d3 = await SessionPending[_0xef6a9c(0xb9)]({
                'where': _0x12cf3d,
                'order': [[
                        _0x4a4506[_0xef6a9c(0xa8)],
                        _0x4a4506[_0xef6a9c(0x84)]
                    ]]
            });
            _0xa98f6[_0xef6a9c(0x95)](-0x58b + -0x1638 + 0x1c8b)[_0xef6a9c(0x8b)]({
                'success': !![],
                'data': _0xcc74d3
            });
        } catch (_0x2fc6be) {
            console[_0xef6a9c(0xa2)](_0x4a4506[_0xef6a9c(0x70)], _0x2fc6be), _0xa98f6[_0xef6a9c(0x95)](0xda9 * -0x2 + -0x475 * 0x4 + 0x2f1a)[_0xef6a9c(0x8b)]({
                'success': ![],
                'message': _0x4a4506[_0xef6a9c(0xa4)]
            });
        }
    }
    static async [_0x4795da(0x6e) + _0x4795da(0x93)](_0x322698, _0x37e169) {
        const _0x2891b3 = _0x4795da, _0x30cfc3 = {
                'nDnfQ': _0x2891b3(0xa6) + _0x2891b3(0xaf) + 'd',
                'yLICk': function (_0x74e110, _0x1d8f51) {
                    return _0x74e110 !== _0x1d8f51;
                },
                'GSScc': function (_0x3fe53b, _0x17297e) {
                    return _0x3fe53b(_0x17297e);
                },
                'QazHT': _0x2891b3(0x72) + _0x2891b3(0x6d) + _0x2891b3(0xb4),
                'mxDkL': _0x2891b3(0x8c) + _0x2891b3(0xae) + ':',
                'qllHK': _0x2891b3(0x74) + _0x2891b3(0xb6) + _0x2891b3(0x85)
            };
        try {
            const {
                sessionId: _0x24ea37,
                status: _0x846359
            } = _0x322698[_0x2891b3(0x94)];
            if (!_0x24ea37)
                return _0x37e169[_0x2891b3(0x95)](0x16f * -0x1 + 0x5 * 0xc7 + 0x26 * -0x6)[_0x2891b3(0x8b)]({
                    'success': ![],
                    'message': _0x30cfc3[_0x2891b3(0x98)]
                });
            const _0x386583 = await SessionPending[_0x2891b3(0xaa)]({
                'sessionId': _0x24ea37,
                'status': _0x30cfc3[_0x2891b3(0x99)](_0x846359, undefined) ? _0x30cfc3[_0x2891b3(0x80)](parseInt, _0x846359) : -0x1357 + 0x1 * -0x12fa + 0x2651 * 0x1
            });
            _0x37e169[_0x2891b3(0x95)](-0x1be4 + -0x2481 + -0x67 * -0xa2)[_0x2891b3(0x8b)]({
                'success': !![],
                'message': _0x30cfc3[_0x2891b3(0xa9)],
                'data': _0x386583
            });
        } catch (_0x53bc65) {
            console[_0x2891b3(0xa2)](_0x30cfc3[_0x2891b3(0x96)], _0x53bc65), _0x37e169[_0x2891b3(0x95)](0xf * -0x81 + -0x8 * -0x153 + -0x115)[_0x2891b3(0x8b)]({
                'success': ![],
                'message': _0x30cfc3[_0x2891b3(0x9f)]
            });
        }
    }
    static async [_0x4795da(0x7e) + _0x4795da(0x93)](_0x243fa0, _0x30abc3) {
        const _0x8363b8 = _0x4795da, _0x5ebb36 = {
                'trOuk': _0x8363b8(0xa5) + 'd',
                'Gleav': _0x8363b8(0x9d),
                'NFtfi': _0x8363b8(0xb7) + _0x8363b8(0x8e) + _0x8363b8(0xa0),
                'guvXE': _0x8363b8(0x86) + _0x8363b8(0x8f) + _0x8363b8(0xb4),
                'tIKcn': _0x8363b8(0x90) + _0x8363b8(0xae) + ':',
                'xtqNT': _0x8363b8(0x74) + _0x8363b8(0xb2) + _0x8363b8(0x85),
                'rKRfo': function (_0x44ecb4, _0x2c8697) {
                    return _0x44ecb4 === _0x2c8697;
                },
                'INLjA': _0x8363b8(0x75) + 't'
            };
        try {
            const _0x56aa61 = await SessionPending[_0x8363b8(0xb5)]({
                'order': [[
                        _0x5ebb36[_0x8363b8(0x8d)],
                        _0x5ebb36[_0x8363b8(0x7f)]
                    ]]
            });
            if (!_0x56aa61)
                return _0x30abc3[_0x8363b8(0x95)](0x246 + -0x11c3 + 0x1111)[_0x8363b8(0x8b)]({
                    'success': ![],
                    'message': _0x5ebb36[_0x8363b8(0xb0)]
                });
            await _0x56aa61[_0x8363b8(0x71)](), callNotifyMessage, _0x30abc3[_0x8363b8(0x95)](0x1002 + -0x1a5 * 0x4 + -0x8a6)[_0x8363b8(0x8b)]({
                'success': !![],
                'message': _0x5ebb36[_0x8363b8(0x6c)]
            });
        } catch (_0x19ee13) {
            console[_0x8363b8(0xa2)](_0x5ebb36[_0x8363b8(0x7c)], _0x19ee13), _0x30abc3[_0x8363b8(0x95)](0x12b5 + 0x26eb + -0x37ac)[_0x8363b8(0x8b)]({
                'success': ![],
                'message': _0x5ebb36[_0x8363b8(0x79)],
                'error': _0x5ebb36[_0x8363b8(0xa7)](process[_0x8363b8(0xac)][_0x8363b8(0x78)], _0x5ebb36[_0x8363b8(0xb8)]) ? _0x19ee13[_0x8363b8(0x76)] : undefined
            });
        }
    }
}
module[_0x4795da(0x97)] = SessionPendingController;