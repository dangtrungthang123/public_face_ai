function _0x565b() {
    const _0x1b0867 = [
        'postgres',
        'log',
        '24894252BkejUn',
        'isiwo',
        '7770266yyNzqD',
        'Env',
        '8rYwqbU',
        '1565082GfbteD',
        'RL:',
        '5135155gKQEQu',
        's/readFile',
        'sequelize',
        '2412672QbTKZd',
        'Database\x20U',
        '_db',
        'exports',
        'DATABASE_U',
        '278tOfixN',
        '../service',
        'XTZYl',
        '21081YUcrGu',
        'po/face_ai',
        'XzEAm',
        '875758NOJsSm'
    ];
    _0x565b = function () {
        return _0x1b0867;
    };
    return _0x565b();
}
const _0x2b591e = _0x58cb;
function _0x58cb(_0x581423, _0x5955d1) {
    _0x581423 = _0x581423 - (0x1d1d * 0x1 + -0xbbf + -0xfbc);
    const _0x260204 = _0x565b();
    let _0x16d632 = _0x260204[_0x581423];
    return _0x16d632;
}
(function (_0x67c442, _0x413f99) {
    const _0x219c8b = _0x58cb, _0x444a48 = _0x67c442();
    while (!![]) {
        try {
            const _0x29d2b9 = parseInt(_0x219c8b(0x1b8)) / (0x1faf + 0x19db * -0x1 + -0x5d3) + -parseInt(_0x219c8b(0x1b2)) / (0x44e + 0xa9f + 0x43 * -0x39) * (-parseInt(_0x219c8b(0x1b5)) / (-0x2571 + 0xc * -0x12a + 0x336c)) + -parseInt(_0x219c8b(0x1ad)) / (-0x46e + -0x1cc2 + 0x2134) + parseInt(_0x219c8b(0x1aa)) / (-0x17 * -0x44 + 0x1 * -0x26b2 + 0x209b * 0x1) + parseInt(_0x219c8b(0x1a8)) / (-0x165 * -0x9 + -0xb70 * -0x1 + -0x17f7) + parseInt(_0x219c8b(0x1a5)) / (0x2345 + 0x735 + -0x2a73) * (parseInt(_0x219c8b(0x1a7)) / (-0x8 * -0x30b + -0xb33 + -0x3 * 0x45f)) + -parseInt(_0x219c8b(0x1a3)) / (-0xefd + -0xc92 + -0xdcc * -0x2);
            if (_0x29d2b9 === _0x413f99)
                break;
            else
                _0x444a48['push'](_0x444a48['shift']());
        } catch (_0x32ebdb) {
            _0x444a48['push'](_0x444a48['shift']());
        }
    }
}(_0x565b, 0xbc28b * -0x1 + 0x1 * 0x23d3f + 0x16f79b));
const {Sequelize} = require(_0x2b591e(0x1ac)), {readEnvFile} = require(_0x2b591e(0x1b3) + _0x2b591e(0x1ab) + _0x2b591e(0x1a6)), getDbUrl = () => {
        const _0x385df9 = _0x2b591e, _0x5000eb = {
                'isiwo': function (_0x41f0df) {
                    return _0x41f0df();
                },
                'XTZYl': _0x385df9(0x1ae) + _0x385df9(0x1a9),
                'XzEAm': _0x385df9(0x1b6) + _0x385df9(0x1af)
            }, _0x582403 = _0x5000eb[_0x385df9(0x1a4)](readEnvFile);
        return console[_0x385df9(0x1a2)](_0x5000eb[_0x385df9(0x1b4)], _0x582403[_0x385df9(0x1b1) + 'RL']), _0x582403[_0x385df9(0x1b1) + 'RL'] || _0x5000eb[_0x385df9(0x1b7)];
    }, sequelize = new Sequelize(getDbUrl(), {
        'dialect': _0x2b591e(0x1b9),
        'logging': ![],
        'pool': {
            'max': 0x5,
            'min': 0x0,
            'acquire': 0x7530,
            'idle': 0x2710
        },
        'dialectOptions': { 'ssl': ![] }
    });
module[_0x2b591e(0x1b0)] = sequelize;