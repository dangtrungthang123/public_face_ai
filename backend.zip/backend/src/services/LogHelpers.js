const fs = require('fs');
const path = require('path');
const util = require('util');

const appendFileAsync = util.promisify(fs.appendFile);
const readdirAsync = util.promisify(fs.readdir);
const statAsync = util.promisify(fs.stat);
const unlinkAsync = util.promisify(fs.unlink);

class LogHelpers {
    constructor(options = {}) {
        this.logDir = options.logDir || './logs';
        this.maxLogDays = options.maxLogDays || 7;
        this.dateFormat = options.dateFormat || 'YYYY-MM-DD';
        this.logFormat = options.logFormat || 'YYYY-MM-DD HH:mm:ss';
        
        // Đảm bảo thư mục log tồn tại
        this.ensureLogDirectory();
        
        // Khởi tạo cleanup scheduler
        this.scheduleCleanup();
    }
    
    ensureLogDirectory() {
        if (!fs.existsSync(this.logDir)) {
            fs.mkdirSync(this.logDir, { recursive: true });
        }
    }
    
    getCurrentDate() {
        return new Date();
    }
    
    formatDate(date, format) {
        const pad = (n) => n.toString().padStart(2, '0');
        
        const replacements = {
            'YYYY': date.getFullYear(),
            'MM': pad(date.getMonth() + 1),
            'DD': pad(date.getDate()),
            'HH': pad(date.getHours()),
            'mm': pad(date.getMinutes()),
            'ss': pad(date.getSeconds())
        };
        
        return format.replace(/YYYY|MM|DD|HH|mm|ss/g, (match) => replacements[match]);
    }
    
    getLogFileName(date = null) {
        const targetDate = date || this.getCurrentDate();
        const dateStr = this.formatDate(targetDate, this.dateFormat);
        return `log-${dateStr}.log`;
    }
    
    getLogFilePath(date = null) {
        return path.join(this.logDir, this.getLogFileName(date));
    }
    
    async writeLog(level, message, data = null) {
        try {
            const now = this.getCurrentDate();
            const timestamp = this.formatDate(now, this.logFormat);
            const logEntry = {
                timestamp,
                level: level.toUpperCase(),
                message,
                data
            };
            
            // Format log line
            let logLine = `[${logEntry.timestamp}] [${logEntry.level}] ${logEntry.message}`;
            if (data) {
                logLine += ` | ${typeof data === 'object' ? JSON.stringify(data) : data}`;
            }
            logLine += '\n';
            
            // Ghi vào file
            const logPath = this.getLogFilePath(now);
            await appendFileAsync(logPath, logLine);
            
            // In ra console (tùy chọn)
            console.log(logLine.trim());
            
            return true;
        } catch (error) {
            console.error('Error writing log:', error);
            return false;
        }
    }
    
    async cleanupOldLogs() {
        try {
            const files = await readdirAsync(this.logDir);
            const now = this.getCurrentDate();
            const cutoffDate = new Date(now);
            cutoffDate.setDate(cutoffDate.getDate() - this.maxLogDays);
            
            for (const file of files) {
                if (!file.startsWith('log-') || !file.endsWith('.txt')) {
                    continue;
                }
                
                // Trích xuất date từ filename
                const dateMatch = file.match(/log-(\d{4}-\d{2}-\d{2})\.txt/);
                if (!dateMatch) continue;
                
                const fileDateStr = dateMatch[1];
                const [year, month, day] = fileDateStr.split('-').map(Number);
                const fileDate = new Date(year, month - 1, day);
                
                // Xóa file nếu cũ hơn maxLogDays
                if (fileDate < cutoffDate) {
                    const filePath = path.join(this.logDir, file);
                    await unlinkAsync(filePath);
                    console.log(`Deleted old log file: ${file}`);
                }
            }
        } catch (error) {
            console.error('Error cleaning up old logs:', error);
        }
    }
    
    scheduleCleanup() {
        // Chạy cleanup mỗi ngày lúc 00:01
        const now = new Date();
        const tomorrow = new Date(now);
        tomorrow.setDate(tomorrow.getDate() + 1);
        tomorrow.setHours(0, 1, 0, 0);
        
        const timeUntilCleanup = tomorrow.getTime() - now.getTime();
        
        setTimeout(() => {
            this.cleanupOldLogs();
            // Lên lịch cho lần tiếp theo (mỗi 24 giờ)
            setInterval(() => this.cleanupOldLogs(), 24 * 60 * 60 * 1000);
        }, timeUntilCleanup);
        
        console.log(`Next log cleanup scheduled at: ${tomorrow.toLocaleString()}`);
    }
    
    // Các phương thức tiện ích
    async info(message, data = null) {
        return this.writeLog('info', message, data);
    }
    
    async error(message, data = null) {
        return this.writeLog('error', message, data);
    }
    
    async warn(message, data = null) {
        return this.writeLog('warn', message, data);
    }
    
    async debug(message, data = null) {
        return this.writeLog('debug', message, data);
    }
    
    // Đọc log của một ngày cụ thể
    async readLogs(date) {
        try {
            const targetDate = date || this.getCurrentDate();
            const logPath = this.getLogFilePath(targetDate);
            
            if (!fs.existsSync(logPath)) {
                return [];
            }
            
            const content = await util.promisify(fs.readFile)(logPath, 'utf8');
            return content.split('\n').filter(line => line.trim());
        } catch (error) {
            console.error('Error reading logs:', error);
            return [];
        }
    }

    
}

// Singleton instance (tùy chọn)
let instance = null;

function getLogger(options = {}) {
    if (!instance) {
        instance = new LogHelpers(options);
    }
    return instance;
}


function trimImageData(imageData) {
    // Kiểm tra null/undefined/empty
    if (!imageData || typeof imageData !== 'string' || imageData.trim() === '') {
        return "(empty or null)";
    }
    
    const trimmedData = imageData.trim();
    const totalLength = trimmedData.length;
    
    // Nếu chuỗi quá ngắn, trả về luôn
    if (totalLength <= 20) {
        return trimmedData;
    }
    
    // Kiểm tra để tránh lỗi substring
    const firstPart = trimmedData.substring(0, Math.min(10, totalLength));
    const lastPart = trimmedData.substring(Math.max(0, totalLength - 10));
    
    return `${firstPart}...${lastPart}`;
}

module.exports = {
    LogHelpers,
    getLogger,
    trimImageData
};