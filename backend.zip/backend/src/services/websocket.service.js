const _0x442f92 = _0x5c67;
(function (_0x9e4ce, _0x5435fa) {
    const _0x123a16 = _0x5c67, _0x5a800e = _0x9e4ce();
    while (!![]) {
        try {
            const _0x2c2f7f = parseInt(_0x123a16(0x2ac)) / (0x4f * 0x2 + -0x7 * -0x4fd + -0x2388) * (-parseInt(_0x123a16(0x2aa)) / (-0x1 * 0xe4b + -0x13c * -0x3 + -0xa99 * -0x1)) + parseInt(_0x123a16(0x2e4)) / (-0x2481 + -0x1faf + 0x4433) + -parseInt(_0x123a16(0x2ea)) / (-0x9bc + -0xc8a + 0x164a) + -parseInt(_0x123a16(0x1fd)) / (0x15cf + 0xc41 * 0x2 + -0x2e4c) * (-parseInt(_0x123a16(0x277)) / (-0xffd * -0x1 + 0x266 * 0xc + -0x5 * 0x8f3)) + -parseInt(_0x123a16(0x2db)) / (0x1 * 0x1933 + 0x2d5 * 0xa + -0x357e) * (-parseInt(_0x123a16(0x2a2)) / (0x25 * 0xa7 + -0x13aa + 0x3 * -0x17b)) + parseInt(_0x123a16(0x2b8)) / (-0x13fa + 0xa99 * -0x1 + 0x1e9c) * (parseInt(_0x123a16(0x2d0)) / (0x2197 + -0x2 * -0x449 + -0x2a1f)) + parseInt(_0x123a16(0x226)) / (-0x1ee6 + 0xd1d * 0x1 + -0x28c * -0x7) * (-parseInt(_0x123a16(0x33f)) / (0x1ab + 0x25 * -0x6a + 0xdb3));
            if (_0x2c2f7f === _0x5435fa)
                break;
            else
                _0x5a800e['push'](_0x5a800e['shift']());
        } catch (_0x5c43b4) {
            _0x5a800e['push'](_0x5a800e['shift']());
        }
    }
}(_0x3741, 0x98445 + 0x1846a + -0x5ee70));
function _0x5c67(_0x429a31, _0x501421) {
    _0x429a31 = _0x429a31 - (0x126c * 0x2 + -0x341 * 0xb + 0xd8);
    const _0x551352 = _0x3741();
    let _0x218ece = _0x551352[_0x429a31];
    return _0x218ece;
}
const moment = require(_0x442f92(0x228)), Device = require(_0x442f92(0x265) + _0x442f92(0x299)), EventEmitter = require(_0x442f92(0x204)), {callVerifyAPI, callNotifyMessage} = require(_0x442f92(0x23c) + _0x442f92(0x26b)), LicenseService = require(_0x442f92(0x2be) + _0x442f92(0x2ee)), {url} = require(_0x442f92(0x217));
class WebSocketService extends EventEmitter {
    constructor() {
        const _0x5f34ff = _0x442f92, _0x42f16e = { 'zNbtT': _0x5f34ff(0x2c2) + _0x5f34ff(0x284) }, _0xbf145f = _0x42f16e[_0x5f34ff(0x326)][_0x5f34ff(0x1e5)]('|');
        let _0x45bf0b = 0x285 * -0xe + 0x1a0 + 0x10d3 * 0x2;
        while (!![]) {
            switch (_0xbf145f[_0x45bf0b++]) {
            case '0':
                this[_0x5f34ff(0x23d)] = new Map();
                continue;
            case '1':
                this[_0x5f34ff(0x253) + _0x5f34ff(0x20a)] = new Map();
                continue;
            case '2':
                this[_0x5f34ff(0x292) + _0x5f34ff(0x221)] = new Map();
                continue;
            case '3':
                this[_0x5f34ff(0x230) + _0x5f34ff(0x304)] = new Map();
                continue;
            case '4':
                this[_0x5f34ff(0x253) + 'ts'] = new Map();
                continue;
            case '5':
                this[_0x5f34ff(0x1ef)] = null;
                continue;
            case '6':
                super();
                continue;
            }
            break;
        }
    }
    [_0x442f92(0x342)](_0x386a63) {
        const _0x279a39 = _0x442f92, _0x198f47 = {
                'sGfRC': function (_0x38f51a, _0x7baebc) {
                    return _0x38f51a === _0x7baebc;
                },
                'ebSav': function (_0x32f681) {
                    return _0x32f681();
                },
                'zzrTf': _0x279a39(0x288) + _0x279a39(0x291),
                'yNYbW': _0x279a39(0x2bb),
                'ftnTp': _0x279a39(0x213),
                'owWLP': function (_0x1e73f5, _0x2dcdc2, _0x25fba0) {
                    return _0x1e73f5(_0x2dcdc2, _0x25fba0);
                },
                'zVDds': _0x279a39(0x2a0)
            };
        this[_0x279a39(0x1ef)] = _0x386a63, this[_0x279a39(0x1ef)]['on'](_0x198f47[_0x279a39(0x318)], (_0x16e145, _0x1ca8f6) => this[_0x279a39(0x31a) + _0x279a39(0x2d4)](_0x16e145, _0x1ca8f6));
        const _0x20d776 = _0x198f47[_0x279a39(0x27a)](setInterval, () => {
            const _0x3c3e6b = _0x279a39;
            this[_0x3c3e6b(0x1ef)][_0x3c3e6b(0x202)][_0x3c3e6b(0x257)](_0x4cc6d2 => {
                const _0x59be80 = _0x3c3e6b;
                if (_0x198f47[_0x59be80(0x250)](_0x4cc6d2[_0x59be80(0x27b)], ![]))
                    return console[_0x59be80(0x2a1)]('[' + _0x198f47[_0x59be80(0x332)](moment)[_0x59be80(0x2c6)](_0x198f47[_0x59be80(0x315)]) + (_0x59be80(0x28f) + _0x59be80(0x2f8) + _0x59be80(0x231) + _0x59be80(0x21d)) + (_0x4cc6d2['sn'] || _0x198f47[_0x59be80(0x33b)])), _0x4cc6d2[_0x59be80(0x222)]();
                _0x4cc6d2[_0x59be80(0x27b)] = ![], _0x4cc6d2[_0x59be80(0x309)]();
            });
        }, -0xb6ce + 0xa0f * -0xa + 0x19094);
        this[_0x279a39(0x1ef)]['on'](_0x198f47[_0x279a39(0x1f3)], () => clearInterval(_0x20d776));
    }
    async [_0x442f92(0x2af) + _0x442f92(0x2cb)]() {
        const _0x3c7ec9 = _0x442f92, _0x29f9ea = {
                'Exenn': _0x3c7ec9(0x20d),
                'oUrXX': _0x3c7ec9(0x32f) + _0x3c7ec9(0x2b1) + _0x3c7ec9(0x286) + _0x3c7ec9(0x294),
                'IZwJC': _0x3c7ec9(0x2a4) + _0x3c7ec9(0x339) + _0x3c7ec9(0x327) + 's:'
            };
        try {
            await Device[_0x3c7ec9(0x237)]({ 'status': _0x29f9ea[_0x3c7ec9(0x1f6)] }, { 'where': {} }), console[_0x3c7ec9(0x2a1)](_0x29f9ea[_0x3c7ec9(0x2c5)]);
        } catch (_0x2f5d20) {
            console[_0x3c7ec9(0x209)](_0x29f9ea[_0x3c7ec9(0x2bc)], _0x2f5d20[_0x3c7ec9(0x254)]);
        }
    }
    async [_0x442f92(0x31a) + _0x442f92(0x2d4)](_0x1a46d0, _0x2e362d) {
        const _0x45cc5b = _0x442f92, _0x628e29 = {
                'khzby': function (_0x55f39d) {
                    return _0x55f39d();
                },
                'fuqLu': _0x45cc5b(0x288) + _0x45cc5b(0x291),
                'gkrPk': _0x45cc5b(0x23b) + 'i',
                'Givsh': _0x45cc5b(0x2b0),
                'xIZml': _0x45cc5b(0x340),
                'syQAs': _0x45cc5b(0x31f) + _0x45cc5b(0x2f5),
                'qCbkR': _0x45cc5b(0x317) + _0x45cc5b(0x24c),
                'oOXqj': _0x45cc5b(0x2d6),
                'zCypU': function (_0x3dbb95) {
                    return _0x3dbb95();
                },
                'GXSwT': _0x45cc5b(0x299),
                'fQddc': function (_0x740783) {
                    return _0x740783();
                },
                'JjZDy': _0x45cc5b(0x2d9),
                'mQrSc': _0x45cc5b(0x254),
                'RJmGI': _0x45cc5b(0x2a0),
                'cCQFL': _0x45cc5b(0x209)
            }, _0x379d58 = await LicenseService[_0x45cc5b(0x312) + _0x45cc5b(0x223)]();
        if (!_0x379d58[_0x45cc5b(0x2ab)]) {
            console[_0x45cc5b(0x2a1)]('[' + _0x628e29[_0x45cc5b(0x2f3)](moment)[_0x45cc5b(0x2c6)](_0x628e29[_0x45cc5b(0x275)]) + (_0x45cc5b(0x21b) + _0x45cc5b(0x269) + _0x45cc5b(0x289)) + _0x379d58[_0x45cc5b(0x209)]), _0x1a46d0[_0x45cc5b(0x2a0)](-0x1526 + -0x2593 * -0x1 + 0xc7d * -0x1, _0x45cc5b(0x2e5) + _0x45cc5b(0x29a) + _0x379d58[_0x45cc5b(0x209)]);
            return;
        }
        const _0x5a1dda = _0x2e362d[_0x45cc5b(0x1e6)][_0x45cc5b(0x2e9) + _0x45cc5b(0x261)];
        _0x1a46d0[_0x45cc5b(0x262)] = _0x5a1dda, _0x1a46d0[_0x45cc5b(0x27b)] = !![];
        if (_0x2e362d[_0x45cc5b(0x251)][_0x45cc5b(0x30b)](_0x628e29[_0x45cc5b(0x30a)])) {
            _0x1a46d0[_0x45cc5b(0x2dc)] = _0x628e29[_0x45cc5b(0x344)];
            const _0x5ae74c = _0x2e362d[_0x45cc5b(0x251)][_0x45cc5b(0x1e5)]('?'), _0x23adec = new URLSearchParams(_0x5ae74c[-0xee1 + 0x1 * 0xf3b + 0x59 * -0x1] || ''), _0x3852b5 = _0x23adec[_0x45cc5b(0x308)]('sn'), _0x882451 = _0x23adec[_0x45cc5b(0x308)](_0x628e29[_0x45cc5b(0x33c)]) || _0x45cc5b(0x324) + Date[_0x45cc5b(0x330)]() + '-' + Math[_0x45cc5b(0x334)]()[_0x45cc5b(0x287)](-0x135c + -0xa28 + -0x1a * -0x124)[_0x45cc5b(0x25e)](0x21b8 + -0xf77 * 0x2 + -0x2c8, 0x144 * 0x1 + -0x12f2 * 0x1 + -0x11b7 * -0x1);
            if (!_0x3852b5) {
                console[_0x45cc5b(0x2a1)]('[' + _0x628e29[_0x45cc5b(0x2f3)](moment)[_0x45cc5b(0x2c6)](_0x628e29[_0x45cc5b(0x275)]) + (_0x45cc5b(0x2e3) + _0x45cc5b(0x220) + _0x45cc5b(0x2f4) + _0x45cc5b(0x24a))), _0x1a46d0[_0x45cc5b(0x2a0)](-0x2529 + 0x211 * -0x6 + 0xb * 0x4dd, _0x628e29[_0x45cc5b(0x1ff)]);
                return;
            }
            _0x1a46d0[_0x45cc5b(0x2dc)] = _0x628e29[_0x45cc5b(0x344)], _0x1a46d0['sn'] = _0x3852b5, _0x1a46d0[_0x45cc5b(0x340)] = _0x882451, this[_0x45cc5b(0x253) + 'ts'][_0x45cc5b(0x263)](_0x3852b5, _0x1a46d0), this[_0x45cc5b(0x253) + _0x45cc5b(0x20a)][_0x45cc5b(0x263)](_0x1a46d0, {
                'clientId': _0x882451,
                'sn': _0x3852b5,
                'connectedAt': new Date()
            }), console[_0x45cc5b(0x2a1)]('[' + _0x628e29[_0x45cc5b(0x2f3)](moment)[_0x45cc5b(0x2c6)](_0x628e29[_0x45cc5b(0x275)]) + (_0x45cc5b(0x2e3) + _0x45cc5b(0x26e) + _0x45cc5b(0x31e)) + _0x882451 + (_0x45cc5b(0x1f1) + 'e\x20') + _0x3852b5 + _0x45cc5b(0x27c) + _0x5a1dda), _0x1a46d0[_0x45cc5b(0x2d2)](JSON[_0x45cc5b(0x2b9)]({
                'cmd': _0x628e29[_0x45cc5b(0x30c)],
                'ret': _0x628e29[_0x45cc5b(0x321)],
                'result': !![],
                'sn': _0x3852b5,
                'clientId': _0x882451,
                'message': _0x45cc5b(0x2df) + _0x45cc5b(0x1f1) + 'e\x20' + _0x3852b5,
                'timestamp': _0x628e29[_0x45cc5b(0x1fb)](moment)[_0x45cc5b(0x2c6)](_0x628e29[_0x45cc5b(0x275)])
            }));
        } else
            _0x1a46d0[_0x45cc5b(0x2dc)] = _0x628e29[_0x45cc5b(0x246)];
        console[_0x45cc5b(0x2a1)]('[' + _0x628e29[_0x45cc5b(0x28e)](moment)[_0x45cc5b(0x2c6)](_0x628e29[_0x45cc5b(0x275)]) + (_0x45cc5b(0x245) + _0x45cc5b(0x32b) + 'm\x20') + _0x5a1dda), _0x1a46d0['on'](_0x628e29[_0x45cc5b(0x2c8)], () => {
            const _0x4fec62 = _0x45cc5b;
            _0x1a46d0[_0x4fec62(0x27b)] = !![];
        }), _0x1a46d0['on'](_0x628e29[_0x45cc5b(0x313)], _0x21788d => this[_0x45cc5b(0x30e) + _0x45cc5b(0x244)](_0x1a46d0, _0x21788d)), _0x1a46d0['on'](_0x628e29[_0x45cc5b(0x212)], () => this[_0x45cc5b(0x270) + 'e'](_0x1a46d0)), _0x1a46d0['on'](_0x628e29[_0x45cc5b(0x267)], _0x364052 => this[_0x45cc5b(0x236) + 'r'](_0x1a46d0, _0x364052));
    }
    async [_0x442f92(0x30e) + _0x442f92(0x244)](_0x2de8d1, _0xae6c9c) {
        const _0x599183 = _0x442f92, _0xe22f57 = {
                'TEXDM': function (_0x4db5f1) {
                    return _0x4db5f1();
                },
                'niKMm': _0x599183(0x288) + _0x599183(0x291),
                'mqpcs': _0x599183(0x2bb),
                'kjGDR': function (_0x27b3cd, _0x2a9a18) {
                    return _0x27b3cd === _0x2a9a18;
                },
                'pzVri': _0x599183(0x2b0),
                'jhpgG': _0x599183(0x283) + _0x599183(0x34b),
                'Yneoo': _0x599183(0x2a1),
                'FVRrO': _0x599183(0x239),
                'NMStx': _0x599183(0x317) + _0x599183(0x24c),
                'YuCBK': _0x599183(0x274) + _0x599183(0x249) + 'e:'
            };
        try {
            const _0x4ac60a = await LicenseService[_0x599183(0x312) + _0x599183(0x223)]();
            if (!_0x4ac60a[_0x599183(0x2ab)]) {
                console[_0x599183(0x2a1)]('[' + _0xe22f57[_0x599183(0x216)](moment)[_0x599183(0x2c6)](_0xe22f57[_0x599183(0x248)]) + (_0x599183(0x25c) + _0x599183(0x20e)) + (_0x2de8d1['sn'] || _0xe22f57[_0x599183(0x266)]) + (_0x599183(0x2f2) + '\x20') + _0x4ac60a[_0x599183(0x209)]), _0x2de8d1[_0x599183(0x2a0)](0x1eb1 + -0x69 * -0xa + -0x1edb, _0x599183(0x2e5) + _0x599183(0x29a) + _0x4ac60a[_0x599183(0x209)]);
                return;
            }
            const _0x10cc4c = _0xae6c9c[_0x599183(0x287)](), _0x354678 = JSON[_0x599183(0x298)](_0x10cc4c), {
                    cmd: _0x1ca3f5,
                    ret: _0x5405f9
                } = _0x354678, _0x4fb615 = _0xe22f57[_0x599183(0x29e)](_0x2de8d1[_0x599183(0x2dc)], _0xe22f57[_0x599183(0x211)]) ? _0x2de8d1[_0x599183(0x340)] + '\x20(' + _0x2de8d1['sn'] + ')' : _0x2de8d1['sn'] || _0xe22f57[_0x599183(0x224)];
            console[_0x599183(0x2a1)]('[' + _0xe22f57[_0x599183(0x216)](moment)[_0x599183(0x2c6)](_0xe22f57[_0x599183(0x248)]) + (_0x599183(0x20b) + _0x599183(0x27c)) + _0x2de8d1[_0x599183(0x2dc)] + '\x20' + _0x4fb615 + ':', this[_0x599183(0x1e8) + _0x599183(0x234)](_0x354678)), this[_0x599183(0x2c3)](_0xe22f57[_0x599183(0x33d)], {
                'timestamp': _0xe22f57[_0x599183(0x216)](moment)[_0x599183(0x2c6)](_0xe22f57[_0x599183(0x248)]),
                'sn': _0x2de8d1['sn'],
                'clientId': _0x2de8d1[_0x599183(0x340)],
                'clientType': _0x2de8d1[_0x599183(0x2dc)],
                'sn': _0x2de8d1['sn'],
                'type': _0xe22f57[_0x599183(0x23f)],
                'data': _0x354678
            });
            if (_0xe22f57[_0x599183(0x29e)](_0x1ca3f5, _0xe22f57[_0x599183(0x200)])) {
            } else {
                if (_0x1ca3f5)
                    this[_0x599183(0x34a) + _0x599183(0x343)](_0x2de8d1, _0x1ca3f5, _0x354678);
                else
                    _0x5405f9 && this[_0x599183(0x34a) + _0x599183(0x2f9)](_0x2de8d1, _0x5405f9, _0x354678);
            }
        } catch (_0x54233b) {
            console[_0x599183(0x209)](_0xe22f57[_0x599183(0x2e0)], _0x54233b[_0x599183(0x254)]);
        }
    }
    async [_0x442f92(0x34a) + _0x442f92(0x343)](_0x368828, _0x168be8, _0x4f9834) {
        const _0x2fb967 = _0x442f92, _0x543771 = {
                'exKIs': function (_0x5c28ac, _0x2143ea) {
                    return _0x5c28ac + _0x2143ea;
                },
                'TBkfV': _0x2fb967(0x30d) + _0x2fb967(0x2ca),
                'vBzHr': _0x2fb967(0x25f) + _0x2fb967(0x244),
                'KwVDR': function (_0x537026, _0x43fc73) {
                    return _0x537026 + _0x43fc73;
                },
                'JlbnI': _0x2fb967(0x333) + _0x2fb967(0x2fe),
                'nxHHV': function (_0x1f049e, _0x5e4332) {
                    return _0x1f049e + _0x5e4332;
                },
                'rVLeg': _0x2fb967(0x319),
                'kofxc': function (_0x1d2a51, _0xccfe91) {
                    return _0x1d2a51 + _0xccfe91;
                },
                'tcLFZ': _0x2fb967(0x205) + _0x2fb967(0x2a5) + _0x2fb967(0x2bf) + _0x2fb967(0x1f9) + '\x20',
                'cVjwY': function (_0x3c18b3, _0x4c6d74) {
                    return _0x3c18b3(_0x4c6d74);
                },
                'glCfa': _0x2fb967(0x319) + _0x2fb967(0x1f2),
                'FTucL': function (_0x6d3605, _0x5ac4e4) {
                    return _0x6d3605 + _0x5ac4e4;
                },
                'mjtGR': function (_0x2b6f7e, _0x463783) {
                    return _0x2b6f7e + _0x463783;
                },
                'PdpqP': _0x2fb967(0x2da) + _0x2fb967(0x2c7),
                'vWCHz': function (_0x4aea94, _0x500a64) {
                    return _0x4aea94 === _0x500a64;
                },
                'QwUse': _0x2fb967(0x28c),
                'RrKKh': _0x2fb967(0x1f0) + _0x2fb967(0x32c) + _0x2fb967(0x260),
                'PCKsD': _0x2fb967(0x2b7),
                'pDlKH': _0x2fb967(0x264) + _0x2fb967(0x27e),
                'bMlWE': _0x2fb967(0x28d) + _0x2fb967(0x2f6),
                'wHZgZ': _0x2fb967(0x320),
                'ogxOK': _0x2fb967(0x278),
                'JnDKS': _0x2fb967(0x2a4) + _0x2fb967(0x306) + _0x2fb967(0x311) + _0x2fb967(0x2c1),
                'tXOrp': function (_0x286c5a) {
                    return _0x286c5a();
                },
                'WLTGK': _0x2fb967(0x288) + _0x2fb967(0x291),
                'wcBQp': _0x2fb967(0x227),
                'UyPnd': function (_0x2908bb, _0x239aec) {
                    return _0x2908bb > _0x239aec;
                },
                'rZQuk': function (_0x4de61b, _0x193e46, _0x3f0b32) {
                    return _0x4de61b(_0x193e46, _0x3f0b32);
                },
                'WNDfI': _0x2fb967(0x2a9)
            };
        switch (_0x168be8) {
        case _0x543771[_0x2fb967(0x31d)]:
            const _0x3a0ad6 = _0x4f9834['sn'];
            this[_0x2fb967(0x292) + _0x2fb967(0x221)][_0x2fb967(0x263)](_0x3a0ad6, _0x368828), _0x368828['sn'] = _0x3a0ad6;
            try {
                await Device[_0x2fb967(0x2cd)]({
                    'sn': _0x3a0ad6,
                    'status': _0x543771[_0x2fb967(0x2b2)],
                    'last_seen': new Date(),
                    'ip_address': _0x368828[_0x2fb967(0x262)]
                });
            } catch (_0x4f3506) {
                console[_0x2fb967(0x209)](_0x543771[_0x2fb967(0x346)], _0x4f3506[_0x2fb967(0x254)]);
            }
            _0x368828[_0x2fb967(0x2d2)](JSON[_0x2fb967(0x2b9)]({
                'ret': _0x543771[_0x2fb967(0x31d)],
                'result': !![],
                'cloudtime': _0x543771[_0x2fb967(0x2fa)](moment)[_0x2fb967(0x2c6)](_0x543771[_0x2fb967(0x272)]),
                'nosenduser': ![]
            })), console[_0x2fb967(0x2a1)]('[' + _0x543771[_0x2fb967(0x2fa)](moment)[_0x2fb967(0x2c6)](_0x543771[_0x2fb967(0x272)]) + (_0x2fb967(0x305) + _0x2fb967(0x242) + '\x20') + _0x3a0ad6);
            break;
        case _0x543771[_0x2fb967(0x335)]:
            const _0x5590e9 = _0x4f9834[_0x2fb967(0x25a)] || -0x1ad * -0x9 + 0x28 * 0x42 + -0x1965, _0x33608f = _0x4f9834[_0x2fb967(0x300)] || 0x157 + 0x2706 + 0x1 * -0x285d;
            _0x4f9834[_0x2fb967(0x2fb)] && _0x543771[_0x2fb967(0x2d3)](_0x4f9834[_0x2fb967(0x2fb)][_0x2fb967(0x22c)], -0x29 * -0x6d + 0x881 + -0x19f6) && _0x4f9834[_0x2fb967(0x2fb)][0x2 * 0x85 + -0x3 * -0x933 + -0x1ca3][_0x2fb967(0x2e7)] && this[_0x2fb967(0x23d)][_0x2fb967(0x263)](_0x4f9834['sn'] || _0x368828['sn'], _0x4f9834[_0x2fb967(0x2fb)][0x1f3 * -0x11 + 0x1 * 0x232 + 0x1ef1][_0x2fb967(0x2e7)]);
            _0x543771[_0x2fb967(0x252)](callVerifyAPI, _0x4f9834[_0x2fb967(0x2fb)][0x8b9 + -0x1 * -0x1492 + -0x1d4b][_0x2fb967(0x2e7)], _0x368828['sn'])[_0x2fb967(0x2ff)](_0x81bab2 => {
                const _0x23217c = _0x2fb967, _0x48e743 = {
                        'vUJBf': function (_0x4c26a3, _0x4435ba) {
                            const _0x3cfcfc = _0x5c67;
                            return _0x543771[_0x3cfcfc(0x2ae)](_0x4c26a3, _0x4435ba);
                        },
                        'vsckp': _0x543771[_0x23217c(0x296)],
                        'MvbTK': _0x543771[_0x23217c(0x325)],
                        'OqkFT': function (_0x478783, _0x4eb6dd) {
                            const _0x2b3471 = _0x23217c;
                            return _0x543771[_0x2b3471(0x247)](_0x478783, _0x4eb6dd);
                        },
                        'cnBjr': _0x543771[_0x23217c(0x280)],
                        'yPumu': function (_0xb0fcc3, _0x4fb4bc) {
                            const _0x58b374 = _0x23217c;
                            return _0x543771[_0x58b374(0x2b4)](_0xb0fcc3, _0x4fb4bc);
                        },
                        'YKFxN': _0x543771[_0x23217c(0x24d)],
                        'wnQOu': function (_0x34f61e, _0xd31759) {
                            const _0x3f3dd4 = _0x23217c;
                            return _0x543771[_0x3f3dd4(0x26f)](_0x34f61e, _0xd31759);
                        },
                        'KPjlA': _0x543771[_0x23217c(0x2a3)],
                        'EYXOo': function (_0xb68128, _0xc7c4c5) {
                            const _0x1bd932 = _0x23217c;
                            return _0x543771[_0x1bd932(0x1fe)](_0xb68128, _0xc7c4c5);
                        },
                        'VMeve': _0x543771[_0x23217c(0x1ea)],
                        'IOUNM': function (_0x2feb35, _0x2a2e9f) {
                            const _0x11abec = _0x23217c;
                            return _0x543771[_0x11abec(0x2de)](_0x2feb35, _0x2a2e9f);
                        }
                    };
                console[_0x23217c(0x2a1)](_0x543771[_0x23217c(0x329)](_0x543771[_0x23217c(0x273)], JSON[_0x23217c(0x2b9)](_0x81bab2))), _0x543771[_0x23217c(0x349)](_0x81bab2[_0x23217c(0x2d7)], _0x543771[_0x23217c(0x2d5)]) ? (console[_0x23217c(0x2a1)](_0x543771[_0x23217c(0x26f)](_0x543771[_0x23217c(0x235)], _0x368828['sn'])), this[_0x23217c(0x26d) + _0x23217c(0x337)](_0x368828['sn'], {
                    'cmd': _0x543771[_0x23217c(0x2f7)],
                    'doornum': 0x1
                })[_0x23217c(0x2ff)](_0x360e1f => {
                    const _0x5efdaf = _0x23217c, _0x2bc17a = {
                            'yjlQB': function (_0x5e13f1, _0x19bc00) {
                                const _0x3868bc = _0x5c67;
                                return _0x48e743[_0x3868bc(0x316)](_0x5e13f1, _0x19bc00);
                            },
                            'cxBUj': _0x48e743[_0x5efdaf(0x256)]
                        };
                    console[_0x5efdaf(0x2a1)](_0x48e743[_0x5efdaf(0x218)](_0x48e743[_0x5efdaf(0x219)], JSON[_0x5efdaf(0x2b9)](_0x360e1f))), _0x360e1f[_0x5efdaf(0x276)] ? (console[_0x5efdaf(0x2a1)](_0x48e743[_0x5efdaf(0x2ad)](_0x48e743[_0x5efdaf(0x29b)], _0x81bab2[_0x5efdaf(0x297)])), _0x48e743[_0x5efdaf(0x210)](callNotifyMessage, _0x81bab2[_0x5efdaf(0x297)])[_0x5efdaf(0x2ff)](_0x169c01 => {
                        const _0x42f763 = _0x5efdaf;
                        console[_0x42f763(0x2a1)](_0x48e743[_0x42f763(0x215)](_0x48e743[_0x42f763(0x1f7)], JSON[_0x42f763(0x2b9)](_0x169c01))), this[_0x42f763(0x23e) + _0x42f763(0x2cc)](_0x4f9834['sn'] || _0x368828['sn'], {
                            'event': _0x48e743[_0x42f763(0x1ed)],
                            'sn': _0x4f9834['sn'] || _0x368828['sn'],
                            'data': _0x169c01
                        });
                    })[_0x5efdaf(0x2b3)](_0x1c4ff0 => {
                        const _0x2042fc = _0x5efdaf;
                        console[_0x2042fc(0x2a1)](_0x2bc17a[_0x2042fc(0x2fd)](_0x2bc17a[_0x2042fc(0x241)], _0x1c4ff0));
                    })) : console[_0x5efdaf(0x2a1)](_0x48e743[_0x5efdaf(0x22a)]);
                })[_0x23217c(0x2b3)](_0x5f0761 => {
                    const _0x10a069 = _0x23217c;
                    console[_0x10a069(0x2a1)](_0x48e743[_0x10a069(0x307)](_0x48e743[_0x10a069(0x219)], _0x5f0761));
                })) : console[_0x23217c(0x2a1)](_0x543771[_0x23217c(0x2ef)]);
            })[_0x2fb967(0x2b3)](_0x25325f => {
                const _0x522ef5 = _0x2fb967;
                console[_0x522ef5(0x2a1)](_0x543771[_0x522ef5(0x26f)](_0x543771[_0x522ef5(0x208)], _0x25325f));
            }), _0x368828[_0x2fb967(0x2d2)](JSON[_0x2fb967(0x2b9)]({
                'ret': _0x543771[_0x2fb967(0x335)],
                'result': !![],
                'count': _0x5590e9,
                'logindex': _0x33608f,
                'cloudtime': _0x543771[_0x2fb967(0x2fa)](moment)[_0x2fb967(0x2c6)](_0x543771[_0x2fb967(0x272)]),
                'access': 0x1
            }));
            break;
        case _0x543771[_0x2fb967(0x2e6)]:
            _0x4f9834[_0x2fb967(0x2fb)] && this[_0x2fb967(0x23d)][_0x2fb967(0x263)](_0x4f9834['sn'] || _0x368828['sn'], _0x4f9834[_0x2fb967(0x2fb)]);
            _0x368828[_0x2fb967(0x2d2)](JSON[_0x2fb967(0x2b9)]({
                'ret': _0x543771[_0x2fb967(0x2e6)],
                'result': !![],
                'enrollid': _0x4f9834[_0x2fb967(0x20f)],
                'backupnum': _0x4f9834[_0x2fb967(0x24f)]
            }));
            break;
        }
    }
    [_0x442f92(0x34a) + _0x442f92(0x2f9)](_0x219fb7, _0x74c373, _0x2db1a8) {
        const _0x1dce8a = _0x442f92, _0x21cddc = {
                'KrKto': _0x1dce8a(0x2e8),
                'jsfPI': _0x1dce8a(0x301),
                'MuPbr': function (_0x7f406d) {
                    return _0x7f406d();
                },
                'iTLmi': _0x1dce8a(0x288) + _0x1dce8a(0x291),
                'DpDQX': _0x1dce8a(0x2a1),
                'GSgft': function (_0x1eff6f) {
                    return _0x1eff6f();
                },
                'qITlG': _0x1dce8a(0x2fc)
            }, _0x1c5c29 = _0x2db1a8[_0x1dce8a(0x276)] ? _0x21cddc[_0x1dce8a(0x26a)] : _0x21cddc[_0x1dce8a(0x201)], _0xffc593 = _0x2db1a8[_0x1dce8a(0x2a6)] ? _0x1dce8a(0x2a8) + _0x2db1a8[_0x1dce8a(0x2a6)] + ')' : '';
        console[_0x1dce8a(0x2a1)]('[' + _0x21cddc[_0x1dce8a(0x341)](moment)[_0x1dce8a(0x2c6)](_0x21cddc[_0x1dce8a(0x31b)]) + (_0x1dce8a(0x305) + _0x1dce8a(0x310) + '\x20') + _0x74c373 + ':\x20' + _0x1c5c29 + _0xffc593);
        if (_0x219fb7['sn']) {
            const _0x10e22f = _0x219fb7['sn'] + ':' + _0x74c373, _0x1e708f = this[_0x1dce8a(0x230) + _0x1dce8a(0x304)][_0x1dce8a(0x308)](_0x10e22f);
            _0x1e708f && (_0x1e708f[_0x1dce8a(0x22f)](_0x2db1a8), this[_0x1dce8a(0x230) + _0x1dce8a(0x304)][_0x1dce8a(0x26c)](_0x10e22f));
        }
        this[_0x1dce8a(0x2c3)](_0x21cddc[_0x1dce8a(0x28b)], {
            'timestamp': _0x21cddc[_0x1dce8a(0x2e2)](moment)[_0x1dce8a(0x2c6)](_0x21cddc[_0x1dce8a(0x31b)]),
            'sn': _0x219fb7['sn'],
            'type': _0x21cddc[_0x1dce8a(0x268)],
            'command': _0x74c373,
            'result': _0x1c5c29,
            'reason': _0xffc593,
            'data': _0x2db1a8
        });
    }
    async [_0x442f92(0x270) + 'e'](_0x47e807) {
        const _0x3fc132 = _0x442f92, _0x17deaf = {
                'yyHFW': _0x3fc132(0x2a1),
                'QbeNU': function (_0x46ec39) {
                    return _0x46ec39();
                },
                'pdJwD': _0x3fc132(0x288) + _0x3fc132(0x291),
                'XidMu': _0x3fc132(0x1fc) + 'ED',
                'QdWWJ': function (_0x14f915, _0x55c57d) {
                    return _0x14f915 === _0x55c57d;
                },
                'vqtjU': _0x3fc132(0x20d),
                'CDdJW': _0x3fc132(0x2a4) + _0x3fc132(0x2bd) + _0x3fc132(0x229) + _0x3fc132(0x348) + _0x3fc132(0x33a),
                'IlCYw': function (_0x110118) {
                    return _0x110118();
                }
            };
        if (_0x47e807['sn']) {
            this[_0x3fc132(0x2c3)](_0x17deaf[_0x3fc132(0x2c0)], {
                'timestamp': _0x17deaf[_0x3fc132(0x233)](moment)[_0x3fc132(0x2c6)](_0x17deaf[_0x3fc132(0x2b6)]),
                'sn': _0x47e807['sn'],
                'type': _0x17deaf[_0x3fc132(0x336)],
                'message': _0x3fc132(0x2d8) + _0x47e807['sn'] + (_0x3fc132(0x22e) + _0x3fc132(0x206))
            });
            if (_0x17deaf[_0x3fc132(0x2ba)](this[_0x3fc132(0x292) + _0x3fc132(0x221)][_0x3fc132(0x308)](_0x47e807['sn']), _0x47e807)) {
                this[_0x3fc132(0x292) + _0x3fc132(0x221)][_0x3fc132(0x26c)](_0x47e807['sn']), console[_0x3fc132(0x2a1)]('[' + _0x17deaf[_0x3fc132(0x233)](moment)[_0x3fc132(0x2c6)](_0x17deaf[_0x3fc132(0x2b6)]) + (_0x3fc132(0x1ec) + _0x3fc132(0x238) + _0x3fc132(0x289)) + _0x47e807['sn']);
                try {
                    await Device[_0x3fc132(0x237)]({
                        'status': _0x17deaf[_0x3fc132(0x232)],
                        'last_seen': new Date()
                    }, { 'where': { 'sn': _0x47e807['sn'] } });
                } catch (_0x4bc846) {
                    console[_0x3fc132(0x209)](_0x17deaf[_0x3fc132(0x2a7)], _0x4bc846[_0x3fc132(0x254)]);
                }
            } else
                console[_0x3fc132(0x2a1)]('[' + _0x17deaf[_0x3fc132(0x282)](moment)[_0x3fc132(0x2c6)](_0x17deaf[_0x3fc132(0x2b6)]) + (_0x3fc132(0x2c9) + _0x3fc132(0x258) + _0x3fc132(0x295) + _0x3fc132(0x20c)) + _0x47e807['sn']);
        }
    }
    [_0x442f92(0x236) + 'r'](_0x3014d2, _0x3eaa65) {
        const _0x220809 = _0x442f92, _0x3440e2 = {
                'NwPnH': _0x220809(0x2a1),
                'rDWQk': function (_0x2a4b09) {
                    return _0x2a4b09();
                },
                'pZyLI': _0x220809(0x288) + _0x220809(0x291),
                'RsCDB': _0x220809(0x338)
            };
        _0x3014d2['sn'] && this[_0x220809(0x2c3)](_0x3440e2[_0x220809(0x21e)], {
            'timestamp': _0x3440e2[_0x220809(0x1ee)](moment)[_0x220809(0x2c6)](_0x3440e2[_0x220809(0x2b5)]),
            'sn': _0x3014d2['sn'],
            'type': _0x3440e2[_0x220809(0x214)],
            'message': _0x220809(0x2dd) + _0x220809(0x25b) + _0x3014d2['sn'] + ':\x20' + _0x3eaa65[_0x220809(0x254)]
        }), console[_0x220809(0x209)]('[' + _0x3440e2[_0x220809(0x1ee)](moment)[_0x220809(0x2c6)](_0x3440e2[_0x220809(0x2b5)]) + (_0x220809(0x259) + _0x220809(0x29d)), _0x3eaa65[_0x220809(0x254)]);
    }
    async [_0x442f92(0x26d) + _0x442f92(0x337)](_0x5cb35b, _0x4a8415, _0x4f4a79 = 0x309c + -0x373c + -0x1 * -0x2db0) {
        const _0x5baa48 = _0x442f92, _0x438419 = {
                'rETrW': function (_0x302218, _0x5faad7) {
                    return _0x302218(_0x5faad7);
                },
                'jRCZd': function (_0x418a02, _0x17a28d, _0x58e6d4) {
                    return _0x418a02(_0x17a28d, _0x58e6d4);
                },
                'nmIlh': function (_0x253d80, _0x49f886) {
                    return _0x253d80 === _0x49f886;
                },
                'fSqJK': function (_0x173c75) {
                    return _0x173c75();
                },
                'MZAhT': _0x5baa48(0x288) + _0x5baa48(0x291),
                'vHiBU': _0x5baa48(0x2a1),
                'XcodY': function (_0x22d217) {
                    return _0x22d217();
                },
                'phJyF': _0x5baa48(0x2cf),
                'xsTDI': function (_0x2750ff) {
                    return _0x2750ff();
                }
            }, _0x3442d7 = this[_0x5baa48(0x292) + _0x5baa48(0x221)][_0x5baa48(0x308)](_0x5cb35b);
        if (_0x3442d7 && _0x438419[_0x5baa48(0x2e1)](_0x3442d7[_0x5baa48(0x2f0)], -0x977 + 0x1f62 * 0x1 + -0xff * 0x16)) {
            const _0x3d70c6 = _0x4a8415[_0x5baa48(0x22d)], _0x2a6ccb = _0x5cb35b + ':' + _0x3d70c6;
            return _0x3442d7[_0x5baa48(0x2d2)](JSON[_0x5baa48(0x2b9)](_0x4a8415)), console[_0x5baa48(0x2a1)]('[' + _0x438419[_0x5baa48(0x293)](moment)[_0x5baa48(0x2c6)](_0x438419[_0x5baa48(0x225)]) + (_0x5baa48(0x21c) + _0x5baa48(0x285)) + _0x5cb35b + ':', JSON[_0x5baa48(0x2b9)](_0x4a8415)), this[_0x5baa48(0x2c3)](_0x438419[_0x5baa48(0x1f4)], {
                'timestamp': _0x438419[_0x5baa48(0x302)](moment)[_0x5baa48(0x2c6)](_0x438419[_0x5baa48(0x225)]),
                'sn': _0x5cb35b,
                'type': _0x438419[_0x5baa48(0x240)],
                'data': _0x4a8415
            }), new Promise((_0x26be4d, _0x362ee1) => {
                const _0x19ad90 = _0x5baa48, _0xa6dcd8 = {
                        'MXuSE': function (_0x39bed6, _0x3a604c) {
                            const _0x2e881f = _0x5c67;
                            return _0x438419[_0x2e881f(0x347)](_0x39bed6, _0x3a604c);
                        },
                        'guKGt': function (_0x55d7c6, _0xf6d7e7) {
                            const _0x253323 = _0x5c67;
                            return _0x438419[_0x253323(0x347)](_0x55d7c6, _0xf6d7e7);
                        }
                    }, _0x266d1f = _0x438419[_0x19ad90(0x1e7)](setTimeout, () => {
                        const _0x9447c1 = _0x19ad90;
                        this[_0x9447c1(0x230) + _0x9447c1(0x304)][_0x9447c1(0x331)](_0x2a6ccb) && (this[_0x9447c1(0x230) + _0x9447c1(0x304)][_0x9447c1(0x26c)](_0x2a6ccb), _0x438419[_0x9447c1(0x347)](_0x362ee1, new Error(_0x9447c1(0x255) + _0x9447c1(0x32e) + _0x9447c1(0x27d) + _0x9447c1(0x2ce) + '\x20' + _0x5cb35b + (_0x9447c1(0x2c4) + _0x9447c1(0x281)) + _0x3d70c6)));
                    }, _0x4f4a79);
                this[_0x19ad90(0x230) + _0x19ad90(0x304)][_0x19ad90(0x263)](_0x2a6ccb, {
                    'resolve': _0x1e1c02 => {
                        const _0x22e1e2 = _0x19ad90;
                        _0xa6dcd8[_0x22e1e2(0x323)](clearTimeout, _0x266d1f), _0xa6dcd8[_0x22e1e2(0x323)](_0x26be4d, _0x1e1c02);
                    },
                    'reject': _0x563616 => {
                        const _0x38c38a = _0x19ad90;
                        _0xa6dcd8[_0x38c38a(0x1f5)](clearTimeout, _0x266d1f), _0xa6dcd8[_0x38c38a(0x1f5)](_0x362ee1, _0x563616);
                    }
                });
            });
        }
        console[_0x5baa48(0x2f1)]('[' + _0x438419[_0x5baa48(0x328)](moment)[_0x5baa48(0x2c6)](_0x438419[_0x5baa48(0x225)]) + _0x5baa48(0x345) + _0x5cb35b + (_0x5baa48(0x29f) + _0x5baa48(0x314) + _0x5baa48(0x243)));
        throw new Error(_0x5baa48(0x2d8) + _0x5cb35b + (_0x5baa48(0x29f) + _0x5baa48(0x314) + _0x5baa48(0x322)));
    }
    [_0x442f92(0x23e) + _0x442f92(0x2cc)](_0x6d4b78, _0x7cbf6f) {
        const _0x44ecfe = _0x442f92, _0x2958cd = {
                'Yahjq': function (_0x27528a, _0x123e40) {
                    return _0x27528a === _0x123e40;
                },
                'kgFAu': _0x44ecfe(0x2eb),
                'sqETu': function (_0x3ad012) {
                    return _0x3ad012();
                },
                'JdQnk': _0x44ecfe(0x288) + _0x44ecfe(0x291),
                'chrTq': function (_0xd70408) {
                    return _0xd70408();
                }
            }, _0xf647a1 = this[_0x44ecfe(0x253) + 'ts'][_0x44ecfe(0x308)](_0x6d4b78);
        if (_0xf647a1 && _0x2958cd[_0x44ecfe(0x2ed)](_0xf647a1[_0x44ecfe(0x2f0)], -0x199 + -0x31 * 0x23 + 0x84d))
            try {
                const _0x569cc4 = {
                    'cmd': _0x2958cd[_0x44ecfe(0x33e)],
                    'event': _0x7cbf6f[_0x44ecfe(0x21a)],
                    'sn': _0x6d4b78,
                    'data': _0x7cbf6f[_0x44ecfe(0x27f)],
                    'timestamp': _0x2958cd[_0x44ecfe(0x24e)](moment)[_0x44ecfe(0x2c6)](_0x2958cd[_0x44ecfe(0x32d)])
                };
                return _0xf647a1[_0x44ecfe(0x2d2)](JSON[_0x44ecfe(0x2b9)](_0x569cc4)), console[_0x44ecfe(0x2a1)]('[' + _0x2958cd[_0x44ecfe(0x24e)](moment)[_0x44ecfe(0x2c6)](_0x2958cd[_0x44ecfe(0x32d)]) + (_0x44ecfe(0x24b) + _0x44ecfe(0x32a) + _0x44ecfe(0x25d) + '\x20') + _0x6d4b78 + ':\x20' + _0x7cbf6f[_0x44ecfe(0x21a)]), !![];
            } catch (_0x46b062) {
                return console[_0x44ecfe(0x209)]('[' + _0x2958cd[_0x44ecfe(0x1eb)](moment)[_0x44ecfe(0x2c6)](_0x2958cd[_0x44ecfe(0x32d)]) + (_0x44ecfe(0x271) + _0x44ecfe(0x303) + _0x44ecfe(0x22b) + _0x44ecfe(0x23a)) + _0x6d4b78 + ':', _0x46b062[_0x44ecfe(0x254)]), ![];
            }
        else
            return console[_0x44ecfe(0x2a1)]('[' + _0x2958cd[_0x44ecfe(0x24e)](moment)[_0x44ecfe(0x2c6)](_0x2958cd[_0x44ecfe(0x32d)]) + (_0x44ecfe(0x207) + _0x44ecfe(0x2ec) + _0x44ecfe(0x203) + _0x44ecfe(0x1fa)) + _0x6d4b78), ![];
    }
    [_0x442f92(0x31c) + 'ge'](_0x2ded18) {
        const _0x310a8b = _0x442f92;
        return this[_0x310a8b(0x23d)][_0x310a8b(0x308)](_0x2ded18);
    }
    [_0x442f92(0x1e8) + _0x442f92(0x234)](_0xf7d14e) {
        const _0x2bd25f = _0x442f92, _0x154daa = {
                'rodFX': function (_0x4531dd, _0xaa8463) {
                    return _0x4531dd === _0xaa8463;
                },
                'wpwLo': _0x2bd25f(0x1f8),
                'lnTYX': function (_0x5943e0, _0xc1b6c0) {
                    return _0x5943e0 > _0xc1b6c0;
                },
                'thiDd': function (_0x112407, _0x5b9b84) {
                    return _0x112407 + _0x5b9b84;
                },
                'DYdRC': _0x2bd25f(0x279)
            };
        return JSON[_0x2bd25f(0x2b9)](_0xf7d14e, (_0xf31fa5, _0x12310c) => {
            const _0xe298d0 = _0x2bd25f;
            if (_0x154daa[_0xe298d0(0x290)](typeof _0x12310c, _0x154daa[_0xe298d0(0x2d1)]) && _0x154daa[_0xe298d0(0x28a)](_0x12310c[_0xe298d0(0x22c)], -0x100f * -0x1 + -0x16ef + 0x744))
                return _0x154daa[_0xe298d0(0x21f)](_0x12310c[_0xe298d0(0x30f)](0x1845 + -0x1ee * -0x9 + -0x29a3, 0xdf9 + 0x23ad + -0x3142), _0x154daa[_0xe298d0(0x1e9)]);
            return _0x12310c;
        });
    }
}
module[_0x442f92(0x29c)] = new WebSocketService();
function _0x3741() {
    const _0x55d048 = [
        'peedClient',
        'upsert',
        'rom\x20device',
        'SENT',
        '30vPtJIz',
        'wpwLo',
        'send',
        'UyPnd',
        'ection',
        'QwUse',
        'connect',
        'status',
        'Device\x20',
        'pong',
        'Verify\x20Res',
        '227864hmOLRv',
        'clientType',
        'WebSocket\x20',
        'FTucL',
        'Registered',
        'YuCBK',
        'nmIlh',
        'GSgft',
        ']\x20SpeedCli',
        '1340163ptQqNT',
        'License\x20Er',
        'WNDfI',
        'image',
        'SUCCESS',
        'remoteAddr',
        '1545940uoMjIK',
        'forward',
        'Client\x20lis',
        'Yahjq',
        'service',
        'pDlKH',
        'readyState',
        'warn',
        '\x20rejected:',
        'khzby',
        'có\x20sn,\x20đón',
        '\x20parameter',
        'or:\x20',
        'PCKsD',
        'ing\x20dead\x20c',
        'ceResponse',
        'tXOrp',
        'record',
        'RESPONSE',
        'yjlQB',
        'sage\x20',
        'then',
        'logindex',
        'FAILED',
        'XcodY',
        'rwarding\x20t',
        'uests',
        ']\x20Device\x20r',
        'sync\x20devic',
        'IOUNM',
        'get',
        'ping',
        'gkrPk',
        'includes',
        'qCbkR',
        'Response\x20n',
        'handleMess',
        'substring',
        'esponse\x20to',
        'e\x20status\x20t',
        'checkActiv',
        'mQrSc',
        '\x20or\x20not\x20co',
        'zzrTf',
        'OqkFT',
        'SpeedWsCli',
        'ftnTp',
        'Open\x20Door\x20',
        'handleConn',
        'iTLmi',
        'getFaceIma',
        'wHZgZ',
        'ted:\x20',
        'Missing\x20sn',
        'reg',
        'oOXqj',
        'nnected',
        'MXuSE',
        'speed-',
        'vBzHr',
        'zNbtT',
        'ce\x20statuse',
        'xsTDI',
        'mjtGR',
        'd\x20to\x20Speed',
        'ection\x20fro',
        'ess,\x20call\x20',
        'JdQnk',
        'iting\x20for\x20',
        'All\x20device',
        'now',
        'has',
        'ebSav',
        'Notify\x20mes',
        'random',
        'wcBQp',
        'XidMu',
        'dToDevice',
        'ERROR',
        'reset\x20devi',
        'n\x20DB:',
        'yNYbW',
        'xIZml',
        'Yneoo',
        'kgFAu',
        '204adUwwg',
        'clientId',
        'MuPbr',
        'init',
        'ceRequest',
        'Givsh',
        ']\x20Device\x20',
        'JnDKS',
        'rETrW',
        'e\x20status\x20i',
        'vWCHz',
        'handleDevi',
        'vice',
        'split',
        'socket',
        'jRCZd',
        'stringifyT',
        'DYdRC',
        'glCfa',
        'chrTq',
        ']\x20Device\x20d',
        'MvbTK',
        'rDWQk',
        'wss',
        'Verify\x20Suc',
        '\x20for\x20devic',
        'failed',
        'zVDds',
        'vHiBU',
        'guKGt',
        'Exenn',
        'vsckp',
        'string',
        '\x20message\x20:',
        '\x20device\x20',
        'zCypU',
        'DISCONNECT',
        '406385xfuytQ',
        'cVjwY',
        'syQAs',
        'NMStx',
        'jsfPI',
        'clients',
        'tening\x20for',
        'events',
        'Open\x20door\x20',
        'ted.',
        ']\x20No\x20Speed',
        'bMlWE',
        'error',
        'tInfo',
        ']\x20Received',
        'or\x20',
        'offline',
        'from\x20',
        'enrollid',
        'EYXOo',
        'pzVri',
        'RJmGI',
        'connection',
        'RsCDB',
        'vUJBf',
        'TEXDM',
        'inspector',
        'yPumu',
        'YKFxN',
        'event',
        ']\x20Connecti',
        ']\x20Command\x20',
        'for\x20',
        'NwPnH',
        'thiDd',
        'ent\x20không\x20',
        'Devices',
        'terminate',
        'eLicense',
        'jhpgG',
        'MZAhT',
        '389345UXhmzC',
        'sendlog',
        'moment',
        'ice\x20offlin',
        'VMeve',
        'o\x20SpeedCli',
        'length',
        'cmd',
        '\x20disconnec',
        'resolve',
        'pendingReq',
        'onnection\x20',
        'vqtjU',
        'QbeNU',
        'runcated',
        'RrKKh',
        'handleErro',
        'update',
        'isconnecte',
        'RECEIVED',
        'ent\x20',
        '/SpeedWsCl',
        './sun.api.',
        'faceCache',
        'forwardToS',
        'FVRrO',
        'phJyF',
        'cxBUj',
        'egistered:',
        'nnected.',
        'age',
        ']\x20New\x20conn',
        'GXSwT',
        'KwVDR',
        'niKMm',
        'ing\x20messag',
        'g\x20kết\x20nối',
        ']\x20Forwarde',
        'ent',
        'rVLeg',
        'sqETu',
        'backupnum',
        'sGfRC',
        'url',
        'rZQuk',
        'speedClien',
        'message',
        'Timeout\x20wa',
        'cnBjr',
        'forEach',
        '\x20connectio',
        ']\x20WebSocke',
        'count',
        'error\x20for\x20',
        ']\x20Message\x20',
        'Client\x20for',
        'substr',
        'NotifyMess',
        'open\x20door:',
        'ess',
        'remoteIp',
        'set',
        'Access\x20is\x20',
        '../models/',
        'mqpcs',
        'cCQFL',
        'qITlG',
        'on\x20rejecte',
        'KrKto',
        'service.js',
        'delete',
        'sendComman',
        'ent\x20connec',
        'kofxc',
        'handleClos',
        ']\x20Error\x20fo',
        'WLTGK',
        'PdpqP',
        'Error\x20pars',
        'fuqLu',
        'result',
        '30ckjVrM',
        'online',
        '...',
        'owWLP',
        'isAlive',
        '\x20from\x20',
        'response\x20f',
        'denined',
        'data',
        'JlbnI',
        'nd\x20',
        'IlCYw',
        'unknown\x20de',
        '3|5',
        'sent\x20to\x20',
        'reset\x20to\x20o',
        'toString',
        'YYYY-MM-DD',
        'd:\x20',
        'lnTYX',
        'DpDQX',
        'OPEN',
        'Verify\x20Err',
        'fQddc',
        ']\x20Terminat',
        'rodFX',
        '\x20HH:mm:ss',
        'registered',
        'fSqJK',
        'ffline.',
        'n\x20closed\x20f',
        'TBkfV',
        'sessionId',
        'parse',
        'device',
        'ror:\x20',
        'KPjlA',
        'exports',
        't\x20error:',
        'kjGDR',
        '\x20not\x20found',
        'close',
        'log',
        '32IfpDQQ',
        'tcLFZ',
        'Failed\x20to\x20',
        'success,\x20p',
        'reason',
        'CDdJW',
        '\x20(Reason:\x20',
        'senduser',
        '2564NpJmXd',
        'isValid',
        '117lbxmSK',
        'wnQOu',
        'exKIs',
        'resetAllSt',
        'speed',
        '\x20statuses\x20',
        'ogxOK',
        'catch',
        'nxHHV',
        'pZyLI',
        'pdJwD',
        'opendoor',
        '1467837CeyYsS',
        'stringify',
        'QdWWJ',
        'unknown',
        'IZwJC',
        'update\x20dev',
        './license.',
        'ost\x20notify',
        'yyHFW',
        'o\x20DB:',
        '6|2|4|1|0|',
        'emit',
        '\x20for\x20comma',
        'oUrXX',
        'format',
        'ponse\x20:\x20',
        'JjZDy',
        ']\x20Obsolete',
        'otify:',
        'atuses'
    ];
    _0x3741 = function () {
        return _0x55d048;
    };
    return _0x3741();
}