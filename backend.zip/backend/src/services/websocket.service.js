function _0x3260() {
    const _0x16a91a = [
        'ted:\x20',
        'ffline.',
        '\x20from\x20',
        ']\x20Device\x20r',
        'now',
        'clientType',
        'SUCCESS',
        '6DgSDOi',
        'rom\x20device',
        'ydXnw',
        'OSmtr',
        'sendComman',
        'DMPik',
        'g\x20kết\x20nối',
        'record',
        'iting\x20for\x20',
        'ted.',
        ',\x20Session\x20',
        '][notifydo',
        'LXsrE',
        'set',
        'DeviceRequ',
        'nnected.',
        'Timeout\x20wa',
        'ding.js',
        'handleErro',
        'BizQz',
        'PmPss',
        '...',
        'jcCho',
        'uZKtX',
        'XYZAP',
        'logindex',
        ']\x20Received',
        '\x20rejected:',
        'pong',
        'rVRQZ',
        'enrollid',
        'evice:\x20',
        'aNjqg',
        'sendlog',
        'handleMess',
        'ing\x20messag',
        'vice:\x20',
        'CHBki',
        'GoKem',
        'atuses',
        '\x20disconnec',
        'sync\x20devic',
        'error',
        'result',
        'DsYEY',
        'message',
        'data',
        'uest',
        'connection',
        'LUEkt',
        'Client\x20for',
        'cmd',
        'url',
        '3999108RAdxEd',
        'handleClos',
        ']\x20No\x20Speed',
        'speed-',
        'ection',
        'dpyOM',
        'for\x20',
        'UOuYh',
        'uOYsc',
        'EcpXC',
        'senduser',
        'mWZde',
        'delete',
        'or]\x20Device',
        'Registered',
        '][Error\x20se',
        'rwarding\x20t',
        'EHEam',
        '\x20for\x20devic',
        'registered',
        'WebSocket\x20',
        'event',
        'gqfIG',
        'QDzFR',
        '\x20not\x20found',
        '125192qANSlT',
        'PEN\x20status',
        'upsert',
        'n\x20closed\x20f',
        'boardingPa',
        'JqEhW',
        'fydoor]\x20De',
        'aiKcy',
        'ing\x20dead\x20c',
        'ent',
        'd:\x20',
        'fGjXp',
        'response\x20f',
        'notifydoor',
        'oEmsC',
        'ce:\x20',
        'ACDYC',
        'vice',
        'XYYbK',
        'peedClient',
        'send',
        '1|2|6|0|5|',
        'info',
        'rs.js',
        'ceRequest',
        'YeKLO',
        '../models/',
        'Error',
        ']\x20Device\x20',
        'uests',
        'faceCache',
        ':\x20Notify\x20s',
        'Ztpos',
        'or\x20',
        ']\x20New\x20conn',
        'device',
        'remoteIp',
        'run\x20handle',
        'resetAllSt',
        'ending]\x20Cr',
        'resolve',
        'uDJUA',
        'dFcAX',
        ',\x20Response',
        'SENT',
        'get',
        'UhNIU',
        './sun.api.',
        'oHZUe',
        'YYYY-MM-DD',
        'Missing\x20sn',
        'parse',
        'ice\x20offlin',
        'unknown',
        'hVLYN',
        'events',
        'lXIZL',
        'LdyTF',
        '\x20(Reason:\x20',
        'd\x20to\x20Speed',
        'connect',
        'zmiyn',
        'jzlKV',
        ']\x20Connecti',
        'Client\x20lis',
        'ror:\x20',
        'BVWOW',
        'warn',
        'log',
        '][Error]\x20D',
        'reason',
        'Error\x20proc',
        'substring',
        'customerNa',
        'waKzY',
        'forward',
        ']\x20SpeedCli',
        'dEiQC',
        'online',
        '][SessionP',
        'RESPONSE',
        'ceResponse',
        'md:\x20',
        'tInfo',
        'DISCONNECT',
        'EEfhM',
        'RECEIVED',
        'Failed\x20to\x20',
        'service',
        'có\x20sn,\x20đón',
        '\x20for\x20comma',
        'e\x20status\x20t',
        'socket',
        ']\x20Forwarde',
        't\x20error:',
        ',\x20Error:\x20',
        'exports',
        'wss',
        'OPEN',
        ']\x20Obsolete',
        'lPVju',
        '/SpeedWsCl',
        'zmjJc',
        'service.js',
        'o\x20SpeedCli',
        '][verifyAP',
        './LogHelpe',
        ']\x20Error\x20fo',
        'PtiJc',
        'WAeer',
        'yinoU',
        'eLicense',
        'CEmDr',
        'ID:\x20',
        'checkActiv',
        'sRJiE',
        'noyzm',
        '[handleDev',
        'haEnJ',
        'image',
        'esponse\x20to',
        'onnection\x20',
        'uxqwt',
        'ULkzt',
        'fBdoC',
        'vFPpz',
        'I]\x20Device:',
        'has',
        'ess',
        'Device\x20',
        'dzTBr',
        'error\x20for\x20',
        'DzrPs',
        'emit',
        'XqYPv',
        ']\x20WebSocke',
        'eCfIN',
        'string',
        'stringifyT',
        'ent\x20with\x20O',
        '1213156kpjwrK',
        'update',
        'JUKmz',
        'nbCVP',
        'ZtmRh',
        'FAILED',
        '\x20HH:mm:ss',
        'dToDevice',
        'ufvBd',
        'USwQd',
        'o\x20DB:',
        'Budhb',
        'tening\x20for',
        'create',
        'n\x20DB:',
        'JsAIc',
        'getFaceIma',
        'lFIqY',
        './license.',
        'readyState',
        'reg',
        'rJKjX',
        'runcated',
        'moment',
        'title',
        'on\x20rejecte',
        'offline',
        'close',
        'reset\x20devi',
        'KHYLt',
        'includes',
        'All\x20device',
        'YBceh',
        './logs',
        'terminate',
        'ection\x20fro',
        'init',
        'nding\x20noti',
        'ing\x20sessio',
        'format',
        'ce\x20statuse',
        '\x20parameter',
        'handleDevi',
        '2338325eIclTf',
        'age',
        'EzrdS',
        'eated\x20pend',
        'gMiuI',
        'ping',
        'stringify',
        'isValid',
        'QPhWD',
        'sessionpen',
        'fehog',
        ']\x20Device\x20d',
        'SpeedWsCli',
        'est\x20with\x20c',
        'HabKq',
        '4|3',
        'XrGPH',
        '\x20connectio',
        'NqiAI',
        'kdRnz',
        'handleConn',
        'wFVzI',
        'isconnecte',
        'forwardToS',
        'License\x20Er',
        'update\x20dev',
        'from\x20',
        'oDaqo',
        'length',
        'sessionId',
        'Error\x20pars',
        'NTMtw',
        'split',
        'e\x20status\x20i',
        'forEach',
        'essing\x20req',
        '\x20or\x20not\x20co',
        '\x20statuses\x20',
        'clients',
        'tdJVo',
        'speed',
        'substr',
        'egistered:',
        'ENriv',
        'isAlive',
        ']\x20Terminat',
        'tvVjK',
        'backupnum',
        'joWsD',
        'nSnig',
        'clientId',
        'pendingReq',
        'toString',
        'remoteAddr',
        'SUXqM',
        'RQKLq',
        'reset\x20to\x20o',
        'Devices',
        'lHUwF',
        '1400980abJOsp',
        'iceRequest',
        'nzbbx',
        'CKIkb',
        'ent\x20connec',
        '\x20device\x20',
        'ERROR',
        'ent\x20',
        'unknown\x20de',
        'ohpjr',
        'VOfMx',
        ']\x20Message\x20',
        '3129618VpvDlG',
        'ZHaWC',
        'random',
        'eGtbK',
        'kJqGr',
        'nd\x20',
        'speedClien',
        'ent\x20không\x20',
        'count',
        ']\x20Command\x20',
        'status',
        'sent\x20to\x20',
        'nnected',
        'PAmlw',
        'n\x20for\x20Devi',
        '12477832kmYRrr'
    ];
    _0x3260 = function () {
        return _0x16a91a;
    };
    return _0x3260();
}
function _0x121e(_0x62bbbd, _0x1d0e9c) {
    _0x62bbbd = _0x62bbbd - (-0xec * 0x1 + 0x1429 + -0x119c);
    const _0x24aaf1 = _0x3260();
    let _0x3ab99d = _0x24aaf1[_0x62bbbd];
    return _0x3ab99d;
}
const _0x14d53f = _0x121e;
(function (_0x534279, _0x50d7c1) {
    const _0x524be5 = _0x121e, _0x1e9166 = _0x534279();
    while (!![]) {
        try {
            const _0x777ba5 = parseInt(_0x524be5(0x1aa)) / (0xd * -0x10a + -0x117 * 0x9 + 0x3 * 0x7c6) + parseInt(_0x524be5(0x281)) / (-0x11 * 0x1b4 + -0xb64 + -0x812 * -0x5) * (-parseInt(_0x524be5(0x233)) / (-0x69c + -0xf1a + 0x43 * 0x53)) + parseInt(_0x524be5(0x268)) / (-0x242 + -0xf4c + 0x1192) + -parseInt(_0x524be5(0x1d5)) / (-0xe75 + 0x1 * -0x2666 + 0x34e0) + parseInt(_0x524be5(0x21c)) / (-0xced + 0x1 * -0x19a9 + -0x2 * -0x134e) + parseInt(_0x524be5(0x210)) / (0xb * 0xdb + -0x4 * 0x600 + 0xe9e * 0x1) + -parseInt(_0x524be5(0x22b)) / (0x509 * 0x2 + -0x172 * 0x14 + 0x12de);
            if (_0x777ba5 === _0x50d7c1)
                break;
            else
                _0x1e9166['push'](_0x1e9166['shift']());
        } catch (_0x51f1c7) {
            _0x1e9166['push'](_0x1e9166['shift']());
        }
    }
}(_0x3260, -0x35562 * 0x2 + 0xd7469 * -0x1 + 0x2ea05 * 0xb));
const moment = require(_0x14d53f(0x1c1)), Device = require(_0x14d53f(0x29b) + _0x14d53f(0x2a4)), EventEmitter = require(_0x14d53f(0x2b8)), {callVerifyAPI, callNotifyMessage} = require(_0x14d53f(0x2b0) + _0x14d53f(0x2e8)), LicenseService = require(_0x14d53f(0x1bc) + _0x14d53f(0x2d9)), SessionPending = require(_0x14d53f(0x29b) + _0x14d53f(0x1de) + _0x14d53f(0x244)), {getLogger} = require(_0x14d53f(0x2eb) + _0x14d53f(0x298)), logger = getLogger({
        'logDir': _0x14d53f(0x1cb),
        'maxLogDays': 0x7,
        'dateFormat': _0x14d53f(0x2b2),
        'logFormat': _0x14d53f(0x2b2) + _0x14d53f(0x1b0)
    });
class WebSocketService extends EventEmitter {
    constructor() {
        const _0x3b10cf = _0x14d53f, _0x5e0413 = { 'SUXqM': _0x3b10cf(0x296) + _0x3b10cf(0x1e4) }, _0x1aa634 = _0x5e0413[_0x3b10cf(0x20b)][_0x3b10cf(0x1f5)]('|');
        let _0x81f873 = -0x15b * -0xd + 0x5 * -0x5f3 + 0x1 * 0xc20;
        while (!![]) {
            switch (_0x1aa634[_0x81f873++]) {
            case '0':
                this[_0x3b10cf(0x222) + _0x3b10cf(0x2d4)] = new Map();
                continue;
            case '1':
                super();
                continue;
            case '2':
                this[_0x3b10cf(0x27b) + _0x3b10cf(0x20e)] = new Map();
                continue;
            case '3':
                this[_0x3b10cf(0x2e2)] = null;
                continue;
            case '4':
                this[_0x3b10cf(0x208) + _0x3b10cf(0x29e)] = new Map();
                continue;
            case '5':
                this[_0x3b10cf(0x29f)] = new Map();
                continue;
            case '6':
                this[_0x3b10cf(0x222) + 'ts'] = new Map();
                continue;
            }
            break;
        }
    }
    [_0x14d53f(0x1ce)](_0x3e0a2d) {
        const _0xe203be = _0x14d53f, _0x36892c = {
                'ydXnw': function (_0x4b4c83, _0x1f26ec) {
                    return _0x4b4c83 === _0x1f26ec;
                },
                'GoKem': function (_0x258e10) {
                    return _0x258e10();
                },
                'EHEam': _0xe203be(0x2b2) + _0xe203be(0x1b0),
                'rVRQZ': _0xe203be(0x2b6),
                'jzlKV': _0xe203be(0x263),
                'zmjJc': function (_0x309e74, _0x2e3b0f, _0x1225ba) {
                    return _0x309e74(_0x2e3b0f, _0x1225ba);
                },
                'gqfIG': _0xe203be(0x1c5)
            };
        this[_0xe203be(0x2e2)] = _0x3e0a2d, this[_0xe203be(0x2e2)]['on'](_0x36892c[_0xe203be(0x2bf)], (_0x223607, _0x459e70) => this[_0xe203be(0x1e9) + _0xe203be(0x26c)](_0x223607, _0x459e70));
        const _0x33e343 = _0x36892c[_0xe203be(0x2e7)](setInterval, () => {
            const _0x3820c7 = _0xe203be, _0x44b395 = {
                    'WAeer': function (_0x31520b, _0x112788) {
                        const _0x287e0e = _0x121e;
                        return _0x36892c[_0x287e0e(0x235)](_0x31520b, _0x112788);
                    },
                    'LUEkt': function (_0x4d7aaf) {
                        const _0x3186c1 = _0x121e;
                        return _0x36892c[_0x3186c1(0x259)](_0x4d7aaf);
                    },
                    'dzTBr': _0x36892c[_0x3820c7(0x279)],
                    'USwQd': _0x36892c[_0x3820c7(0x250)]
                };
            this[_0x3820c7(0x2e2)][_0x3820c7(0x1fb)][_0x3820c7(0x1f7)](_0x3038c5 => {
                const _0x20d7ea = _0x3820c7;
                if (_0x44b395[_0x20d7ea(0x2ee)](_0x3038c5[_0x20d7ea(0x201)], ![]))
                    return console[_0x20d7ea(0x2c5)]('[' + _0x44b395[_0x20d7ea(0x264)](moment)[_0x20d7ea(0x1d1)](_0x44b395[_0x20d7ea(0x303)]) + (_0x20d7ea(0x202) + _0x20d7ea(0x289) + _0x20d7ea(0x2fa) + _0x20d7ea(0x26e)) + (_0x3038c5['sn'] || _0x44b395[_0x20d7ea(0x1b3)])), _0x3038c5[_0x20d7ea(0x1cc)]();
                _0x3038c5[_0x20d7ea(0x201)] = ![], _0x3038c5[_0x20d7ea(0x1da)]();
            });
        }, -0x4 * 0x2b5a + 0x137 * 0x5 + 0x11c85);
        this[_0xe203be(0x2e2)]['on'](_0x36892c[_0xe203be(0x27e)], () => clearInterval(_0x33e343));
    }
    async [_0x14d53f(0x2a7) + _0x14d53f(0x25a)]() {
        const _0x476af9 = _0x14d53f, _0x38e828 = {
                'aNjqg': _0x476af9(0x1c4),
                'nzbbx': _0x476af9(0x1c9) + _0x476af9(0x1fa) + _0x476af9(0x20d) + _0x476af9(0x22d),
                'wFVzI': _0x476af9(0x2d8) + _0x476af9(0x1c6) + _0x476af9(0x1d2) + 's:'
            };
        try {
            await Device[_0x476af9(0x1ab)]({ 'status': _0x38e828[_0x476af9(0x253)] }, { 'where': {} }), console[_0x476af9(0x2c5)](_0x38e828[_0x476af9(0x212)]);
        } catch (_0x108516) {
            console[_0x476af9(0x25d)](_0x38e828[_0x476af9(0x1ea)], _0x108516[_0x476af9(0x260)]);
        }
    }
    async [_0x14d53f(0x1e9) + _0x14d53f(0x26c)](_0x19f698, _0x2898a9) {
        const _0x40cab3 = _0x14d53f, _0x2715e8 = {
                'UhNIU': function (_0x202d61) {
                    return _0x202d61();
                },
                'XYYbK': _0x40cab3(0x2b2) + _0x40cab3(0x1b0),
                'lPVju': _0x40cab3(0x2e6) + 'i',
                'ZtmRh': _0x40cab3(0x1fd),
                'EEfhM': _0x40cab3(0x207),
                'fBdoC': _0x40cab3(0x2b3) + _0x40cab3(0x1d3),
                'JUKmz': _0x40cab3(0x1e1) + _0x40cab3(0x28a),
                'PAmlw': _0x40cab3(0x2bd),
                'CKIkb': function (_0x27aace) {
                    return _0x27aace();
                },
                'DzrPs': _0x40cab3(0x2a4),
                'oEmsC': function (_0x16ad40) {
                    return _0x16ad40();
                },
                'LdyTF': _0x40cab3(0x24f),
                'CEmDr': _0x40cab3(0x260),
                'QDzFR': _0x40cab3(0x1c5),
                'YBceh': _0x40cab3(0x25d)
            }, _0x8f8b11 = await LicenseService[_0x40cab3(0x2f3) + _0x40cab3(0x2f0)]();
        if (!_0x8f8b11[_0x40cab3(0x1dc)]) {
            console[_0x40cab3(0x2c5)]('[' + _0x2715e8[_0x40cab3(0x2af)](moment)[_0x40cab3(0x1d1)](_0x2715e8[_0x40cab3(0x293)]) + (_0x40cab3(0x2c0) + _0x40cab3(0x1c3) + _0x40cab3(0x28b)) + _0x8f8b11[_0x40cab3(0x25d)]), _0x19f698[_0x40cab3(0x1c5)](0x1 * -0x212b + 0xbeb + 0x1930 * 0x1, _0x40cab3(0x1ed) + _0x40cab3(0x2c2) + _0x8f8b11[_0x40cab3(0x25d)]);
            return;
        }
        const _0x417531 = _0x2898a9[_0x40cab3(0x2dd)][_0x40cab3(0x20a) + _0x40cab3(0x301)];
        _0x19f698[_0x40cab3(0x2a5)] = _0x417531, _0x19f698[_0x40cab3(0x201)] = !![];
        if (_0x2898a9[_0x40cab3(0x267)][_0x40cab3(0x1c8)](_0x2715e8[_0x40cab3(0x2e5)])) {
            _0x19f698[_0x40cab3(0x231)] = _0x2715e8[_0x40cab3(0x1ae)];
            const _0x21ec54 = _0x2898a9[_0x40cab3(0x267)][_0x40cab3(0x1f5)]('?'), _0x19406b = new URLSearchParams(_0x21ec54[0xf9 * -0x1f + -0x339 + 0x1 * 0x2161] || ''), _0x781321 = _0x19406b[_0x40cab3(0x2ae)]('sn'), _0x408722 = _0x19406b[_0x40cab3(0x2ae)](_0x2715e8[_0x40cab3(0x2d6)]) || _0x40cab3(0x26b) + Date[_0x40cab3(0x230)]() + '-' + Math[_0x40cab3(0x21e)]()[_0x40cab3(0x209)](-0x250b + -0x23d6 + 0x3 * 0x1857)[_0x40cab3(0x1fe)](0x121f + 0x11b * 0x3 + -0x156e * 0x1, -0x42 * 0x7c + -0x1889 + 0x388a);
            if (!_0x781321) {
                console[_0x40cab3(0x2c5)]('[' + _0x2715e8[_0x40cab3(0x2af)](moment)[_0x40cab3(0x1d1)](_0x2715e8[_0x40cab3(0x293)]) + (_0x40cab3(0x2cd) + _0x40cab3(0x223) + _0x40cab3(0x2da) + _0x40cab3(0x239))), _0x19f698[_0x40cab3(0x1c5)](-0x169d + 0x1faa + 0x77 * -0xb, _0x2715e8[_0x40cab3(0x2fd)]);
                return;
            }
            _0x19f698[_0x40cab3(0x231)] = _0x2715e8[_0x40cab3(0x1ae)], _0x19f698['sn'] = _0x781321, _0x19f698[_0x40cab3(0x207)] = _0x408722, this[_0x40cab3(0x222) + 'ts'][_0x40cab3(0x240)](_0x781321, _0x19f698), this[_0x40cab3(0x222) + _0x40cab3(0x2d4)][_0x40cab3(0x240)](_0x19f698, {
                'clientId': _0x408722,
                'sn': _0x781321,
                'connectedAt': new Date()
            }), console[_0x40cab3(0x2c5)]('[' + _0x2715e8[_0x40cab3(0x2af)](moment)[_0x40cab3(0x1d1)](_0x2715e8[_0x40cab3(0x293)]) + (_0x40cab3(0x2cd) + _0x40cab3(0x214) + _0x40cab3(0x22c)) + _0x408722 + (_0x40cab3(0x27a) + 'e\x20') + _0x781321 + _0x40cab3(0x22e) + _0x417531), _0x19f698[_0x40cab3(0x295)](JSON[_0x40cab3(0x1db)]({
                'cmd': _0x2715e8[_0x40cab3(0x1ac)],
                'ret': _0x2715e8[_0x40cab3(0x229)],
                'result': !![],
                'sn': _0x781321,
                'clientId': _0x408722,
                'message': _0x40cab3(0x276) + _0x40cab3(0x27a) + 'e\x20' + _0x781321,
                'timestamp': _0x2715e8[_0x40cab3(0x213)](moment)[_0x40cab3(0x1d1)](_0x2715e8[_0x40cab3(0x293)])
            }));
        } else
            _0x19f698[_0x40cab3(0x231)] = _0x2715e8[_0x40cab3(0x1a2)];
        console[_0x40cab3(0x2c5)]('[' + _0x2715e8[_0x40cab3(0x28f)](moment)[_0x40cab3(0x1d1)](_0x2715e8[_0x40cab3(0x293)]) + (_0x40cab3(0x2a3) + _0x40cab3(0x1cd) + 'm\x20') + _0x417531), _0x19f698['on'](_0x2715e8[_0x40cab3(0x2ba)], () => {
            const _0x59d45d = _0x40cab3;
            _0x19f698[_0x59d45d(0x201)] = !![];
        }), _0x19f698['on'](_0x2715e8[_0x40cab3(0x2f1)], _0x4f4d91 => this[_0x40cab3(0x255) + _0x40cab3(0x1d6)](_0x19f698, _0x4f4d91)), _0x19f698['on'](_0x2715e8[_0x40cab3(0x27f)], () => this[_0x40cab3(0x269) + 'e'](_0x19f698)), _0x19f698['on'](_0x2715e8[_0x40cab3(0x1ca)], _0x460dc9 => this[_0x40cab3(0x245) + 'r'](_0x19f698, _0x460dc9));
    }
    async [_0x14d53f(0x255) + _0x14d53f(0x1d6)](_0x15efb0, _0x248ccf) {
        const _0x59b937 = _0x14d53f, _0x266409 = {
                'eGtbK': function (_0xf360) {
                    return _0xf360();
                },
                'jcCho': _0x59b937(0x2b2) + _0x59b937(0x1b0),
                'VOfMx': _0x59b937(0x2b6),
                'XqYPv': function (_0x4f66ea, _0xdd990d) {
                    return _0x4f66ea === _0xdd990d;
                },
                'PtiJc': _0x59b937(0x1fd),
                'fGjXp': _0x59b937(0x218) + _0x59b937(0x292),
                'ZHaWC': _0x59b937(0x2c5),
                'BVWOW': function (_0x133a68) {
                    return _0x133a68();
                },
                'kJqGr': _0x59b937(0x2d7),
                'hVLYN': _0x59b937(0x1e1) + _0x59b937(0x28a),
                'CHBki': _0x59b937(0x1f3) + _0x59b937(0x256) + 'e:'
            };
        try {
            const _0x54945b = await LicenseService[_0x59b937(0x2f3) + _0x59b937(0x2f0)]();
            if (!_0x54945b[_0x59b937(0x1dc)]) {
                console[_0x59b937(0x2c5)]('[' + _0x266409[_0x59b937(0x21f)](moment)[_0x59b937(0x1d1)](_0x266409[_0x59b937(0x249)]) + (_0x59b937(0x21b) + _0x59b937(0x1ef)) + (_0x15efb0['sn'] || _0x266409[_0x59b937(0x21a)]) + (_0x59b937(0x24e) + '\x20') + _0x54945b[_0x59b937(0x25d)]), _0x15efb0[_0x59b937(0x1c5)](0x239f + 0x128a * -0x1 + -0xd25, _0x59b937(0x1ed) + _0x59b937(0x2c2) + _0x54945b[_0x59b937(0x25d)]);
                return;
            }
            const _0x7a4e72 = _0x248ccf[_0x59b937(0x209)](), _0x16cdd1 = JSON[_0x59b937(0x2b4)](_0x7a4e72), {
                    cmd: _0x5d10d6,
                    ret: _0x5ccbc5
                } = _0x16cdd1, _0x9dc537 = _0x266409[_0x59b937(0x1a4)](_0x15efb0[_0x59b937(0x231)], _0x266409[_0x59b937(0x2ed)]) ? _0x15efb0[_0x59b937(0x207)] + '\x20(' + _0x15efb0['sn'] + ')' : _0x15efb0['sn'] || _0x266409[_0x59b937(0x28c)];
            console[_0x59b937(0x2c5)]('[' + _0x266409[_0x59b937(0x21f)](moment)[_0x59b937(0x1d1)](_0x266409[_0x59b937(0x249)]) + (_0x59b937(0x24d) + _0x59b937(0x22e)) + _0x15efb0[_0x59b937(0x231)] + '\x20' + _0x9dc537 + ':', this[_0x59b937(0x1a8) + _0x59b937(0x1c0)](_0x16cdd1)), this[_0x59b937(0x1a3)](_0x266409[_0x59b937(0x21d)], {
                'timestamp': _0x266409[_0x59b937(0x2c3)](moment)[_0x59b937(0x1d1)](_0x266409[_0x59b937(0x249)]),
                'sn': _0x15efb0['sn'],
                'clientId': _0x15efb0[_0x59b937(0x207)],
                'clientType': _0x15efb0[_0x59b937(0x231)],
                'sn': _0x15efb0['sn'],
                'type': _0x266409[_0x59b937(0x220)],
                'data': _0x16cdd1
            });
            if (_0x266409[_0x59b937(0x1a4)](_0x5d10d6, _0x266409[_0x59b937(0x2b7)])) {
            } else {
                if (_0x5d10d6)
                    this[_0x59b937(0x1d4) + _0x59b937(0x299)](_0x15efb0, _0x5d10d6, _0x16cdd1);
                else
                    _0x5ccbc5 && this[_0x59b937(0x1d4) + _0x59b937(0x2d2)](_0x15efb0, _0x5ccbc5, _0x16cdd1);
            }
        } catch (_0x3703f4) {
            console[_0x59b937(0x25d)](_0x266409[_0x59b937(0x258)], _0x3703f4[_0x59b937(0x260)]);
        }
    }
    async [_0x14d53f(0x1d4) + _0x14d53f(0x299)](_0x30f4d0, _0x1d7b72, _0x50115e) {
        const _0x1ea665 = _0x14d53f, _0x2e89c7 = {
                'uZKtX': function (_0x292973, _0x1d8c64) {
                    return _0x292973 + _0x1d8c64;
                },
                'nSnig': _0x1ea665(0x2a6) + _0x1ea665(0x241) + _0x1ea665(0x1e2) + _0x1ea665(0x2d3),
                'YeKLO': _0x1ea665(0x2cf),
                'zmiyn': _0x1ea665(0x2d8) + _0x1ea665(0x25c) + _0x1ea665(0x2dc) + _0x1ea665(0x1b4),
                'PmPss': _0x1ea665(0x1be),
                'joWsD': function (_0x40e516) {
                    return _0x40e516();
                },
                'tdJVo': _0x1ea665(0x2b2) + _0x1ea665(0x1b0),
                'UOuYh': function (_0x59d351) {
                    return _0x59d351();
                },
                'uOYsc': _0x1ea665(0x254),
                'NqiAI': function (_0xd16806, _0x5d3e42) {
                    return _0xd16806 > _0x5d3e42;
                },
                'BizQz': function (_0x5aada3, _0x29c7b6, _0x460889) {
                    return _0x5aada3(_0x29c7b6, _0x460889);
                },
                'EcpXC': function (_0x70da66, _0x55d88f) {
                    return _0x70da66 === _0x55d88f;
                },
                'Budhb': _0x1ea665(0x2e3),
                'HabKq': _0x1ea665(0x28e),
                'DsYEY': _0x1ea665(0x2c8) + _0x1ea665(0x1f8) + _0x1ea665(0x262),
                'noyzm': _0x1ea665(0x29c),
                'waKzY': _0x1ea665(0x272)
            };
        console[_0x1ea665(0x2c5)](_0x2e89c7[_0x1ea665(0x24a)](_0x2e89c7[_0x1ea665(0x206)], _0x1d7b72));
        const _0x2712b7 = _0x50115e['sn'];
        this[_0x1ea665(0x27b) + _0x1ea665(0x20e)][_0x1ea665(0x240)](_0x2712b7, _0x30f4d0), _0x30f4d0['sn'] = _0x2712b7;
        try {
            await Device[_0x1ea665(0x283)]({
                'sn': _0x2712b7,
                'status': _0x2e89c7[_0x1ea665(0x29a)],
                'last_seen': new Date(),
                'ip_address': _0x30f4d0[_0x1ea665(0x2a5)]
            });
        } catch (_0x46d792) {
            console[_0x1ea665(0x25d)](_0x2e89c7[_0x1ea665(0x2be)], _0x46d792[_0x1ea665(0x260)]);
        }
        switch (_0x1d7b72) {
        case _0x2e89c7[_0x1ea665(0x247)]:
            _0x30f4d0[_0x1ea665(0x295)](JSON[_0x1ea665(0x1db)]({
                'ret': _0x2e89c7[_0x1ea665(0x247)],
                'result': !![],
                'cloudtime': _0x2e89c7[_0x1ea665(0x205)](moment)[_0x1ea665(0x1d1)](_0x2e89c7[_0x1ea665(0x1fc)]),
                'nosenduser': ![]
            })), console[_0x1ea665(0x2c5)]('[' + _0x2e89c7[_0x1ea665(0x26f)](moment)[_0x1ea665(0x1d1)](_0x2e89c7[_0x1ea665(0x1fc)]) + (_0x1ea665(0x22f) + _0x1ea665(0x1ff) + '\x20') + _0x2712b7);
            break;
        case _0x2e89c7[_0x1ea665(0x270)]:
            const _0x34fae8 = _0x50115e[_0x1ea665(0x224)] || -0x15f2 + 0x189d + -0x2ab, _0x51927a = _0x50115e[_0x1ea665(0x24c)] || 0x577 + 0x233 + -0x7aa;
            _0x50115e[_0x1ea665(0x23a)] && _0x2e89c7[_0x1ea665(0x1e7)](_0x50115e[_0x1ea665(0x23a)][_0x1ea665(0x1f1)], 0x4ca * -0x6 + 0x79 * 0x35 + 0x3af) && _0x50115e[_0x1ea665(0x23a)][-0xd7 + -0x2240 + -0x2317 * -0x1][_0x1ea665(0x2f8)] && this[_0x1ea665(0x29f)][_0x1ea665(0x240)](_0x50115e['sn'] || _0x30f4d0['sn'], _0x50115e[_0x1ea665(0x23a)][0x215 * -0x5 + -0xe * 0x1b1 + 0x2217][_0x1ea665(0x2f8)]);
            try {
                const _0x5c62cb = await _0x2e89c7[_0x1ea665(0x246)](callVerifyAPI, _0x50115e[_0x1ea665(0x23a)][0x1623 + 0xde * -0x19 + -0x75][_0x1ea665(0x2f8)], _0x50115e['sn']);
                logger[_0x1ea665(0x297)](_0x1ea665(0x2f6) + _0x1ea665(0x211) + _0x1ea665(0x2ea) + _0x1ea665(0x2ff) + '\x20' + _0x50115e['sn'] + (_0x1ea665(0x2ac) + ':\x20') + JSON[_0x1ea665(0x1db)](_0x5c62cb)), _0x2e89c7[_0x1ea665(0x271)](_0x5c62cb[_0x1ea665(0x226)], _0x2e89c7[_0x1ea665(0x1b5)]) ? (this[_0x1ea665(0x237) + _0x1ea665(0x1b1)](_0x30f4d0['sn'], {
                    'cmd': _0x2e89c7[_0x1ea665(0x1e3)],
                    'result': !![],
                    'doornum': 0x1,
                    'boardingPass': _0x5c62cb[_0x1ea665(0x285) + 'ss'],
                    'title': _0x5c62cb[_0x1ea665(0x1c2)],
                    'message': _0x5c62cb[_0x1ea665(0x260)],
                    'customerName': _0x5c62cb[_0x1ea665(0x2ca) + 'me']
                }), logger[_0x1ea665(0x297)](_0x1ea665(0x2f6) + _0x1ea665(0x211) + _0x1ea665(0x23e) + _0x1ea665(0x275) + ':\x20' + _0x50115e['sn'] + (_0x1ea665(0x2ac) + _0x1ea665(0x2a0) + _0x1ea665(0x1a9) + _0x1ea665(0x282))), SessionPending[_0x1ea665(0x1b7)]({
                    'sessionId': _0x5c62cb[_0x1ea665(0x1f2)],
                    'status': 0x0,
                    'sn': _0x50115e['sn'],
                    'boardingPass': _0x5c62cb[_0x1ea665(0x285) + 'ss']
                }), logger[_0x1ea665(0x297)](_0x1ea665(0x2f6) + _0x1ea665(0x211) + _0x1ea665(0x2d0) + _0x1ea665(0x2a8) + _0x1ea665(0x1d8) + _0x1ea665(0x1d0) + _0x1ea665(0x22a) + _0x1ea665(0x290) + _0x50115e['sn'] + (_0x1ea665(0x23d) + _0x1ea665(0x2f2)) + _0x5c62cb[_0x1ea665(0x1f2)])) : await this[_0x1ea665(0x237) + _0x1ea665(0x1b1)](_0x30f4d0['sn'], {
                    'cmd': _0x2e89c7[_0x1ea665(0x1e3)],
                    'result': ![],
                    'doornum': 0x1,
                    'boardingPass': _0x5c62cb[_0x1ea665(0x285) + 'ss'],
                    'title': _0x5c62cb[_0x1ea665(0x1c2)],
                    'message': _0x5c62cb[_0x1ea665(0x260)],
                    'customerName': _0x5c62cb[_0x1ea665(0x2ca) + 'me']
                });
            } catch (_0x1f5d46) {
                logger[_0x1ea665(0x25d)](_0x1ea665(0x2f6) + _0x1ea665(0x211) + _0x1ea665(0x2c6) + _0x1ea665(0x252) + _0x50115e['sn'] + _0x1ea665(0x2e0) + _0x1f5d46[_0x1ea665(0x260)]);
                try {
                    await this[_0x1ea665(0x237) + _0x1ea665(0x1b1)](_0x50115e['sn'], {
                        'cmd': _0x2e89c7[_0x1ea665(0x1e3)],
                        'result': ![],
                        'doornum': 0x1,
                        'message': _0x2e89c7[_0x1ea665(0x25f)],
                        'title': _0x2e89c7[_0x1ea665(0x2f5)],
                        'customerName': ''
                    });
                } catch (_0x3964ae) {
                    logger[_0x1ea665(0x25d)](_0x1ea665(0x2f6) + _0x1ea665(0x211) + _0x1ea665(0x277) + _0x1ea665(0x1cf) + _0x1ea665(0x287) + _0x1ea665(0x257) + _0x50115e['sn'] + _0x1ea665(0x2e0) + _0x3964ae[_0x1ea665(0x260)]);
                }
            }
            _0x30f4d0[_0x1ea665(0x295)](JSON[_0x1ea665(0x1db)]({
                'ret': _0x2e89c7[_0x1ea665(0x270)],
                'result': !![],
                'count': _0x34fae8,
                'logindex': _0x51927a,
                'cloudtime': _0x2e89c7[_0x1ea665(0x26f)](moment)[_0x1ea665(0x1d1)](_0x2e89c7[_0x1ea665(0x1fc)]),
                'access': 0x1
            }));
            break;
        case _0x2e89c7[_0x1ea665(0x2cb)]:
            _0x50115e[_0x1ea665(0x23a)] && this[_0x1ea665(0x29f)][_0x1ea665(0x240)](_0x50115e['sn'] || _0x30f4d0['sn'], _0x50115e[_0x1ea665(0x23a)]);
            _0x30f4d0[_0x1ea665(0x295)](JSON[_0x1ea665(0x1db)]({
                'ret': _0x2e89c7[_0x1ea665(0x2cb)],
                'result': !![],
                'enrollid': _0x50115e[_0x1ea665(0x251)],
                'backupnum': _0x50115e[_0x1ea665(0x204)]
            }));
            break;
        }
    }
    [_0x14d53f(0x1d4) + _0x14d53f(0x2d2)](_0x8837c3, _0x130dc9, _0x24370b) {
        const _0xd239dd = _0x14d53f, _0xcbecd0 = {
                'ufvBd': _0xd239dd(0x232),
                'oHZUe': _0xd239dd(0x1af),
                'EzrdS': function (_0xdf3451) {
                    return _0xdf3451();
                },
                'yinoU': _0xd239dd(0x2b2) + _0xd239dd(0x1b0),
                'haEnJ': _0xd239dd(0x2c5),
                'lFIqY': function (_0x4a18cb) {
                    return _0x4a18cb();
                },
                'fehog': _0xd239dd(0x2d1)
            }, _0x45a46a = _0x24370b[_0xd239dd(0x25e)] ? _0xcbecd0[_0xd239dd(0x1b2)] : _0xcbecd0[_0xd239dd(0x2b1)], _0x2b55ef = _0x24370b[_0xd239dd(0x2c7)] ? _0xd239dd(0x2bb) + _0x24370b[_0xd239dd(0x2c7)] + ')' : '';
        console[_0xd239dd(0x2c5)]('[' + _0xcbecd0[_0xd239dd(0x1d7)](moment)[_0xd239dd(0x1d1)](_0xcbecd0[_0xd239dd(0x2ef)]) + (_0xd239dd(0x22f) + _0xd239dd(0x2f9) + '\x20') + _0x130dc9 + ':\x20' + _0x45a46a + _0x2b55ef);
        if (_0x8837c3['sn']) {
            const _0x5cd9bf = _0x8837c3['sn'] + ':' + _0x130dc9, _0x1574f4 = this[_0xd239dd(0x208) + _0xd239dd(0x29e)][_0xd239dd(0x2ae)](_0x5cd9bf);
            _0x1574f4 && (_0x1574f4[_0xd239dd(0x2a9)](_0x24370b), this[_0xd239dd(0x208) + _0xd239dd(0x29e)][_0xd239dd(0x274)](_0x5cd9bf));
        }
        this[_0xd239dd(0x1a3)](_0xcbecd0[_0xd239dd(0x2f7)], {
            'timestamp': _0xcbecd0[_0xd239dd(0x1bb)](moment)[_0xd239dd(0x1d1)](_0xcbecd0[_0xd239dd(0x2ef)]),
            'sn': _0x8837c3['sn'],
            'type': _0xcbecd0[_0xd239dd(0x1df)],
            'command': _0x130dc9,
            'result': _0x45a46a,
            'reason': _0x2b55ef,
            'data': _0x24370b
        });
    }
    async [_0x14d53f(0x269) + 'e'](_0x326f70) {
        const _0x18a92b = _0x14d53f, _0x15b72d = {
                'DMPik': _0x18a92b(0x2c5),
                'OSmtr': function (_0x47b2c6) {
                    return _0x47b2c6();
                },
                'XYZAP': _0x18a92b(0x2b2) + _0x18a92b(0x1b0),
                'QPhWD': _0x18a92b(0x2d5) + 'ED',
                'dEiQC': function (_0x2b13e0, _0x479821) {
                    return _0x2b13e0 === _0x479821;
                },
                'lXIZL': _0x18a92b(0x1c4),
                'mWZde': _0x18a92b(0x2d8) + _0x18a92b(0x1ee) + _0x18a92b(0x2b5) + _0x18a92b(0x1f6) + _0x18a92b(0x1b8),
                'rJKjX': function (_0x4edf83) {
                    return _0x4edf83();
                }
            };
        if (_0x326f70['sn']) {
            this[_0x18a92b(0x1a3)](_0x15b72d[_0x18a92b(0x238)], {
                'timestamp': _0x15b72d[_0x18a92b(0x236)](moment)[_0x18a92b(0x1d1)](_0x15b72d[_0x18a92b(0x24b)]),
                'sn': _0x326f70['sn'],
                'type': _0x15b72d[_0x18a92b(0x1dd)],
                'message': _0x18a92b(0x302) + _0x326f70['sn'] + (_0x18a92b(0x25b) + _0x18a92b(0x23c))
            });
            if (_0x15b72d[_0x18a92b(0x2ce)](this[_0x18a92b(0x27b) + _0x18a92b(0x20e)][_0x18a92b(0x2ae)](_0x326f70['sn']), _0x326f70)) {
                this[_0x18a92b(0x27b) + _0x18a92b(0x20e)][_0x18a92b(0x274)](_0x326f70['sn']), console[_0x18a92b(0x2c5)]('[' + _0x15b72d[_0x18a92b(0x236)](moment)[_0x18a92b(0x1d1)](_0x15b72d[_0x18a92b(0x24b)]) + (_0x18a92b(0x1e0) + _0x18a92b(0x1eb) + _0x18a92b(0x28b)) + _0x326f70['sn']);
                try {
                    await Device[_0x18a92b(0x1ab)]({
                        'status': _0x15b72d[_0x18a92b(0x2b9)],
                        'last_seen': new Date()
                    }, { 'where': { 'sn': _0x326f70['sn'] } });
                } catch (_0x2b3202) {
                    console[_0x18a92b(0x25d)](_0x15b72d[_0x18a92b(0x273)], _0x2b3202[_0x18a92b(0x260)]);
                }
            } else
                console[_0x18a92b(0x2c5)]('[' + _0x15b72d[_0x18a92b(0x1bf)](moment)[_0x18a92b(0x1d1)](_0x15b72d[_0x18a92b(0x24b)]) + (_0x18a92b(0x2e4) + _0x18a92b(0x1e6) + _0x18a92b(0x284) + _0x18a92b(0x2a2)) + _0x326f70['sn']);
        }
    }
    [_0x14d53f(0x245) + 'r'](_0x359ad3, _0x829dfc) {
        const _0x53e42e = _0x14d53f, _0xa52d72 = {
                'kdRnz': _0x53e42e(0x2c5),
                'NTMtw': function (_0xe33290) {
                    return _0xe33290();
                },
                'JsAIc': _0x53e42e(0x2b2) + _0x53e42e(0x1b0),
                'ENriv': _0x53e42e(0x216)
            };
        _0x359ad3['sn'] && this[_0x53e42e(0x1a3)](_0xa52d72[_0x53e42e(0x1e8)], {
            'timestamp': _0xa52d72[_0x53e42e(0x1f4)](moment)[_0x53e42e(0x1d1)](_0xa52d72[_0x53e42e(0x1b9)]),
            'sn': _0x359ad3['sn'],
            'type': _0xa52d72[_0x53e42e(0x200)],
            'message': _0x53e42e(0x27c) + _0x53e42e(0x1a1) + _0x359ad3['sn'] + ':\x20' + _0x829dfc[_0x53e42e(0x260)]
        }), console[_0x53e42e(0x25d)]('[' + _0xa52d72[_0x53e42e(0x1f4)](moment)[_0x53e42e(0x1d1)](_0xa52d72[_0x53e42e(0x1b9)]) + (_0x53e42e(0x1a5) + _0x53e42e(0x2df)), _0x829dfc[_0x53e42e(0x260)]);
    }
    async [_0x14d53f(0x237) + _0x14d53f(0x1b1)](_0x54a478, _0x180d00, _0x32a1a8 = -0x191 * 0x13 + 0x2de6 + 0x16ed) {
        const _0x128a20 = _0x14d53f, _0x4e726f = {
                'ACDYC': function (_0x516e2c, _0x265a5a) {
                    return _0x516e2c(_0x265a5a);
                },
                'LXsrE': function (_0x51ab7a, _0x2a3f19) {
                    return _0x51ab7a(_0x2a3f19);
                },
                'oDaqo': function (_0x43fa00, _0x380416, _0x27cce0) {
                    return _0x43fa00(_0x380416, _0x27cce0);
                },
                'lHUwF': function (_0x573633, _0xe8b7ed) {
                    return _0x573633 === _0xe8b7ed;
                },
                'uxqwt': function (_0x5c1376) {
                    return _0x5c1376();
                },
                'KHYLt': _0x128a20(0x2b2) + _0x128a20(0x1b0),
                'vFPpz': _0x128a20(0x2c5),
                'tvVjK': _0x128a20(0x2ad),
                'aiKcy': function (_0x37ecae) {
                    return _0x37ecae();
                }
            }, _0x379d54 = this[_0x128a20(0x27b) + _0x128a20(0x20e)][_0x128a20(0x2ae)](_0x54a478);
        if (_0x379d54 && _0x4e726f[_0x128a20(0x20f)](_0x379d54[_0x128a20(0x1bd)], -0x16a3 + -0x1 * -0xdab + -0x8f9 * -0x1)) {
            const _0x3c3275 = _0x180d00[_0x128a20(0x266)], _0x5c6aff = _0x54a478 + ':' + _0x3c3275;
            return _0x379d54[_0x128a20(0x295)](JSON[_0x128a20(0x1db)](_0x180d00)), console[_0x128a20(0x2c5)]('[' + _0x4e726f[_0x128a20(0x2fb)](moment)[_0x128a20(0x1d1)](_0x4e726f[_0x128a20(0x1c7)]) + (_0x128a20(0x225) + _0x128a20(0x227)) + _0x54a478 + ':', JSON[_0x128a20(0x1db)](_0x180d00)), this[_0x128a20(0x1a3)](_0x4e726f[_0x128a20(0x2fe)], {
                'timestamp': _0x4e726f[_0x128a20(0x2fb)](moment)[_0x128a20(0x1d1)](_0x4e726f[_0x128a20(0x1c7)]),
                'sn': _0x54a478,
                'type': _0x4e726f[_0x128a20(0x203)],
                'data': _0x180d00
            }), new Promise((_0x56058b, _0x3f7b4b) => {
                const _0x47d759 = _0x128a20, _0x593a9b = {
                        'eCfIN': function (_0x1f3ff0, _0x40f862) {
                            const _0xa2dc2 = _0x121e;
                            return _0x4e726f[_0xa2dc2(0x23f)](_0x1f3ff0, _0x40f862);
                        },
                        'Ztpos': function (_0x4c2a0a, _0x2ccf59) {
                            const _0x4d3fe2 = _0x121e;
                            return _0x4e726f[_0x4d3fe2(0x291)](_0x4c2a0a, _0x2ccf59);
                        }
                    }, _0x5d78c4 = _0x4e726f[_0x47d759(0x1f0)](setTimeout, () => {
                        const _0x157bcb = _0x47d759;
                        this[_0x157bcb(0x208) + _0x157bcb(0x29e)][_0x157bcb(0x300)](_0x5c6aff) && (this[_0x157bcb(0x208) + _0x157bcb(0x29e)][_0x157bcb(0x274)](_0x5c6aff), _0x4e726f[_0x157bcb(0x291)](_0x56058b, {
                            'result': ![],
                            'timeout': !![],
                            'message': _0x157bcb(0x243) + _0x157bcb(0x23b) + _0x157bcb(0x28d) + _0x157bcb(0x234) + '\x20' + _0x54a478 + (_0x157bcb(0x2db) + _0x157bcb(0x221)) + _0x3c3275
                        }));
                    }, _0x32a1a8);
                this[_0x47d759(0x208) + _0x47d759(0x29e)][_0x47d759(0x240)](_0x5c6aff, {
                    'resolve': _0x301fd8 => {
                        const _0x49f8c2 = _0x47d759;
                        _0x593a9b[_0x49f8c2(0x1a6)](clearTimeout, _0x5d78c4), _0x593a9b[_0x49f8c2(0x2a1)](_0x56058b, _0x301fd8);
                    },
                    'reject': _0xca1a7e => {
                        const _0x5c1017 = _0x47d759;
                        _0x593a9b[_0x5c1017(0x1a6)](clearTimeout, _0x5d78c4), _0x593a9b[_0x5c1017(0x1a6)](_0x3f7b4b, _0xca1a7e);
                    }
                });
            });
        }
        console[_0x128a20(0x2c4)]('[' + _0x4e726f[_0x128a20(0x288)](moment)[_0x128a20(0x1d1)](_0x4e726f[_0x128a20(0x1c7)]) + _0x128a20(0x29d) + _0x54a478 + (_0x128a20(0x280) + _0x128a20(0x1f9) + _0x128a20(0x242)));
        throw new Error(_0x128a20(0x302) + _0x54a478 + (_0x128a20(0x280) + _0x128a20(0x1f9) + _0x128a20(0x228)));
    }
    [_0x14d53f(0x1ec) + _0x14d53f(0x294)](_0xf4ee74, _0xc54a0e) {
        const _0x56b2ae = _0x14d53f, _0x35042b = {
                'uDJUA': function (_0x4d0e1e, _0x493a3e) {
                    return _0x4d0e1e === _0x493a3e;
                },
                'gMiuI': _0x56b2ae(0x2cc),
                'nbCVP': function (_0x2743b4) {
                    return _0x2743b4();
                },
                'XrGPH': _0x56b2ae(0x2b2) + _0x56b2ae(0x1b0),
                'ohpjr': function (_0x486ef0) {
                    return _0x486ef0();
                },
                'JqEhW': function (_0x2a0a52) {
                    return _0x2a0a52();
                }
            }, _0x1dbc10 = this[_0x56b2ae(0x222) + 'ts'][_0x56b2ae(0x2ae)](_0xf4ee74);
        if (_0x1dbc10 && _0x35042b[_0x56b2ae(0x2aa)](_0x1dbc10[_0x56b2ae(0x1bd)], -0xdc5 + 0x17a5 + -0x9df))
            try {
                const _0x581bab = {
                    'cmd': _0x35042b[_0x56b2ae(0x1d9)],
                    'event': _0xc54a0e[_0x56b2ae(0x27d)],
                    'sn': _0xf4ee74,
                    'data': _0xc54a0e[_0x56b2ae(0x261)],
                    'timestamp': _0x35042b[_0x56b2ae(0x1ad)](moment)[_0x56b2ae(0x1d1)](_0x35042b[_0x56b2ae(0x1e5)])
                };
                return _0x1dbc10[_0x56b2ae(0x295)](JSON[_0x56b2ae(0x1db)](_0x581bab)), console[_0x56b2ae(0x2c5)]('[' + _0x35042b[_0x56b2ae(0x1ad)](moment)[_0x56b2ae(0x1d1)](_0x35042b[_0x56b2ae(0x1e5)]) + (_0x56b2ae(0x2de) + _0x56b2ae(0x2bc) + _0x56b2ae(0x265) + '\x20') + _0xf4ee74 + ':\x20' + _0xc54a0e[_0x56b2ae(0x27d)]), !![];
            } catch (_0x23e1f9) {
                return console[_0x56b2ae(0x25d)]('[' + _0x35042b[_0x56b2ae(0x219)](moment)[_0x56b2ae(0x1d1)](_0x35042b[_0x56b2ae(0x1e5)]) + (_0x56b2ae(0x2ec) + _0x56b2ae(0x278) + _0x56b2ae(0x2e9) + _0x56b2ae(0x217)) + _0xf4ee74 + ':', _0x23e1f9[_0x56b2ae(0x260)]), ![];
            }
        else
            return console[_0x56b2ae(0x2c5)]('[' + _0x35042b[_0x56b2ae(0x286)](moment)[_0x56b2ae(0x1d1)](_0x35042b[_0x56b2ae(0x1e5)]) + (_0x56b2ae(0x26a) + _0x56b2ae(0x2c1) + _0x56b2ae(0x1b6) + _0x56b2ae(0x215)) + _0xf4ee74), ![];
    }
    [_0x14d53f(0x1ba) + 'ge'](_0x404902) {
        const _0x2cdbda = _0x14d53f;
        return this[_0x2cdbda(0x29f)][_0x2cdbda(0x2ae)](_0x404902);
    }
    [_0x14d53f(0x1a8) + _0x14d53f(0x1c0)](_0xe39133) {
        const _0x360fa3 = _0x14d53f, _0x2b94fc = {
                'sRJiE': function (_0x15fb28, _0x569381) {
                    return _0x15fb28 === _0x569381;
                },
                'RQKLq': _0x360fa3(0x1a7),
                'ULkzt': function (_0x2e8f86, _0x940181) {
                    return _0x2e8f86 > _0x940181;
                },
                'dpyOM': function (_0x388939, _0x1340fe) {
                    return _0x388939 + _0x1340fe;
                },
                'dFcAX': _0x360fa3(0x248)
            };
        return JSON[_0x360fa3(0x1db)](_0xe39133, (_0x55988b, _0x2f4730) => {
            const _0x2193c2 = _0x360fa3;
            if (_0x2b94fc[_0x2193c2(0x2f4)](typeof _0x2f4730, _0x2b94fc[_0x2193c2(0x20c)]) && _0x2b94fc[_0x2193c2(0x2fc)](_0x2f4730[_0x2193c2(0x1f1)], 0x11b7 * 0x2 + 0x5d6 + -0x368 * 0xc))
                return _0x2b94fc[_0x2193c2(0x26d)](_0x2f4730[_0x2193c2(0x2c9)](-0x174f + -0xc80 + 0x23cf, 0x83a + 0x1ac6 * -0x1 + 0x12f0), _0x2b94fc[_0x2193c2(0x2ab)]);
            return _0x2f4730;
        });
    }
}
module[_0x14d53f(0x2e1)] = new WebSocketService();