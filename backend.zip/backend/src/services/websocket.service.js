function _0x4f98(_0x381589, _0xe2a61e) {
    _0x381589 = _0x381589 - (-0x20da + -0x4 * 0x7a4 + 0x40c3);
    const _0x2b84ea = _0xb2d1();
    let _0x55ec3e = _0x2b84ea[_0x381589];
    return _0x55ec3e;
}
const _0x287c6c = _0x4f98;
function _0xb2d1() {
    const _0x3e8948 = [
        'init',
        ']\x20Terminat',
        'hbSag',
        'YYYY-MM-DD',
        'delete',
        'IDPZK',
        'Devices',
        'reason',
        'StjMQ',
        'Failed\x20to\x20',
        'bfXLJ',
        'ing\x20sessio',
        'nd\x20',
        'random',
        'Wcmvb',
        'rs.js',
        'TYXCH',
        '\x20disconnec',
        'has',
        '\x20(Reason:\x20',
        'ent\x20with\x20O',
        'TgFRr',
        'lrjPk',
        ']\x20New\x20conn',
        'MisNk',
        'length',
        'ding.js',
        'Registered',
        'evice:\x20',
        'NdaYK',
        'response\x20f',
        'QrApZ',
        'ping',
        'sent\x20to\x20',
        'VHNnX',
        'aFitc',
        'kHJIE',
        'All\x20device',
        '\x20for\x20comma',
        'online',
        'rWbOB',
        'vVwGN',
        'FwKjx',
        '[handleDev',
        'ceResponse',
        'url',
        'runcated',
        '2|5|6|3|4|',
        'warn',
        ']\x20Device\x20d',
        'on\x20rejecte',
        'e\x20status\x20t',
        'MSKNa',
        'moment',
        'reset\x20devi',
        'checkActiv',
        'xOymb',
        'jaEEd',
        'efEkf',
        ':\x20Notify\x20s',
        'handleDevi',
        '55xTZQOz',
        'handleMess',
        'title',
        'handleClos',
        'PUjiA',
        'unknown\x20de',
        'tiCuZ',
        'atuses',
        'iceRequest',
        'notifydoor',
        'enrollid',
        'ing\x20dead\x20c',
        'pong',
        'run\x20handle',
        '\x20connectio',
        'update',
        'Error',
        'update\x20dev',
        ']\x20Forwarde',
        '263487qyhrzV',
        ']\x20WebSocke',
        'd:\x20',
        'tInfo',
        ']\x20Command\x20',
        ',\x20Session\x20',
        'get',
        '8njDXAk',
        'nnected.',
        'I]\x20Device:',
        'vMiht',
        'sendlog',
        'License\x20Er',
        't\x20error:',
        'd\x20to\x20Speed',
        'isconnecte',
        '\x20not\x20found',
        ']\x20Device\x20r',
        '\x20parameter',
        'image',
        'split',
        'close',
        'tNSnm',
        'sMSlx',
        'resetAllSt',
        ']\x20Obsolete',
        'ce:\x20',
        'o\x20DB:',
        'PvVKk',
        './license.',
        'QnefQ',
        '\x20rejected:',
        'hGnNB',
        'HCbCN',
        'EKZxl',
        'ending]\x20Cr',
        ',\x20Error:\x20',
        './logs',
        'UylUS',
        'for\x20',
        '\x20for\x20devic',
        'n\x20DB:',
        'xcAYE',
        'set',
        'log',
        'ent\x20không\x20',
        'uest',
        'nnected',
        'wss',
        'loKrN',
        'info',
        'NLUOK',
        '221304IZDGxJ',
        'reset\x20to\x20o',
        'service.js',
        'ection',
        'terminate',
        'eLicense',
        'connection',
        ']\x20Connecti',
        'PEN\x20status',
        'toString',
        '481650rQjrHZ',
        'Error\x20proc',
        'pendingReq',
        'JZTry',
        'Client\x20for',
        'from\x20',
        'RESPONSE',
        'boardingPa',
        'SUCCESS',
        'tvEDE',
        'ent',
        'eated\x20pend',
        'yZmHw',
        'n\x20closed\x20f',
        './LogHelpe',
        '793602Zlctlb',
        'WebSocket\x20',
        'events',
        ']\x20Message\x20',
        'RUtil',
        'beuUI',
        'Timeout\x20wa',
        'result',
        'dftvj',
        '][Error]\x20D',
        'có\x20sn,\x20đón',
        'getFaceIma',
        'DqiDW',
        'YNZYn',
        'handleErro',
        '][SessionP',
        'esponse\x20to',
        'isValid',
        'offline',
        'send',
        'cNxZR',
        'mmjfV',
        'SENT',
        'ess',
        'TSquI',
        'kHTCz',
        'onnection\x20',
        '5146575KkPASV',
        'RKQaQ',
        'JDEQy',
        'rom\x20device',
        'ceRequest',
        'handleConn',
        'FQzBS',
        'or]\x20Device',
        'registered',
        'substring',
        'xJWme',
        'vice',
        'error\x20for\x20',
        'readyState',
        '/SpeedWsCl',
        'JpehO',
        'format',
        'sessionId',
        'upsert',
        'fydoor]\x20De',
        '\x20from\x20',
        'egistered:',
        'iwEul',
        'create',
        'unknown',
        'uests',
        'socket',
        'lHzFB',
        'sYoiF',
        './sun.api.',
        'ted:\x20',
        '../models/',
        'DeviceRequ',
        'ent\x20',
        '32bgCzRo',
        'speedClien',
        'xbUHg',
        'clientId',
        'sync\x20devic',
        'customerNa',
        'MzsGo',
        'gyjpM',
        'SLaNJ',
        'now',
        'ffline.',
        'stringifyT',
        'substr',
        'or\x20',
        'logindex',
        'cmd',
        'ID:\x20',
        'stringify',
        'CVZGk',
        ',\x20Response',
        'tening\x20for',
        'ayrQC',
        'senduser',
        'DISCONNECT',
        'parse',
        'jJpmS',
        'clientType',
        'OPEN',
        'FAILED',
        'epXtH',
        'clients',
        'Missing\x20sn',
        'age',
        ']\x20Device\x20',
        'vhosd',
        'record',
        'essing\x20req',
        'speed',
        'ror:\x20',
        '][verifyAP',
        'SpeedWsCli',
        'connect',
        'n\x20for\x20Devi',
        'AYJmz',
        'sendComman',
        'IYtzT',
        'md:\x20',
        'e\x20status\x20i',
        'forward',
        'oRqUa',
        'Device\x20',
        'emit',
        '...',
        'IKJGz',
        'rllRn',
        'speed-',
        'PvdIv',
        'Error\x20pars',
        'resolve',
        'rwarding\x20t',
        'sessionpen',
        'RPSfF',
        'xBMbG',
        'ulLhC',
        'forwardToS',
        'faceCache',
        'ection\x20fro',
        'ERROR',
        ']\x20Error\x20fo',
        'event',
        'dToDevice',
        '\x20or\x20not\x20co',
        'includes',
        'ent\x20connec',
        'ulXbm',
        'CttmT',
        'IoFEg',
        'vice:\x20',
        '305496kLGZlT',
        'ted.',
        'peedClient',
        'forEach',
        '\x20HH:mm:ss',
        'est\x20with\x20c',
        '\x20device\x20',
        'g\x20kết\x20nối',
        ']\x20SpeedCli',
        'RECEIVED',
        '][notifydo',
        'SChiI',
        ']\x20No\x20Speed',
        'chhVA',
        'ing\x20messag',
        'epuZb',
        'backupnum',
        'isAlive',
        'yKNGl',
        'Client\x20lis',
        'WiLSw',
        'zhTlo',
        '\x20statuses\x20',
        'ice\x20offlin',
        'tFXpT',
        'string',
        '3239700jULRbW',
        '0|1',
        'MnoXm',
        'ce\x20statuse',
        'hWDWo',
        'data',
        'tABdq',
        'device',
        'remoteAddr',
        'XMgUC',
        'error',
        'HJEmz',
        'nding\x20noti',
        'exports',
        'Ccsfg',
        'iuPGr',
        'count',
        'status',
        'lEhRB',
        ']\x20Received',
        'NSIou',
        '11XeOPUv',
        'remoteIp',
        '][Error\x20se',
        'UBlob',
        'message',
        'NPoBm',
        'bxdDw',
        'o\x20SpeedCli',
        'service',
        'iting\x20for\x20',
        'reg'
    ];
    _0xb2d1 = function () {
        return _0x3e8948;
    };
    return _0xb2d1();
}
(function (_0x50b451, _0x9b6a7) {
    const _0x17c55c = _0x4f98, _0x354965 = _0x50b451();
    while (!![]) {
        try {
            const _0x1dbae3 = parseInt(_0x17c55c(0x279)) / (0x2 * -0x94d + 0x55 * -0x2b + 0x6 * 0x57b) + parseInt(_0x17c55c(0x242)) / (0x22e2 + 0x22d2 + -0x45b2) * (parseInt(_0x17c55c(0x23b)) / (0x1171 + 0xe88 + -0x1ff6)) + -parseInt(_0x17c55c(0x1b1)) / (0x7d4 + 0x436 + -0xc06) + -parseInt(_0x17c55c(0x228)) / (0xa * 0x60 + 0xd65 + -0x1120) * (-parseInt(_0x17c55c(0x26f)) / (0x16a * -0x5 + -0x329 * 0xb + 0x29db)) + -parseInt(_0x17c55c(0x2a3)) / (-0x1923 + 0x26db + 0x5 * -0x2bd) + -parseInt(_0x17c55c(0x163)) / (0x2e * -0x29 + -0x3e5 * -0x1 + 0xd * 0x45) * (parseInt(_0x17c55c(0x288)) / (0x1990 + 0x1bbf * -0x1 + -0x8e * -0x4)) + -parseInt(_0x17c55c(0x1cb)) / (0x2 * 0x509 + -0x2100 + 0x2df * 0x8) * (-parseInt(_0x17c55c(0x1e0)) / (0x185c + 0x150 + -0x19a1));
            if (_0x1dbae3 === _0x9b6a7)
                break;
            else
                _0x354965['push'](_0x354965['shift']());
        } catch (_0x3cf8fb) {
            _0x354965['push'](_0x354965['shift']());
        }
    }
}(_0xb2d1, -0xd91b * 0x2 + -0xb7698 + 0x133cdb));
const moment = require(_0x287c6c(0x220)), Device = require(_0x287c6c(0x160) + _0x287c6c(0x1d2)), EventEmitter = require(_0x287c6c(0x28a)), {callVerifyAPI, callNotifyMessage} = require(_0x287c6c(0x15e) + _0x287c6c(0x271)), LicenseService = require(_0x287c6c(0x258) + _0x287c6c(0x1e8)), SessionPending = require(_0x287c6c(0x160) + _0x287c6c(0x19f) + _0x287c6c(0x205)), {getLogger} = require(_0x287c6c(0x287) + _0x287c6c(0x1fa)), logger = getLogger({
        'logDir': _0x287c6c(0x260),
        'maxLogDays': 0x7,
        'dateFormat': _0x287c6c(0x1ee),
        'logFormat': _0x287c6c(0x1ee) + _0x287c6c(0x1b5)
    });
class WebSocketService extends EventEmitter {
    constructor() {
        const _0x6ce675 = _0x287c6c, _0x31f867 = { 'xBMbG': _0x6ce675(0x21a) + _0x6ce675(0x1cc) }, _0x549027 = _0x31f867[_0x6ce675(0x1a1)][_0x6ce675(0x24f)]('|');
        let _0x3143ab = 0xe3 * -0xd + 0x328 + 0x85f * 0x1;
        while (!![]) {
            switch (_0x549027[_0x3143ab++]) {
            case '0':
                this[_0x6ce675(0x27b) + _0x6ce675(0x15a)] = new Map();
                continue;
            case '1':
                this[_0x6ce675(0x26b)] = null;
                continue;
            case '2':
                super();
                continue;
            case '3':
                this[_0x6ce675(0x164) + _0x6ce675(0x23e)] = new Map();
                continue;
            case '4':
                this[_0x6ce675(0x1a4)] = new Map();
                continue;
            case '5':
                this[_0x6ce675(0x2ab) + _0x6ce675(0x1f1)] = new Map();
                continue;
            case '6':
                this[_0x6ce675(0x164) + 'ts'] = new Map();
                continue;
            }
            break;
        }
    }
    [_0x287c6c(0x1eb)](_0x378e87) {
        const _0x5dd01a = _0x287c6c, _0x340f63 = {
                'NSIou': function (_0x39a1cb, _0x2a5817) {
                    return _0x39a1cb === _0x2a5817;
                },
                'JZTry': function (_0x1acf8d) {
                    return _0x1acf8d();
                },
                'TSquI': _0x5dd01a(0x1ee) + _0x5dd01a(0x1b5),
                'StjMQ': _0x5dd01a(0x159),
                'yKNGl': _0x5dd01a(0x275),
                'PvdIv': function (_0x3c24b2, _0x2b3f99, _0x215df) {
                    return _0x3c24b2(_0x2b3f99, _0x215df);
                },
                'QrApZ': _0x5dd01a(0x250)
            };
        this[_0x5dd01a(0x26b)] = _0x378e87, this[_0x5dd01a(0x26b)]['on'](_0x340f63[_0x5dd01a(0x1c3)], (_0x2a7375, _0xfc5223) => this[_0x5dd01a(0x2a8) + _0x5dd01a(0x272)](_0x2a7375, _0xfc5223));
        const _0xde79ad = _0x340f63[_0x5dd01a(0x19b)](setInterval, () => {
            const _0x2d4fb2 = _0x5dd01a;
            this[_0x2d4fb2(0x26b)][_0x2d4fb2(0x181)][_0x2d4fb2(0x1b4)](_0x4f4b8e => {
                const _0x31bd86 = _0x2d4fb2;
                if (_0x340f63[_0x31bd86(0x1df)](_0x4f4b8e[_0x31bd86(0x1c2)], ![]))
                    return console[_0x31bd86(0x267)]('[' + _0x340f63[_0x31bd86(0x27c)](moment)[_0x31bd86(0x2b3)](_0x340f63[_0x31bd86(0x2a0)]) + (_0x31bd86(0x1ec) + _0x31bd86(0x233) + _0x31bd86(0x2a2) + _0x31bd86(0x262)) + (_0x4f4b8e['sn'] || _0x340f63[_0x31bd86(0x1f3)])), _0x4f4b8e[_0x31bd86(0x273)]();
                _0x4f4b8e[_0x31bd86(0x1c2)] = ![], _0x4f4b8e[_0x31bd86(0x20b)]();
            });
        }, 0x7f97 + -0xabf3 + 0xa18c);
        this[_0x5dd01a(0x26b)]['on'](_0x340f63[_0x5dd01a(0x20a)], () => clearInterval(_0xde79ad));
    }
    async [_0x287c6c(0x253) + _0x287c6c(0x22f)]() {
        const _0x15c9c0 = _0x287c6c, _0x362ace = {
                'MzsGo': _0x15c9c0(0x29a),
                'MSKNa': _0x15c9c0(0x210) + _0x15c9c0(0x1c7) + _0x15c9c0(0x270) + _0x15c9c0(0x16d),
                'aFitc': _0x15c9c0(0x1f4) + _0x15c9c0(0x221) + _0x15c9c0(0x1ce) + 's:'
            };
        try {
            await Device[_0x15c9c0(0x237)]({ 'status': _0x362ace[_0x15c9c0(0x169)] }, { 'where': {} }), console[_0x15c9c0(0x267)](_0x362ace[_0x15c9c0(0x21f)]);
        } catch (_0x463fa3) {
            console[_0x15c9c0(0x1d5)](_0x362ace[_0x15c9c0(0x20e)], _0x463fa3[_0x15c9c0(0x1e4)]);
        }
    }
    async [_0x287c6c(0x2a8) + _0x287c6c(0x272)](_0x59710d, _0x5a5a63) {
        const _0x1f8c1a = _0x287c6c, _0x5c39d8 = {
                'oRqUa': function (_0x4c8730) {
                    return _0x4c8730();
                },
                'loKrN': _0x1f8c1a(0x1ee) + _0x1f8c1a(0x1b5),
                'bxdDw': _0x1f8c1a(0x2b1) + 'i',
                'Ccsfg': _0x1f8c1a(0x188),
                'UylUS': _0x1f8c1a(0x166),
                'yZmHw': _0x1f8c1a(0x182) + _0x1f8c1a(0x24d),
                'lHzFB': _0x1f8c1a(0x18b) + _0x1f8c1a(0x283),
                'FQzBS': _0x1f8c1a(0x18c),
                'xcAYE': _0x1f8c1a(0x1d2),
                'zhTlo': _0x1f8c1a(0x234),
                'YNZYn': _0x1f8c1a(0x1e4),
                'PUjiA': _0x1f8c1a(0x250),
                'TgFRr': _0x1f8c1a(0x1d5)
            }, _0x4616c5 = await LicenseService[_0x1f8c1a(0x222) + _0x1f8c1a(0x274)]();
        if (!_0x4616c5[_0x1f8c1a(0x299)]) {
            console[_0x1f8c1a(0x267)]('[' + _0x5c39d8[_0x1f8c1a(0x194)](moment)[_0x1f8c1a(0x2b3)](_0x5c39d8[_0x1f8c1a(0x26c)]) + (_0x1f8c1a(0x276) + _0x1f8c1a(0x21d) + _0x1f8c1a(0x23d)) + _0x4616c5[_0x1f8c1a(0x1d5)]), _0x59710d[_0x1f8c1a(0x250)](0x38c + -0xa6d * 0x1 + 0xd5 * 0xd, _0x1f8c1a(0x247) + _0x1f8c1a(0x189) + _0x4616c5[_0x1f8c1a(0x1d5)]);
            return;
        }
        const _0x1d2744 = _0x5a5a63[_0x1f8c1a(0x15b)][_0x1f8c1a(0x1d3) + _0x1f8c1a(0x29f)];
        _0x59710d[_0x1f8c1a(0x1e1)] = _0x1d2744, _0x59710d[_0x1f8c1a(0x1c2)] = !![];
        if (_0x5a5a63[_0x1f8c1a(0x218)][_0x1f8c1a(0x1ab)](_0x5c39d8[_0x1f8c1a(0x1e6)])) {
            _0x59710d[_0x1f8c1a(0x17d)] = _0x5c39d8[_0x1f8c1a(0x1d9)];
            const _0x556b30 = _0x5a5a63[_0x1f8c1a(0x218)][_0x1f8c1a(0x24f)]('?'), _0x7bf57b = new URLSearchParams(_0x556b30[-0x1771 * 0x1 + 0x1ea8 + -0x736] || ''), _0x349a63 = _0x7bf57b[_0x1f8c1a(0x241)]('sn'), _0x4f9420 = _0x7bf57b[_0x1f8c1a(0x241)](_0x5c39d8[_0x1f8c1a(0x261)]) || _0x1f8c1a(0x19a) + Date[_0x1f8c1a(0x16c)]() + '-' + Math[_0x1f8c1a(0x1f8)]()[_0x1f8c1a(0x278)](-0x24dc + -0x2b * -0xb + 0x2327)[_0x1f8c1a(0x16f)](-0x1eba + 0x3 * 0x403 + 0x12b3 * 0x1, 0x3 * -0x22e + 0x1 * -0x117d + -0x1810 * -0x1);
            if (!_0x349a63) {
                console[_0x1f8c1a(0x267)]('[' + _0x5c39d8[_0x1f8c1a(0x194)](moment)[_0x1f8c1a(0x2b3)](_0x5c39d8[_0x1f8c1a(0x26c)]) + (_0x1f8c1a(0x1b9) + _0x1f8c1a(0x268) + _0x1f8c1a(0x292) + _0x1f8c1a(0x1b8))), _0x59710d[_0x1f8c1a(0x250)](-0x68e + -0x6fe + 0x117c, _0x5c39d8[_0x1f8c1a(0x285)]);
                return;
            }
            _0x59710d[_0x1f8c1a(0x17d)] = _0x5c39d8[_0x1f8c1a(0x1d9)], _0x59710d['sn'] = _0x349a63, _0x59710d[_0x1f8c1a(0x166)] = _0x4f9420, this[_0x1f8c1a(0x164) + 'ts'][_0x1f8c1a(0x266)](_0x349a63, _0x59710d), this[_0x1f8c1a(0x164) + _0x1f8c1a(0x23e)][_0x1f8c1a(0x266)](_0x59710d, {
                'clientId': _0x4f9420,
                'sn': _0x349a63,
                'connectedAt': new Date()
            }), console[_0x1f8c1a(0x267)]('[' + _0x5c39d8[_0x1f8c1a(0x194)](moment)[_0x1f8c1a(0x2b3)](_0x5c39d8[_0x1f8c1a(0x26c)]) + (_0x1f8c1a(0x1b9) + _0x1f8c1a(0x1ac) + _0x1f8c1a(0x15f)) + _0x4f9420 + (_0x1f8c1a(0x263) + 'e\x20') + _0x349a63 + _0x1f8c1a(0x2b7) + _0x1d2744), _0x59710d[_0x1f8c1a(0x29b)](JSON[_0x1f8c1a(0x174)]({
                'cmd': _0x5c39d8[_0x1f8c1a(0x15c)],
                'ret': _0x5c39d8[_0x1f8c1a(0x2a9)],
                'result': !![],
                'sn': _0x349a63,
                'clientId': _0x4f9420,
                'message': _0x1f8c1a(0x206) + _0x1f8c1a(0x263) + 'e\x20' + _0x349a63,
                'timestamp': _0x5c39d8[_0x1f8c1a(0x194)](moment)[_0x1f8c1a(0x2b3)](_0x5c39d8[_0x1f8c1a(0x26c)])
            }));
        } else
            _0x59710d[_0x1f8c1a(0x17d)] = _0x5c39d8[_0x1f8c1a(0x265)];
        console[_0x1f8c1a(0x267)]('[' + _0x5c39d8[_0x1f8c1a(0x194)](moment)[_0x1f8c1a(0x2b3)](_0x5c39d8[_0x1f8c1a(0x26c)]) + (_0x1f8c1a(0x202) + _0x1f8c1a(0x1a5) + 'm\x20') + _0x1d2744), _0x59710d['on'](_0x5c39d8[_0x1f8c1a(0x1c6)], () => {
            const _0x24d950 = _0x1f8c1a;
            _0x59710d[_0x24d950(0x1c2)] = !![];
        }), _0x59710d['on'](_0x5c39d8[_0x1f8c1a(0x295)], _0x30b1b9 => this[_0x1f8c1a(0x229) + _0x1f8c1a(0x183)](_0x59710d, _0x30b1b9)), _0x59710d['on'](_0x5c39d8[_0x1f8c1a(0x22c)], () => this[_0x1f8c1a(0x22b) + 'e'](_0x59710d)), _0x59710d['on'](_0x5c39d8[_0x1f8c1a(0x200)], _0x483b66 => this[_0x1f8c1a(0x296) + 'r'](_0x59710d, _0x483b66));
    }
    async [_0x287c6c(0x229) + _0x287c6c(0x183)](_0xf6a7aa, _0x2f1f13) {
        const _0x5655c1 = _0x287c6c, _0x5ab849 = {
                'TYXCH': function (_0x4629f6) {
                    return _0x4629f6();
                },
                'tiCuZ': _0x5655c1(0x1ee) + _0x5655c1(0x1b5),
                'kHTCz': _0x5655c1(0x159),
                'AYJmz': function (_0xb4d7e6, _0x30e7af) {
                    return _0xb4d7e6 === _0x30e7af;
                },
                'vhosd': _0x5655c1(0x188),
                'xbUHg': _0x5655c1(0x22d) + _0x5655c1(0x2ae),
                'XMgUC': _0x5655c1(0x267),
                'JDEQy': function (_0x27dd15) {
                    return _0x27dd15();
                },
                'epuZb': _0x5655c1(0x1ba),
                'ulXbm': _0x5655c1(0x18b) + _0x5655c1(0x283),
                'SLaNJ': _0x5655c1(0x19c) + _0x5655c1(0x1bf) + 'e:'
            };
        try {
            const _0x203add = await LicenseService[_0x5655c1(0x222) + _0x5655c1(0x274)]();
            if (!_0x203add[_0x5655c1(0x299)]) {
                console[_0x5655c1(0x267)]('[' + _0x5ab849[_0x5655c1(0x1fb)](moment)[_0x5655c1(0x2b3)](_0x5ab849[_0x5655c1(0x22e)]) + (_0x5655c1(0x28b) + _0x5655c1(0x27e)) + (_0xf6a7aa['sn'] || _0x5ab849[_0x5655c1(0x2a1)]) + (_0x5655c1(0x25a) + '\x20') + _0x203add[_0x5655c1(0x1d5)]), _0xf6a7aa[_0x5655c1(0x250)](-0x11d0 + 0x1a3 * 0x15 + -0xc9f, _0x5655c1(0x247) + _0x5655c1(0x189) + _0x203add[_0x5655c1(0x1d5)]);
                return;
            }
            const _0x15eb3f = _0x2f1f13[_0x5655c1(0x278)](), _0x31f1f0 = JSON[_0x5655c1(0x17b)](_0x15eb3f), {
                    cmd: _0x5cfe86,
                    ret: _0x3a2176
                } = _0x31f1f0, _0x3eff72 = _0x5ab849[_0x5655c1(0x18e)](_0xf6a7aa[_0x5655c1(0x17d)], _0x5ab849[_0x5655c1(0x185)]) ? _0xf6a7aa[_0x5655c1(0x166)] + '\x20(' + _0xf6a7aa['sn'] + ')' : _0xf6a7aa['sn'] || _0x5ab849[_0x5655c1(0x165)];
            console[_0x5655c1(0x267)]('[' + _0x5ab849[_0x5655c1(0x1fb)](moment)[_0x5655c1(0x2b3)](_0x5ab849[_0x5655c1(0x22e)]) + (_0x5655c1(0x1de) + _0x5655c1(0x2b7)) + _0xf6a7aa[_0x5655c1(0x17d)] + '\x20' + _0x3eff72 + ':', this[_0x5655c1(0x16e) + _0x5655c1(0x219)](_0x31f1f0)), this[_0x5655c1(0x196)](_0x5ab849[_0x5655c1(0x1d4)], {
                'timestamp': _0x5ab849[_0x5655c1(0x2a5)](moment)[_0x5655c1(0x2b3)](_0x5ab849[_0x5655c1(0x22e)]),
                'sn': _0xf6a7aa['sn'],
                'clientId': _0xf6a7aa[_0x5655c1(0x166)],
                'clientType': _0xf6a7aa[_0x5655c1(0x17d)],
                'sn': _0xf6a7aa['sn'],
                'type': _0x5ab849[_0x5655c1(0x1c0)],
                'data': _0x31f1f0
            });
            if (_0x5ab849[_0x5655c1(0x18e)](_0x5cfe86, _0x5ab849[_0x5655c1(0x1ad)])) {
            } else {
                if (_0x5cfe86)
                    this[_0x5655c1(0x227) + _0x5655c1(0x2a7)](_0xf6a7aa, _0x5cfe86, _0x31f1f0);
                else
                    _0x3a2176 && this[_0x5655c1(0x227) + _0x5655c1(0x217)](_0xf6a7aa, _0x3a2176, _0x31f1f0);
            }
        } catch (_0x306dc1) {
            console[_0x5655c1(0x1d5)](_0x5ab849[_0x5655c1(0x16b)], _0x306dc1[_0x5655c1(0x1e4)]);
        }
    }
    async [_0x287c6c(0x227) + _0x287c6c(0x2a7)](_0x3f07f5, _0x210bde, _0x5949c7) {
        const _0x4896e2 = _0x287c6c, _0x149166 = {
                'jaEEd': function (_0x141a35, _0x599e50) {
                    return _0x141a35 + _0x599e50;
                },
                'CVZGk': _0x4896e2(0x235) + _0x4896e2(0x161) + _0x4896e2(0x1b6) + _0x4896e2(0x191),
                'IoFEg': _0x4896e2(0x212),
                'hbSag': _0x4896e2(0x1f4) + _0x4896e2(0x167) + _0x4896e2(0x21e) + _0x4896e2(0x256),
                'rllRn': _0x4896e2(0x1ea),
                'jJpmS': function (_0x40e1e1) {
                    return _0x40e1e1();
                },
                'tFXpT': _0x4896e2(0x1ee) + _0x4896e2(0x1b5),
                'tNSnm': function (_0x3a51ca) {
                    return _0x3a51ca();
                },
                'MisNk': _0x4896e2(0x246),
                'rWbOB': function (_0x4a3552, _0x512b24) {
                    return _0x4a3552 > _0x512b24;
                },
                'ulLhC': function (_0x5b6091, _0x36fae7, _0x2f4566) {
                    return _0x5b6091(_0x36fae7, _0x2f4566);
                },
                'HJEmz': function (_0x3f21bf, _0x40994f) {
                    return _0x3f21bf === _0x40994f;
                },
                'kHJIE': _0x4896e2(0x17e),
                'sYoiF': _0x4896e2(0x231),
                'HCbCN': _0x4896e2(0x27a) + _0x4896e2(0x187) + _0x4896e2(0x269),
                'VHNnX': _0x4896e2(0x238),
                'WiLSw': _0x4896e2(0x179)
            };
        console[_0x4896e2(0x267)](_0x149166[_0x4896e2(0x224)](_0x149166[_0x4896e2(0x175)], _0x210bde));
        const _0x4faf12 = _0x5949c7['sn'];
        this[_0x4896e2(0x2ab) + _0x4896e2(0x1f1)][_0x4896e2(0x266)](_0x4faf12, _0x3f07f5), _0x3f07f5['sn'] = _0x4faf12;
        try {
            await Device[_0x4896e2(0x2b5)]({
                'sn': _0x4faf12,
                'status': _0x149166[_0x4896e2(0x1af)],
                'last_seen': new Date(),
                'ip_address': _0x3f07f5[_0x4896e2(0x1e1)]
            });
        } catch (_0x4d1ace) {
            console[_0x4896e2(0x1d5)](_0x149166[_0x4896e2(0x1ed)], _0x4d1ace[_0x4896e2(0x1e4)]);
        }
        switch (_0x210bde) {
        case _0x149166[_0x4896e2(0x199)]:
            _0x3f07f5[_0x4896e2(0x29b)](JSON[_0x4896e2(0x174)]({
                'ret': _0x149166[_0x4896e2(0x199)],
                'result': !![],
                'cloudtime': _0x149166[_0x4896e2(0x17c)](moment)[_0x4896e2(0x2b3)](_0x149166[_0x4896e2(0x1c9)]),
                'nosenduser': ![]
            })), console[_0x4896e2(0x267)]('[' + _0x149166[_0x4896e2(0x251)](moment)[_0x4896e2(0x2b3)](_0x149166[_0x4896e2(0x1c9)]) + (_0x4896e2(0x24c) + _0x4896e2(0x2b8) + '\x20') + _0x4faf12);
            break;
        case _0x149166[_0x4896e2(0x203)]:
            const _0x552064 = _0x5949c7[_0x4896e2(0x1db)] || -0x936 + 0xd7 * -0xa + -0x8ce * -0x2, _0x59a132 = _0x5949c7[_0x4896e2(0x171)] || -0x65a + 0x14ad + 0x1 * -0xe53;
            _0x5949c7[_0x4896e2(0x186)] && _0x149166[_0x4896e2(0x213)](_0x5949c7[_0x4896e2(0x186)][_0x4896e2(0x204)], 0xf * 0x38 + 0x19ac + -0x1cf4) && _0x5949c7[_0x4896e2(0x186)][-0x1 * -0xcbf + 0x2 * 0x7e1 + -0x1c81][_0x4896e2(0x24e)] && this[_0x4896e2(0x1a4)][_0x4896e2(0x266)](_0x5949c7['sn'] || _0x3f07f5['sn'], _0x5949c7[_0x4896e2(0x186)][-0x1f0a + -0xe33 + 0x2d3d][_0x4896e2(0x24e)]);
            try {
                const _0x1bf930 = await _0x149166[_0x4896e2(0x1a2)](callVerifyAPI, _0x5949c7[_0x4896e2(0x186)][-0x146b + 0x1ad9 + -0x337 * 0x2][_0x4896e2(0x24e)], _0x5949c7['sn']);
                logger[_0x4896e2(0x26d)](_0x4896e2(0x216) + _0x4896e2(0x230) + _0x4896e2(0x18a) + _0x4896e2(0x244) + '\x20' + _0x5949c7['sn'] + (_0x4896e2(0x176) + ':\x20') + JSON[_0x4896e2(0x174)](_0x1bf930)), _0x149166[_0x4896e2(0x1d6)](_0x1bf930[_0x4896e2(0x1dc)], _0x149166[_0x4896e2(0x20f)]) ? (this[_0x4896e2(0x18f) + _0x4896e2(0x1a9)](_0x3f07f5['sn'], {
                    'cmd': _0x149166[_0x4896e2(0x15d)],
                    'result': !![],
                    'doornum': 0x1,
                    'boardingPass': _0x1bf930[_0x4896e2(0x280) + 'ss'],
                    'title': _0x1bf930[_0x4896e2(0x22a)],
                    'message': _0x1bf930[_0x4896e2(0x1e4)],
                    'customerName': _0x1bf930[_0x4896e2(0x168) + 'me']
                }), logger[_0x4896e2(0x26d)](_0x4896e2(0x216) + _0x4896e2(0x230) + _0x4896e2(0x1bb) + _0x4896e2(0x2aa) + ':\x20' + _0x5949c7['sn'] + (_0x4896e2(0x176) + _0x4896e2(0x226) + _0x4896e2(0x1ff) + _0x4896e2(0x277))), SessionPending[_0x4896e2(0x2ba)]({
                    'sessionId': _0x1bf930[_0x4896e2(0x2b4)],
                    'status': 0x0,
                    'sn': _0x5949c7['sn'],
                    'boardingPass': _0x1bf930[_0x4896e2(0x280) + 'ss']
                }), logger[_0x4896e2(0x26d)](_0x4896e2(0x216) + _0x4896e2(0x230) + _0x4896e2(0x297) + _0x4896e2(0x25e) + _0x4896e2(0x284) + _0x4896e2(0x1f6) + _0x4896e2(0x18d) + _0x4896e2(0x255) + _0x5949c7['sn'] + (_0x4896e2(0x240) + _0x4896e2(0x173)) + _0x1bf930[_0x4896e2(0x2b4)])) : await this[_0x4896e2(0x18f) + _0x4896e2(0x1a9)](_0x3f07f5['sn'], {
                    'cmd': _0x149166[_0x4896e2(0x15d)],
                    'result': ![],
                    'doornum': 0x1,
                    'boardingPass': _0x1bf930[_0x4896e2(0x280) + 'ss'],
                    'title': _0x1bf930[_0x4896e2(0x22a)],
                    'message': _0x1bf930[_0x4896e2(0x1e4)],
                    'customerName': _0x1bf930[_0x4896e2(0x168) + 'me']
                });
            } catch (_0x330437) {
                logger[_0x4896e2(0x1d5)](_0x4896e2(0x216) + _0x4896e2(0x230) + _0x4896e2(0x291) + _0x4896e2(0x207) + _0x5949c7['sn'] + _0x4896e2(0x25f) + _0x330437[_0x4896e2(0x1e4)]);
                try {
                    await this[_0x4896e2(0x18f) + _0x4896e2(0x1a9)](_0x5949c7['sn'], {
                        'cmd': _0x149166[_0x4896e2(0x15d)],
                        'result': ![],
                        'doornum': 0x1,
                        'message': _0x149166[_0x4896e2(0x25c)],
                        'title': _0x149166[_0x4896e2(0x20d)],
                        'customerName': ''
                    });
                } catch (_0x3aa54c) {
                    logger[_0x4896e2(0x1d5)](_0x4896e2(0x216) + _0x4896e2(0x230) + _0x4896e2(0x1e2) + _0x4896e2(0x1d7) + _0x4896e2(0x2b6) + _0x4896e2(0x1b0) + _0x5949c7['sn'] + _0x4896e2(0x25f) + _0x3aa54c[_0x4896e2(0x1e4)]);
                }
            }
            _0x3f07f5[_0x4896e2(0x29b)](JSON[_0x4896e2(0x174)]({
                'ret': _0x149166[_0x4896e2(0x203)],
                'result': !![],
                'count': _0x552064,
                'logindex': _0x59a132,
                'cloudtime': _0x149166[_0x4896e2(0x251)](moment)[_0x4896e2(0x2b3)](_0x149166[_0x4896e2(0x1c9)]),
                'access': 0x1
            }));
            break;
        case _0x149166[_0x4896e2(0x1c5)]:
            _0x5949c7[_0x4896e2(0x186)] && this[_0x4896e2(0x1a4)][_0x4896e2(0x266)](_0x5949c7['sn'] || _0x3f07f5['sn'], _0x5949c7[_0x4896e2(0x186)]);
            _0x3f07f5[_0x4896e2(0x29b)](JSON[_0x4896e2(0x174)]({
                'ret': _0x149166[_0x4896e2(0x1c5)],
                'result': !![],
                'enrollid': _0x5949c7[_0x4896e2(0x232)],
                'backupnum': _0x5949c7[_0x4896e2(0x1c1)]
            }));
            break;
        }
    }
    [_0x287c6c(0x227) + _0x287c6c(0x217)](_0x44ac8e, _0x927313, _0x25eb51) {
        const _0x1d4563 = _0x287c6c, _0x1a8820 = {
                'tABdq': _0x1d4563(0x281),
                'ayrQC': _0x1d4563(0x17f),
                'PvVKk': function (_0x497bd3) {
                    return _0x497bd3();
                },
                'tvEDE': _0x1d4563(0x1ee) + _0x1d4563(0x1b5),
                'IDPZK': _0x1d4563(0x267),
                'RUtil': function (_0x45683e) {
                    return _0x45683e();
                },
                'xOymb': _0x1d4563(0x27f)
            }, _0x138d3f = _0x25eb51[_0x1d4563(0x28f)] ? _0x1a8820[_0x1d4563(0x1d1)] : _0x1a8820[_0x1d4563(0x178)], _0x57ab55 = _0x25eb51[_0x1d4563(0x1f2)] ? _0x1d4563(0x1fe) + _0x25eb51[_0x1d4563(0x1f2)] + ')' : '';
        console[_0x1d4563(0x267)]('[' + _0x1a8820[_0x1d4563(0x257)](moment)[_0x1d4563(0x2b3)](_0x1a8820[_0x1d4563(0x282)]) + (_0x1d4563(0x24c) + _0x1d4563(0x298) + '\x20') + _0x927313 + ':\x20' + _0x138d3f + _0x57ab55);
        if (_0x44ac8e['sn']) {
            const _0x2a5625 = _0x44ac8e['sn'] + ':' + _0x927313, _0x1b33fe = this[_0x1d4563(0x27b) + _0x1d4563(0x15a)][_0x1d4563(0x241)](_0x2a5625);
            _0x1b33fe && (_0x1b33fe[_0x1d4563(0x19d)](_0x25eb51), this[_0x1d4563(0x27b) + _0x1d4563(0x15a)][_0x1d4563(0x1ef)](_0x2a5625));
        }
        this[_0x1d4563(0x196)](_0x1a8820[_0x1d4563(0x1f0)], {
            'timestamp': _0x1a8820[_0x1d4563(0x28c)](moment)[_0x1d4563(0x2b3)](_0x1a8820[_0x1d4563(0x282)]),
            'sn': _0x44ac8e['sn'],
            'type': _0x1a8820[_0x1d4563(0x223)],
            'command': _0x927313,
            'result': _0x138d3f,
            'reason': _0x57ab55,
            'data': _0x25eb51
        });
    }
    async [_0x287c6c(0x22b) + 'e'](_0x38f711) {
        const _0xa88710 = _0x287c6c, _0x93542 = {
                'iuPGr': _0xa88710(0x267),
                'iwEul': function (_0x179ea8) {
                    return _0x179ea8();
                },
                'UBlob': _0xa88710(0x1ee) + _0xa88710(0x1b5),
                'vMiht': _0xa88710(0x17a) + 'ED',
                'gyjpM': function (_0x3a6c2f, _0xc2a2c1) {
                    return _0x3a6c2f === _0xc2a2c1;
                },
                'MnoXm': function (_0x23b456) {
                    return _0x23b456();
                },
                'bfXLJ': _0xa88710(0x29a),
                'FwKjx': _0xa88710(0x1f4) + _0xa88710(0x239) + _0xa88710(0x1c8) + _0xa88710(0x192) + _0xa88710(0x264)
            };
        if (_0x38f711['sn']) {
            this[_0xa88710(0x196)](_0x93542[_0xa88710(0x1da)], {
                'timestamp': _0x93542[_0xa88710(0x2b9)](moment)[_0xa88710(0x2b3)](_0x93542[_0xa88710(0x1e3)]),
                'sn': _0x38f711['sn'],
                'type': _0x93542[_0xa88710(0x245)],
                'message': _0xa88710(0x195) + _0x38f711['sn'] + (_0xa88710(0x1fc) + _0xa88710(0x1b2))
            });
            if (_0x93542[_0xa88710(0x16a)](this[_0xa88710(0x2ab) + _0xa88710(0x1f1)][_0xa88710(0x241)](_0x38f711['sn']), _0x38f711)) {
                this[_0xa88710(0x2ab) + _0xa88710(0x1f1)][_0xa88710(0x1ef)](_0x38f711['sn']), console[_0xa88710(0x267)]('[' + _0x93542[_0xa88710(0x1cd)](moment)[_0xa88710(0x2b3)](_0x93542[_0xa88710(0x1e3)]) + (_0xa88710(0x21c) + _0xa88710(0x24a) + _0xa88710(0x23d)) + _0x38f711['sn']);
                try {
                    await Device[_0xa88710(0x237)]({
                        'status': _0x93542[_0xa88710(0x1f5)],
                        'last_seen': new Date()
                    }, { 'where': { 'sn': _0x38f711['sn'] } });
                } catch (_0x1e2b5a) {
                    console[_0xa88710(0x1d5)](_0x93542[_0xa88710(0x215)], _0x1e2b5a[_0xa88710(0x1e4)]);
                }
            } else
                console[_0xa88710(0x267)]('[' + _0x93542[_0xa88710(0x2b9)](moment)[_0xa88710(0x2b3)](_0x93542[_0xa88710(0x1e3)]) + (_0xa88710(0x254) + _0xa88710(0x236) + _0xa88710(0x286) + _0xa88710(0x170)) + _0x38f711['sn']);
        }
    }
    [_0x287c6c(0x296) + 'r'](_0x1f700d, _0x158104) {
        const _0x1a46b7 = _0x287c6c, _0x394f44 = {
                'CttmT': _0x1a46b7(0x267),
                'IKJGz': function (_0x56f073) {
                    return _0x56f073();
                },
                'DqiDW': _0x1a46b7(0x1ee) + _0x1a46b7(0x1b5),
                'RKQaQ': _0x1a46b7(0x1a6),
                'RPSfF': function (_0x4a014e) {
                    return _0x4a014e();
                }
            };
        _0x1f700d['sn'] && this[_0x1a46b7(0x196)](_0x394f44[_0x1a46b7(0x1ae)], {
            'timestamp': _0x394f44[_0x1a46b7(0x198)](moment)[_0x1a46b7(0x2b3)](_0x394f44[_0x1a46b7(0x294)]),
            'sn': _0x1f700d['sn'],
            'type': _0x394f44[_0x1a46b7(0x2a4)],
            'message': _0x1a46b7(0x289) + _0x1a46b7(0x2af) + _0x1f700d['sn'] + ':\x20' + _0x158104[_0x1a46b7(0x1e4)]
        }), console[_0x1a46b7(0x1d5)]('[' + _0x394f44[_0x1a46b7(0x1a0)](moment)[_0x1a46b7(0x2b3)](_0x394f44[_0x1a46b7(0x294)]) + (_0x1a46b7(0x23c) + _0x1a46b7(0x248)), _0x158104[_0x1a46b7(0x1e4)]);
    }
    async [_0x287c6c(0x18f) + _0x287c6c(0x1a9)](_0x3fe37b, _0x42fab1, _0x36f3ae = 0x178f * 0x1 + -0x1208 + 0x1f9 * 0x11) {
        const _0x5555e7 = _0x287c6c, _0x2853d3 = {
                'dftvj': function (_0x513487, _0x77b2e5) {
                    return _0x513487(_0x77b2e5);
                },
                'NPoBm': function (_0x311227, _0x2774c8) {
                    return _0x311227(_0x2774c8);
                },
                'epXtH': function (_0x3972bf, _0x279ab8) {
                    return _0x3972bf(_0x279ab8);
                },
                'cNxZR': function (_0x2fbfeb, _0x12f0bd, _0x5f2d08) {
                    return _0x2fbfeb(_0x12f0bd, _0x5f2d08);
                },
                'efEkf': function (_0x2966ea, _0x527b6a) {
                    return _0x2966ea === _0x527b6a;
                },
                'IYtzT': function (_0x1776d9) {
                    return _0x1776d9();
                },
                'hWDWo': _0x5555e7(0x1ee) + _0x5555e7(0x1b5),
                'Wcmvb': _0x5555e7(0x267),
                'QnefQ': function (_0x25f19d) {
                    return _0x25f19d();
                },
                'NdaYK': _0x5555e7(0x29e)
            }, _0x3f4f3b = this[_0x5555e7(0x2ab) + _0x5555e7(0x1f1)][_0x5555e7(0x241)](_0x3fe37b);
        if (_0x3f4f3b && _0x2853d3[_0x5555e7(0x225)](_0x3f4f3b[_0x5555e7(0x2b0)], -0x1553 + 0x1f85 + -0xa31)) {
            const _0x1adc8e = _0x42fab1[_0x5555e7(0x172)], _0x10e7ad = _0x3fe37b + ':' + _0x1adc8e;
            return _0x3f4f3b[_0x5555e7(0x29b)](JSON[_0x5555e7(0x174)](_0x42fab1)), console[_0x5555e7(0x267)]('[' + _0x2853d3[_0x5555e7(0x190)](moment)[_0x5555e7(0x2b3)](_0x2853d3[_0x5555e7(0x1cf)]) + (_0x5555e7(0x23f) + _0x5555e7(0x20c)) + _0x3fe37b + ':', JSON[_0x5555e7(0x174)](_0x42fab1)), this[_0x5555e7(0x196)](_0x2853d3[_0x5555e7(0x1f9)], {
                'timestamp': _0x2853d3[_0x5555e7(0x259)](moment)[_0x5555e7(0x2b3)](_0x2853d3[_0x5555e7(0x1cf)]),
                'sn': _0x3fe37b,
                'type': _0x2853d3[_0x5555e7(0x208)],
                'data': _0x42fab1
            }), new Promise((_0x33bc31, _0x5684ca) => {
                const _0x381059 = _0x5555e7, _0x2f95b3 = {
                        'chhVA': function (_0x3baae8, _0x538941) {
                            const _0xd5f1e4 = _0x4f98;
                            return _0x2853d3[_0xd5f1e4(0x180)](_0x3baae8, _0x538941);
                        }
                    }, _0x45fec7 = _0x2853d3[_0x381059(0x29c)](setTimeout, () => {
                        const _0x5d419c = _0x381059;
                        this[_0x5d419c(0x27b) + _0x5d419c(0x15a)][_0x5d419c(0x1fd)](_0x10e7ad) && (this[_0x5d419c(0x27b) + _0x5d419c(0x15a)][_0x5d419c(0x1ef)](_0x10e7ad), _0x2f95b3[_0x5d419c(0x1be)](_0x33bc31, {
                            'result': ![],
                            'timeout': !![],
                            'message': _0x5d419c(0x28e) + _0x5d419c(0x1e9) + _0x5d419c(0x209) + _0x5d419c(0x2a6) + '\x20' + _0x3fe37b + (_0x5d419c(0x211) + _0x5d419c(0x1f7)) + _0x1adc8e
                        }));
                    }, _0x36f3ae);
                this[_0x381059(0x27b) + _0x381059(0x15a)][_0x381059(0x266)](_0x10e7ad, {
                    'resolve': _0x5a1456 => {
                        const _0x40e36d = _0x381059;
                        _0x2853d3[_0x40e36d(0x290)](clearTimeout, _0x45fec7), _0x2853d3[_0x40e36d(0x1e5)](_0x33bc31, _0x5a1456);
                    },
                    'reject': _0x26e92a => {
                        const _0x1904fb = _0x381059;
                        _0x2853d3[_0x1904fb(0x290)](clearTimeout, _0x45fec7), _0x2853d3[_0x1904fb(0x290)](_0x5684ca, _0x26e92a);
                    }
                });
            });
        }
        console[_0x5555e7(0x21b)]('[' + _0x2853d3[_0x5555e7(0x259)](moment)[_0x5555e7(0x2b3)](_0x2853d3[_0x5555e7(0x1cf)]) + _0x5555e7(0x184) + _0x3fe37b + (_0x5555e7(0x24b) + _0x5555e7(0x1aa) + _0x5555e7(0x243)));
        throw new Error(_0x5555e7(0x195) + _0x3fe37b + (_0x5555e7(0x24b) + _0x5555e7(0x1aa) + _0x5555e7(0x26a)));
    }
    [_0x287c6c(0x1a3) + _0x287c6c(0x1b3)](_0x236d0e, _0x333be2) {
        const _0x279e9d = _0x287c6c, _0x551b51 = {
                'xJWme': function (_0x3ec0fa, _0x4dde08) {
                    return _0x3ec0fa === _0x4dde08;
                },
                'vVwGN': _0x279e9d(0x193),
                'lrjPk': function (_0x116521) {
                    return _0x116521();
                },
                'mmjfV': _0x279e9d(0x1ee) + _0x279e9d(0x1b5),
                'lEhRB': function (_0x2e3280) {
                    return _0x2e3280();
                },
                'sMSlx': function (_0x1e454c) {
                    return _0x1e454c();
                },
                'SChiI': function (_0x105a13) {
                    return _0x105a13();
                }
            }, _0x5a2104 = this[_0x279e9d(0x164) + 'ts'][_0x279e9d(0x241)](_0x236d0e);
        if (_0x5a2104 && _0x551b51[_0x279e9d(0x2ad)](_0x5a2104[_0x279e9d(0x2b0)], -0x32 * -0xb3 + -0x31c + -0x1fd9 * 0x1))
            try {
                const _0xa750d7 = {
                    'cmd': _0x551b51[_0x279e9d(0x214)],
                    'event': _0x333be2[_0x279e9d(0x1a8)],
                    'sn': _0x236d0e,
                    'data': _0x333be2[_0x279e9d(0x1d0)],
                    'timestamp': _0x551b51[_0x279e9d(0x201)](moment)[_0x279e9d(0x2b3)](_0x551b51[_0x279e9d(0x29d)])
                };
                return _0x5a2104[_0x279e9d(0x29b)](JSON[_0x279e9d(0x174)](_0xa750d7)), console[_0x279e9d(0x267)]('[' + _0x551b51[_0x279e9d(0x1dd)](moment)[_0x279e9d(0x2b3)](_0x551b51[_0x279e9d(0x29d)]) + (_0x279e9d(0x23a) + _0x279e9d(0x249) + _0x279e9d(0x27d) + '\x20') + _0x236d0e + ':\x20' + _0x333be2[_0x279e9d(0x1a8)]), !![];
            } catch (_0x18ae3d) {
                return console[_0x279e9d(0x1d5)]('[' + _0x551b51[_0x279e9d(0x252)](moment)[_0x279e9d(0x2b3)](_0x551b51[_0x279e9d(0x29d)]) + (_0x279e9d(0x1a7) + _0x279e9d(0x19e) + _0x279e9d(0x1e7) + _0x279e9d(0x162)) + _0x236d0e + ':', _0x18ae3d[_0x279e9d(0x1e4)]), ![];
            }
        else
            return console[_0x279e9d(0x267)]('[' + _0x551b51[_0x279e9d(0x1bc)](moment)[_0x279e9d(0x2b3)](_0x551b51[_0x279e9d(0x29d)]) + (_0x279e9d(0x1bd) + _0x279e9d(0x1c4) + _0x279e9d(0x177) + _0x279e9d(0x1b7)) + _0x236d0e), ![];
    }
    [_0x287c6c(0x293) + 'ge'](_0x118bbd) {
        const _0x443246 = _0x287c6c;
        return this[_0x443246(0x1a4)][_0x443246(0x241)](_0x118bbd);
    }
    [_0x287c6c(0x16e) + _0x287c6c(0x219)](_0x274cf6) {
        const _0x4c4d61 = _0x287c6c, _0x25c3a5 = {
                'JpehO': function (_0x17a130, _0x21d070) {
                    return _0x17a130 === _0x21d070;
                },
                'beuUI': _0x4c4d61(0x1ca),
                'EKZxl': function (_0x44273d, _0xccbab8) {
                    return _0x44273d > _0xccbab8;
                },
                'hGnNB': function (_0x57937b, _0x5656c7) {
                    return _0x57937b + _0x5656c7;
                },
                'NLUOK': _0x4c4d61(0x197)
            };
        return JSON[_0x4c4d61(0x174)](_0x274cf6, (_0x44bb32, _0x5ebce3) => {
            const _0x1a639c = _0x4c4d61;
            if (_0x25c3a5[_0x1a639c(0x2b2)](typeof _0x5ebce3, _0x25c3a5[_0x1a639c(0x28d)]) && _0x25c3a5[_0x1a639c(0x25d)](_0x5ebce3[_0x1a639c(0x204)], -0x24b + -0x228d + 0x253c))
                return _0x25c3a5[_0x1a639c(0x25b)](_0x5ebce3[_0x1a639c(0x2ac)](-0xdfa + 0x2 * 0x59d + 0x2c0, -0x8ca + 0x79 * -0x50 + 0x2efe), _0x25c3a5[_0x1a639c(0x26e)]);
            return _0x5ebce3;
        });
    }
}
module[_0x287c6c(0x1d8)] = new WebSocketService();