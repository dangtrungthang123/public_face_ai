function _0x42fb() {
    const _0x2c2199 = [
        'ing\x20messag',
        'unknown',
        'senduser',
        ']\x20Command\x20',
        'error',
        'message',
        'IoBVf',
        'g\x20kết\x20nối',
        'glyda',
        'run\x20handle',
        ']\x20Connecti',
        'service.js',
        'CWBDD',
        'bydhL',
        '\x20HH:mm:ss',
        'terminate',
        '8sMNNgc',
        'remoteAddr',
        'stringify',
        'koLGl',
        'cMTjI',
        '][SessionP',
        'forward',
        ']\x20Device\x20r',
        ',\x20Session\x20',
        'eated\x20pend',
        'có\x20sn,\x20đón',
        'nd\x20',
        'peJVu',
        'ing\x20dead\x20c',
        'ouTBr',
        'speedClien',
        ']\x20WebSocke',
        'handleClos',
        'tInfo',
        'sendComman',
        'onnection\x20',
        'YEptX',
        'isValid',
        'pendingReq',
        'image',
        'tuEDy',
        'ggAsQ',
        'logindex',
        'customerNa',
        'TnaIe',
        'eDmEF',
        'dtzmr',
        'VwSAX',
        'count',
        'dOitw',
        'xaWcB',
        'CqRXc',
        'online',
        '45jbQwFA',
        ']\x20Forwarde',
        'rwarding\x20t',
        'vice',
        '\x20or\x20not\x20co',
        'BTfbW',
        'sessionpen',
        './LogHelpe',
        'ice\x20offlin',
        ']\x20Obsolete',
        'DhjlX',
        'delete',
        'DUXfi',
        'record',
        '2188846dmNbIZ',
        'NeJCT',
        'log',
        'response\x20f',
        ']\x20Message\x20',
        './license.',
        'n\x20closed\x20f',
        'wss',
        'PEN\x20status',
        'fKGXv',
        '[handleDev',
        'JZoKX',
        './logs',
        'haRSP',
        'HUyJS',
        'fBgOE',
        'RkgCP',
        'RmQbV',
        'send',
        'ent\x20không\x20',
        'esponse\x20to',
        'forEach',
        'SENT',
        'd:\x20',
        'Client\x20for',
        '\x20device\x20',
        'WiSiJ',
        'rom\x20device',
        'split',
        'handleMess',
        'forwardToS',
        'url',
        'NLhHO',
        'now',
        '][verifyAP',
        '../models/',
        'xKNJw',
        'BIKWx',
        'License\x20Er',
        'egistered:',
        '\x20connectio',
        'nfReY',
        'fjdwU',
        'ing\x20sessio',
        'ent\x20with\x20O',
        'Missing\x20sn',
        'sendlog',
        'OPEN',
        'result',
        'Devices',
        'BFsmg',
        'eLicense',
        'error\x20for\x20',
        'qcOmY',
        'backupnum',
        'or\x20',
        'getFaceIma',
        'update',
        'sync\x20devic',
        'zxXtr',
        'status',
        'I]\x20Device:',
        'create',
        '\x20disconnec',
        'Client\x20lis',
        '\x20rejected:',
        'XEVZq',
        '\x20statuses\x20',
        'RECEIVED',
        'qbgDm',
        'aEvFx',
        'fFoYN',
        'UCTbG',
        'has',
        'boardingPa',
        'isconnecte',
        'rlVmm',
        'skain',
        '][Error\x20se',
        'kmOPd',
        'nAYUC',
        'isAlive',
        'stringifyT',
        'uest',
        'checkActiv',
        'SevXd',
        'mhNCh',
        'format',
        '][Error]\x20D',
        'VqAhO',
        'BgMym',
        'reason',
        ']\x20No\x20Speed',
        'atuses',
        'n\x20DB:',
        'vice:\x20',
        '0|6|4|2|5|',
        'omWgl',
        'WebSocket\x20',
        'rVami',
        'ent',
        './sun.api.',
        'TnHgT',
        'ceRequest',
        'Device\x20',
        'toString',
        '\x20not\x20found',
        'init',
        'uests',
        'sessionId',
        'warn',
        'nding\x20noti',
        'Failed\x20to\x20',
        '...',
        ':\x20Notify\x20s',
        'connect',
        'zMuya',
        'evice:\x20',
        'parse',
        'QXhVL',
        'ending]\x20Cr',
        'connection',
        'random',
        '][notifydo',
        'BeZuS',
        'zsepz',
        'string',
        'reset\x20to\x20o',
        'fydoor]\x20De',
        'All\x20device',
        'reg',
        'ted:\x20',
        'substr',
        'enrollid',
        ']\x20Device\x20d',
        '1124284rXzRkR',
        '130431qCAhvB',
        '542610ziUOEI',
        'notifydoor',
        'service',
        'KCVMN',
        'ERROR',
        ']\x20Terminat',
        'remoteIp',
        'resetAllSt',
        'qDNUs',
        'nnected.',
        'for\x20',
        'TkkAz',
        'n\x20for\x20Devi',
        'ror:\x20',
        ',\x20Response',
        '1|3',
        'ceResponse',
        'SUCCESS',
        'from\x20',
        'BslsC',
        'oAmVq',
        'offline',
        'ted.',
        'ID:\x20',
        'get',
        'device',
        'ikcCB',
        'est\x20with\x20c',
        'upsert',
        '\x20(Reason:\x20',
        '\x20from\x20',
        'md:\x20',
        'close',
        'ding.js',
        'runcated',
        'gGTog',
        'data',
        'JPfsL',
        '401825pVreHP',
        'iting\x20for\x20',
        'uIhWn',
        ']\x20Received',
        'peedClient',
        'clients',
        'event',
        '58991DVsUJo',
        'pong',
        'ection',
        'ping',
        'e\x20status\x20i',
        'clientType',
        'moment',
        '16ofhilB',
        'oGZVK',
        'emit',
        'handleDevi',
        'substring',
        'on\x20rejecte',
        'registered',
        'handleErro',
        'Registered',
        'SpeedWsCli',
        'handleConn',
        'or]\x20Device',
        'speed-',
        'dToDevice',
        'ce\x20statuse',
        'UFLXe',
        't\x20error:',
        ',\x20Error:\x20',
        'includes',
        'yqHRG',
        'okpXi',
        'title',
        'readyState',
        'IDFvq',
        'Timeout\x20wa',
        'speed',
        'DvTrW',
        'ess',
        ']\x20New\x20conn',
        'PkakC',
        ']\x20Device\x20',
        'nnected',
        '/SpeedWsCl',
        '\x20parameter',
        'resolve',
        'FAILED',
        'info',
        'cROzV',
        'sent\x20to\x20',
        'uFrqA',
        'hxIZx',
        'Error\x20proc',
        '\x20for\x20devic',
        'hydCY',
        'zlMJv',
        'tening\x20for',
        'set',
        'iceRequest',
        'YYYY-MM-DD',
        'socket',
        'CJJjv',
        'tdWcR',
        'ZtUGP',
        'SSaeW',
        'unknown\x20de',
        'sCkBT',
        'exports',
        'ent\x20connec',
        'length',
        '\x20for\x20comma',
        'o\x20SpeedCli',
        'o\x20DB:',
        'WSkSV',
        'KXRKO',
        'e\x20status\x20t',
        'cmd',
        'reset\x20devi',
        'ffline.',
        'XEwMW',
        'Error\x20pars',
        'events',
        'essing\x20req',
        'WHyvC',
        'DISCONNECT',
        'pdxQr',
        'CcsGL',
        'age',
        ']\x20Error\x20fo',
        '4245624jAFggz',
        'tipyF',
        'PYeCh',
        'hSKYY',
        'hvABe',
        'ection\x20fro',
        'aBtuI',
        '22AJBavB',
        'WVWmQ',
        'jEDHI',
        ']\x20SpeedCli',
        'clientId',
        'Error',
        'update\x20dev',
        'DeviceRequ',
        'RESPONSE',
        'OuNsa',
        'rs.js',
        'ce:\x20',
        'LNNtr',
        'faceCache',
        'ent\x20',
        'd\x20to\x20Speed'
    ];
    _0x42fb = function () {
        return _0x2c2199;
    };
    return _0x42fb();
}
const _0x3334da = _0x3af3;
(function (_0x35add9, _0x557578) {
    const _0x588f85 = _0x3af3, _0x5d8bc5 = _0x35add9();
    while (!![]) {
        try {
            const _0x1d88f0 = parseInt(_0x588f85(0x127)) / (0x51 * 0x72 + 0x1 * -0x1283 + -0x118e) * (-parseInt(_0x588f85(0x183)) / (0x1 * 0x2087 + -0xa8b * 0x1 + -0x15fa)) + parseInt(_0x588f85(0x25f)) / (-0x2027 * 0x1 + 0x1613 + 0xa17) * (parseInt(_0x588f85(0x1a3)) / (-0x58 * -0x39 + -0x23a1 * -0x1 + -0x3735)) + parseInt(_0x588f85(0x120)) / (0xcea * 0x2 + 0x5 * 0x606 + 0x67 * -0x8b) + parseInt(_0x588f85(0x17c)) / (0x3cc + 0x97 * -0x22 + 0x1048) + -parseInt(_0x588f85(0x25e)) / (-0xab9 + 0xa01 + -0x1 * -0xbf) * (parseInt(_0x588f85(0x12e)) / (0x1945 + -0xf8 + 0x3 * -0x817)) + -parseInt(_0x588f85(0x1c9)) / (0x226c + 0x3 * -0x713 + -0xd2a) * (-parseInt(_0x588f85(0x260)) / (-0xa3 * 0x1f + -0x1eea * 0x1 + 0x32b1)) + parseInt(_0x588f85(0x1d7)) / (0x3 * -0x281 + -0x205d + -0x27eb * -0x1);
            if (_0x1d88f0 === _0x557578)
                break;
            else
                _0x5d8bc5['push'](_0x5d8bc5['shift']());
        } catch (_0x1b5f1c) {
            _0x5d8bc5['push'](_0x5d8bc5['shift']());
        }
    }
}(_0x42fb, -0x25bee + 0x161 * -0xd8 + 0x93ef7));
function _0x3af3(_0x561d2b, _0x2fed64) {
    _0x561d2b = _0x561d2b - (0x3 * 0x105 + 0x20 * 0xfb + -0x13 * 0x1c1);
    const _0x4e8639 = _0x42fb();
    let _0xe95bfd = _0x4e8639[_0x561d2b];
    return _0xe95bfd;
}
const moment = require(_0x3334da(0x12d)), Device = require(_0x3334da(0x1fa) + _0x3334da(0x279)), EventEmitter = require(_0x3334da(0x174)), {callVerifyAPI, callNotifyMessage} = require(_0x3334da(0x23c) + _0x3334da(0x19e)), LicenseService = require(_0x3334da(0x1dc) + _0x3334da(0x262)), SessionPending = require(_0x3334da(0x1fa) + _0x3334da(0x1cf) + _0x3334da(0x281)), {getLogger} = require(_0x3334da(0x1d0) + _0x3334da(0x18d)), logger = getLogger({
        'logDir': _0x3334da(0x1e3),
        'maxLogDays': 0x7,
        'dateFormat': _0x3334da(0x15e),
        'logFormat': _0x3334da(0x15e) + _0x3334da(0x1a1)
    });
class WebSocketService extends EventEmitter {
    constructor() {
        const _0x38fe24 = _0x3334da, _0x6431d = { 'ouTBr': _0x38fe24(0x237) + _0x38fe24(0x26f) }, _0x4827af = _0x6431d[_0x38fe24(0x1b1)][_0x38fe24(0x1f3)]('|');
        let _0x38ac41 = -0x4 * 0x425 + -0x2075 + -0x3109 * -0x1;
        while (!![]) {
            switch (_0x4827af[_0x38ac41++]) {
            case '0':
                super();
                continue;
            case '1':
                this[_0x38fe24(0x1ba) + _0x38fe24(0x243)] = new Map();
                continue;
            case '2':
                this[_0x38fe24(0x1b2) + _0x38fe24(0x1b5)] = new Map();
                continue;
            case '3':
                this[_0x38fe24(0x1de)] = null;
                continue;
            case '4':
                this[_0x38fe24(0x1b2) + 'ts'] = new Map();
                continue;
            case '5':
                this[_0x38fe24(0x190)] = new Map();
                continue;
            case '6':
                this[_0x38fe24(0x134) + _0x38fe24(0x208)] = new Map();
                continue;
            }
            break;
        }
    }
    [_0x3334da(0x242)](_0x1ed627) {
        const _0x1e871c = _0x3334da, _0x5d8eca = {
                'PkakC': function (_0x3724b6, _0xb0fa35) {
                    return _0x3724b6 === _0xb0fa35;
                },
                'hydCY': function (_0x184e8e) {
                    return _0x184e8e();
                },
                'PYeCh': _0x1e871c(0x15e) + _0x1e871c(0x1a1),
                'BgMym': _0x1e871c(0x194),
                'CqRXc': _0x1e871c(0x250),
                'xaWcB': function (_0x515c11, _0x53de6a, _0x5a721a) {
                    return _0x515c11(_0x53de6a, _0x5a721a);
                },
                'cMTjI': _0x1e871c(0x280)
            };
        this[_0x1e871c(0x1de)] = _0x1ed627, this[_0x1e871c(0x1de)]['on'](_0x5d8eca[_0x1e871c(0x1c7)], (_0x4ba278, _0x43ecd9) => this[_0x1e871c(0x138) + _0x1e871c(0x129)](_0x4ba278, _0x43ecd9));
        const _0x6e1642 = _0x5d8eca[_0x1e871c(0x1c6)](setInterval, () => {
            const _0xb9530d = _0x1e871c;
            this[_0xb9530d(0x1de)][_0xb9530d(0x125)][_0xb9530d(0x1ec)](_0x1c8182 => {
                const _0x5cd7f3 = _0xb9530d;
                if (_0x5d8eca[_0x5cd7f3(0x14b)](_0x1c8182[_0x5cd7f3(0x228)], ![]))
                    return console[_0x5cd7f3(0x1d9)]('[' + _0x5d8eca[_0x5cd7f3(0x159)](moment)[_0x5cd7f3(0x22e)](_0x5d8eca[_0x5cd7f3(0x17e)]) + (_0x5cd7f3(0x265) + _0x5cd7f3(0x1b0) + _0x5cd7f3(0x1b7) + _0x5cd7f3(0x26a)) + (_0x1c8182['sn'] || _0x5d8eca[_0x5cd7f3(0x231)])), _0x1c8182[_0x5cd7f3(0x1a2)]();
                _0x1c8182[_0x5cd7f3(0x228)] = ![], _0x1c8182[_0x5cd7f3(0x12a)]();
            });
        }, -0x55b8 + -0x8e6a + 0x15952);
        this[_0x1e871c(0x1de)]['on'](_0x5d8eca[_0x1e871c(0x1a7)], () => clearInterval(_0x6e1642));
    }
    async [_0x3334da(0x267) + _0x3334da(0x234)]() {
        const _0x3b7d90 = _0x3334da, _0x591e3c = {
                'LNNtr': _0x3b7d90(0x275),
                'hxIZx': _0x3b7d90(0x258) + _0x3b7d90(0x21a) + _0x3b7d90(0x256) + _0x3b7d90(0x171),
                'DUXfi': _0x3b7d90(0x247) + _0x3b7d90(0x170) + _0x3b7d90(0x13c) + 's:'
            };
        try {
            await Device[_0x3b7d90(0x210)]({ 'status': _0x591e3c[_0x3b7d90(0x18f)] }, { 'where': {} }), console[_0x3b7d90(0x1d9)](_0x591e3c[_0x3b7d90(0x156)]);
        } catch (_0xd28d0b) {
            console[_0x3b7d90(0x197)](_0x591e3c[_0x3b7d90(0x1d5)], _0xd28d0b[_0x3b7d90(0x198)]);
        }
    }
    async [_0x3334da(0x138) + _0x3334da(0x129)](_0x248c57, _0x5613c0) {
        const _0x2e7368 = _0x3334da, _0x2e2f20 = {
                'KCVMN': function (_0x28a3a5) {
                    return _0x28a3a5();
                },
                'fKGXv': _0x2e7368(0x15e) + _0x2e7368(0x1a1),
                'uFrqA': _0x2e7368(0x14e) + 'i',
                'uIhWn': _0x2e7368(0x147),
                'HUyJS': _0x2e7368(0x187),
                'qDNUs': function (_0x202aa6) {
                    return _0x202aa6();
                },
                'VwSAX': _0x2e7368(0x204) + _0x2e7368(0x14f),
                'XEwMW': function (_0x4c6b6c) {
                    return _0x4c6b6c();
                },
                'CJJjv': _0x2e7368(0x137) + _0x2e7368(0x23b),
                'CWBDD': _0x2e7368(0x24a),
                'IoBVf': function (_0x149c8f) {
                    return _0x149c8f();
                },
                'WHyvC': _0x2e7368(0x279),
                'ZtUGP': function (_0x20b0a2) {
                    return _0x20b0a2();
                },
                'VqAhO': _0x2e7368(0x128),
                'oGZVK': _0x2e7368(0x198),
                'zsepz': _0x2e7368(0x280),
                'dOitw': _0x2e7368(0x197)
            }, _0x2f99ad = await LicenseService[_0x2e7368(0x22b) + _0x2e7368(0x20a)]();
        if (!_0x2f99ad[_0x2e7368(0x1b9)]) {
            console[_0x2e7368(0x1d9)]('[' + _0x2e2f20[_0x2e7368(0x263)](moment)[_0x2e7368(0x22e)](_0x2e2f20[_0x2e7368(0x1e0)]) + (_0x2e7368(0x19d) + _0x2e7368(0x133) + _0x2e7368(0x1ee)) + _0x2f99ad[_0x2e7368(0x197)]), _0x248c57[_0x2e7368(0x280)](0xd * 0x171 + -0x2 * 0x10fc + 0x132b, _0x2e7368(0x1fd) + _0x2e7368(0x26d) + _0x2f99ad[_0x2e7368(0x197)]);
            return;
        }
        const _0xae0418 = _0x5613c0[_0x2e7368(0x15f)][_0x2e7368(0x1a4) + _0x2e7368(0x149)];
        _0x248c57[_0x2e7368(0x266)] = _0xae0418, _0x248c57[_0x2e7368(0x228)] = !![];
        if (_0x5613c0[_0x2e7368(0x1f6)][_0x2e7368(0x140)](_0x2e2f20[_0x2e7368(0x155)])) {
            _0x248c57[_0x2e7368(0x12c)] = _0x2e2f20[_0x2e7368(0x122)];
            const _0x49e3f4 = _0x5613c0[_0x2e7368(0x1f6)][_0x2e7368(0x1f3)]('?'), _0x28fd62 = new URLSearchParams(_0x49e3f4[-0x59 * 0x3b + -0x1eb8 + 0x333c] || ''), _0x229b01 = _0x28fd62[_0x2e7368(0x278)]('sn'), _0x54c6c2 = _0x28fd62[_0x2e7368(0x278)](_0x2e2f20[_0x2e7368(0x1e5)]) || _0x2e7368(0x13a) + Date[_0x2e7368(0x1f8)]() + '-' + Math[_0x2e7368(0x251)]()[_0x2e7368(0x240)](-0xe7 * -0x1 + 0x3c4 * 0x1 + -0x487)[_0x2e7368(0x25b)](-0x32c + -0x55f * 0x6 + 0x2368, -0xb09 + -0x15 * 0x18b + 0x2b79);
            if (!_0x229b01) {
                console[_0x2e7368(0x1d9)]('[' + _0x2e2f20[_0x2e7368(0x268)](moment)[_0x2e7368(0x22e)](_0x2e2f20[_0x2e7368(0x1e0)]) + (_0x2e7368(0x186) + _0x2e7368(0x1ea) + _0x2e7368(0x1ad) + _0x2e7368(0x19a))), _0x248c57[_0x2e7368(0x280)](0xcfb * 0x3 + -0x4bf + -0x1e42, _0x2e2f20[_0x2e7368(0x1c3)]);
                return;
            }
            _0x248c57[_0x2e7368(0x12c)] = _0x2e2f20[_0x2e7368(0x122)], _0x248c57['sn'] = _0x229b01, _0x248c57[_0x2e7368(0x187)] = _0x54c6c2, this[_0x2e7368(0x1b2) + 'ts'][_0x2e7368(0x15c)](_0x229b01, _0x248c57), this[_0x2e7368(0x1b2) + _0x2e7368(0x1b5)][_0x2e7368(0x15c)](_0x248c57, {
                'clientId': _0x54c6c2,
                'sn': _0x229b01,
                'connectedAt': new Date()
            }), console[_0x2e7368(0x1d9)]('[' + _0x2e2f20[_0x2e7368(0x172)](moment)[_0x2e7368(0x22e)](_0x2e2f20[_0x2e7368(0x1e0)]) + (_0x2e7368(0x186) + _0x2e7368(0x167) + _0x2e7368(0x25a)) + _0x54c6c2 + (_0x2e7368(0x158) + 'e\x20') + _0x229b01 + _0x2e7368(0x27e) + _0xae0418), _0x248c57[_0x2e7368(0x1e9)](JSON[_0x2e7368(0x1a5)]({
                'cmd': _0x2e2f20[_0x2e7368(0x160)],
                'ret': _0x2e2f20[_0x2e7368(0x19f)],
                'result': !![],
                'sn': _0x229b01,
                'clientId': _0x54c6c2,
                'message': _0x2e7368(0x136) + _0x2e7368(0x158) + 'e\x20' + _0x229b01,
                'timestamp': _0x2e2f20[_0x2e7368(0x199)](moment)[_0x2e7368(0x22e)](_0x2e2f20[_0x2e7368(0x1e0)])
            }));
        } else
            _0x248c57[_0x2e7368(0x12c)] = _0x2e2f20[_0x2e7368(0x176)];
        console[_0x2e7368(0x1d9)]('[' + _0x2e2f20[_0x2e7368(0x162)](moment)[_0x2e7368(0x22e)](_0x2e2f20[_0x2e7368(0x1e0)]) + (_0x2e7368(0x14a) + _0x2e7368(0x181) + 'm\x20') + _0xae0418), _0x248c57['on'](_0x2e2f20[_0x2e7368(0x230)], () => {
            const _0x293e4f = _0x2e7368;
            _0x248c57[_0x293e4f(0x228)] = !![];
        }), _0x248c57['on'](_0x2e2f20[_0x2e7368(0x12f)], _0x394ec5 => this[_0x2e7368(0x1f4) + _0x2e7368(0x17a)](_0x248c57, _0x394ec5)), _0x248c57['on'](_0x2e2f20[_0x2e7368(0x254)], () => this[_0x2e7368(0x1b4) + 'e'](_0x248c57)), _0x248c57['on'](_0x2e2f20[_0x2e7368(0x1c5)], _0x36d929 => this[_0x2e7368(0x135) + 'r'](_0x248c57, _0x36d929));
    }
    async [_0x3334da(0x1f4) + _0x3334da(0x17a)](_0x4cdcfc, _0x1a54a6) {
        const _0x36257a = _0x3334da, _0x37153e = {
                'skain': function (_0x3417ca) {
                    return _0x3417ca();
                },
                'IDFvq': _0x36257a(0x15e) + _0x36257a(0x1a1),
                'nfReY': _0x36257a(0x194),
                'BIKWx': function (_0x56c925, _0xdeeaff) {
                    return _0x56c925 === _0xdeeaff;
                },
                'QXhVL': _0x36257a(0x147),
                'BslsC': _0x36257a(0x164) + _0x36257a(0x1cc),
                'ikcCB': function (_0x387298) {
                    return _0x387298();
                },
                'zxXtr': _0x36257a(0x1d9),
                'zlMJv': _0x36257a(0x21b),
                'omWgl': function (_0x5575c5, _0x3675ee) {
                    return _0x5575c5 === _0x3675ee;
                },
                'qbgDm': _0x36257a(0x137) + _0x36257a(0x23b),
                'gGTog': _0x36257a(0x173) + _0x36257a(0x193) + 'e:'
            };
        try {
            const _0x3b7aff = await LicenseService[_0x36257a(0x22b) + _0x36257a(0x20a)]();
            if (!_0x3b7aff[_0x36257a(0x1b9)]) {
                console[_0x36257a(0x1d9)]('[' + _0x37153e[_0x36257a(0x224)](moment)[_0x36257a(0x22e)](_0x37153e[_0x36257a(0x145)]) + (_0x36257a(0x1db) + _0x36257a(0x272)) + (_0x4cdcfc['sn'] || _0x37153e[_0x36257a(0x200)]) + (_0x36257a(0x218) + '\x20') + _0x3b7aff[_0x36257a(0x197)]), _0x4cdcfc[_0x36257a(0x280)](-0x1 * -0x2291 + -0x207 * 0xa + -0xa5b, _0x36257a(0x1fd) + _0x36257a(0x26d) + _0x3b7aff[_0x36257a(0x197)]);
                return;
            }
            const _0x8b93a3 = _0x1a54a6[_0x36257a(0x240)](), _0x58c38c = JSON[_0x36257a(0x24d)](_0x8b93a3), {
                    cmd: _0x14bf3e,
                    ret: _0x3c02dd
                } = _0x58c38c, _0x14710f = _0x37153e[_0x36257a(0x1fc)](_0x4cdcfc[_0x36257a(0x12c)], _0x37153e[_0x36257a(0x24e)]) ? _0x4cdcfc[_0x36257a(0x187)] + '\x20(' + _0x4cdcfc['sn'] + ')' : _0x4cdcfc['sn'] || _0x37153e[_0x36257a(0x273)];
            console[_0x36257a(0x1d9)]('[' + _0x37153e[_0x36257a(0x27a)](moment)[_0x36257a(0x22e)](_0x37153e[_0x36257a(0x145)]) + (_0x36257a(0x123) + _0x36257a(0x27e)) + _0x4cdcfc[_0x36257a(0x12c)] + '\x20' + _0x14710f + ':', this[_0x36257a(0x229) + _0x36257a(0x11c)](_0x58c38c)), this[_0x36257a(0x130)](_0x37153e[_0x36257a(0x212)], {
                'timestamp': _0x37153e[_0x36257a(0x27a)](moment)[_0x36257a(0x22e)](_0x37153e[_0x36257a(0x145)]),
                'sn': _0x4cdcfc['sn'],
                'clientId': _0x4cdcfc[_0x36257a(0x187)],
                'clientType': _0x4cdcfc[_0x36257a(0x12c)],
                'sn': _0x4cdcfc['sn'],
                'type': _0x37153e[_0x36257a(0x15a)],
                'data': _0x58c38c
            });
            if (_0x37153e[_0x36257a(0x238)](_0x14bf3e, _0x37153e[_0x36257a(0x21c)])) {
            } else {
                if (_0x14bf3e)
                    this[_0x36257a(0x131) + _0x36257a(0x23e)](_0x4cdcfc, _0x14bf3e, _0x58c38c);
                else
                    _0x3c02dd && this[_0x36257a(0x131) + _0x36257a(0x270)](_0x4cdcfc, _0x3c02dd, _0x58c38c);
            }
        } catch (_0x4a2e1a) {
            console[_0x36257a(0x197)](_0x37153e[_0x36257a(0x11d)], _0x4a2e1a[_0x36257a(0x198)]);
        }
    }
    async [_0x3334da(0x131) + _0x3334da(0x23e)](_0x49314, _0x1fcbd1, _0x1915c6) {
        const _0x8ea9e4 = _0x3334da, _0x407fac = {
                'bydhL': function (_0x9ac6dc, _0x1a7690) {
                    return _0x9ac6dc + _0x1a7690;
                },
                'YEptX': _0x8ea9e4(0x19c) + _0x8ea9e4(0x18a) + _0x8ea9e4(0x27b) + _0x8ea9e4(0x27f),
                'hSKYY': _0x8ea9e4(0x1c8),
                'RmQbV': _0x8ea9e4(0x247) + _0x8ea9e4(0x211) + _0x8ea9e4(0x16e) + _0x8ea9e4(0x16b),
                'SSaeW': _0x8ea9e4(0x259),
                'UCTbG': function (_0x4e171a) {
                    return _0x4e171a();
                },
                'tuEDy': _0x8ea9e4(0x15e) + _0x8ea9e4(0x1a1),
                'WSkSV': _0x8ea9e4(0x205),
                'yqHRG': function (_0x4f7b39, _0x4bef1d) {
                    return _0x4f7b39 > _0x4bef1d;
                },
                'TnaIe': function (_0x158efa, _0x7a7f8f, _0x3d6a1e) {
                    return _0x158efa(_0x7a7f8f, _0x3d6a1e);
                },
                'rVami': function (_0x1808e5, _0x35f4de) {
                    return _0x1808e5 === _0x35f4de;
                },
                'CcsGL': _0x8ea9e4(0x206),
                'haRSP': _0x8ea9e4(0x261),
                'glyda': _0x8ea9e4(0x157) + _0x8ea9e4(0x175) + _0x8ea9e4(0x22a),
                'KXRKO': _0x8ea9e4(0x188),
                'DvTrW': function (_0x59fa76) {
                    return _0x59fa76();
                },
                'WVWmQ': _0x8ea9e4(0x195)
            };
        console[_0x8ea9e4(0x1d9)](_0x407fac[_0x8ea9e4(0x1a0)](_0x407fac[_0x8ea9e4(0x1b8)], _0x1fcbd1));
        const _0x2c1702 = _0x1915c6['sn'];
        this[_0x8ea9e4(0x134) + _0x8ea9e4(0x208)][_0x8ea9e4(0x15c)](_0x2c1702, _0x49314), _0x49314['sn'] = _0x2c1702;
        try {
            await Device[_0x8ea9e4(0x27c)]({
                'sn': _0x2c1702,
                'status': _0x407fac[_0x8ea9e4(0x17f)],
                'last_seen': new Date(),
                'ip_address': _0x49314[_0x8ea9e4(0x266)]
            });
        } catch (_0x527945) {
            console[_0x8ea9e4(0x197)](_0x407fac[_0x8ea9e4(0x1e8)], _0x527945[_0x8ea9e4(0x198)]);
        }
        switch (_0x1fcbd1) {
        case _0x407fac[_0x8ea9e4(0x163)]:
            _0x49314[_0x8ea9e4(0x1e9)](JSON[_0x8ea9e4(0x1a5)]({
                'ret': _0x407fac[_0x8ea9e4(0x163)],
                'result': !![],
                'cloudtime': _0x407fac[_0x8ea9e4(0x21f)](moment)[_0x8ea9e4(0x22e)](_0x407fac[_0x8ea9e4(0x1bc)]),
                'nosenduser': ![]
            })), console[_0x8ea9e4(0x1d9)]('[' + _0x407fac[_0x8ea9e4(0x21f)](moment)[_0x8ea9e4(0x22e)](_0x407fac[_0x8ea9e4(0x1bc)]) + (_0x8ea9e4(0x1aa) + _0x8ea9e4(0x1fe) + '\x20') + _0x2c1702);
            break;
        case _0x407fac[_0x8ea9e4(0x16c)]:
            const _0xaefd71 = _0x1915c6[_0x8ea9e4(0x1c4)] || -0x1116 + 0x407 + 0xd0f * 0x1, _0x367eec = _0x1915c6[_0x8ea9e4(0x1be)] || 0x13 * -0x18 + -0x1ffa * 0x1 + 0x21c2;
            _0x1915c6[_0x8ea9e4(0x1d6)] && _0x407fac[_0x8ea9e4(0x141)](_0x1915c6[_0x8ea9e4(0x1d6)][_0x8ea9e4(0x168)], -0xe2 * -0x19 + -0x1 * -0xde7 + 0x1 * -0x23f9) && _0x1915c6[_0x8ea9e4(0x1d6)][-0xd34 * -0x1 + -0xccf + -0x65][_0x8ea9e4(0x1bb)] && this[_0x8ea9e4(0x190)][_0x8ea9e4(0x15c)](_0x1915c6['sn'] || _0x49314['sn'], _0x1915c6[_0x8ea9e4(0x1d6)][0x55 * 0x5 + 0x1 * 0x1933 + 0x8f4 * -0x3][_0x8ea9e4(0x1bb)]);
            try {
                const _0xd66c78 = await _0x407fac[_0x8ea9e4(0x1c0)](callVerifyAPI, _0x1915c6[_0x8ea9e4(0x1d6)][-0x1fd * -0x3 + 0x1d56 + -0x234d][_0x8ea9e4(0x1bb)], _0x1915c6['sn']);
                logger[_0x8ea9e4(0x152)](_0x8ea9e4(0x1e1) + _0x8ea9e4(0x15d) + _0x8ea9e4(0x1f9) + _0x8ea9e4(0x214) + '\x20' + _0x1915c6['sn'] + (_0x8ea9e4(0x26e) + ':\x20') + JSON[_0x8ea9e4(0x1a5)](_0xd66c78)), _0x407fac[_0x8ea9e4(0x23a)](_0xd66c78[_0x8ea9e4(0x213)], _0x407fac[_0x8ea9e4(0x179)]) ? (this[_0x8ea9e4(0x1b6) + _0x8ea9e4(0x13b)](_0x49314['sn'], {
                    'cmd': _0x407fac[_0x8ea9e4(0x1e4)],
                    'result': !![],
                    'doornum': 0x1,
                    'boardingPass': _0xd66c78[_0x8ea9e4(0x221) + 'ss'],
                    'title': _0xd66c78[_0x8ea9e4(0x143)],
                    'message': _0xd66c78[_0x8ea9e4(0x198)],
                    'customerName': _0xd66c78[_0x8ea9e4(0x1bf) + 'me']
                }), logger[_0x8ea9e4(0x152)](_0x8ea9e4(0x1e1) + _0x8ea9e4(0x15d) + _0x8ea9e4(0x252) + _0x8ea9e4(0x139) + ':\x20' + _0x1915c6['sn'] + (_0x8ea9e4(0x26e) + _0x8ea9e4(0x249) + _0x8ea9e4(0x203) + _0x8ea9e4(0x1df))), SessionPending[_0x8ea9e4(0x215)]({
                    'sessionId': _0xd66c78[_0x8ea9e4(0x244)],
                    'status': 0x0,
                    'sn': _0x1915c6['sn']
                }), logger[_0x8ea9e4(0x152)](_0x8ea9e4(0x1e1) + _0x8ea9e4(0x15d) + _0x8ea9e4(0x1a8) + _0x8ea9e4(0x24f) + _0x8ea9e4(0x1ac) + _0x8ea9e4(0x202) + _0x8ea9e4(0x26c) + _0x8ea9e4(0x18e) + _0x1915c6['sn'] + (_0x8ea9e4(0x1ab) + _0x8ea9e4(0x277)) + _0xd66c78[_0x8ea9e4(0x244)])) : await this[_0x8ea9e4(0x1b6) + _0x8ea9e4(0x13b)](_0x49314['sn'], {
                    'cmd': _0x407fac[_0x8ea9e4(0x1e4)],
                    'result': ![],
                    'doornum': 0x1,
                    'boardingPass': _0xd66c78[_0x8ea9e4(0x221) + 'ss'],
                    'title': _0xd66c78[_0x8ea9e4(0x143)],
                    'message': _0xd66c78[_0x8ea9e4(0x198)],
                    'customerName': _0xd66c78[_0x8ea9e4(0x1bf) + 'me']
                });
            } catch (_0x1f2b34) {
                logger[_0x8ea9e4(0x197)](_0x8ea9e4(0x1e1) + _0x8ea9e4(0x15d) + _0x8ea9e4(0x22f) + _0x8ea9e4(0x24c) + _0x1915c6['sn'] + _0x8ea9e4(0x13f) + _0x1f2b34[_0x8ea9e4(0x198)]);
                try {
                    await this[_0x8ea9e4(0x1b6) + _0x8ea9e4(0x13b)](_0x1915c6['sn'], {
                        'cmd': _0x407fac[_0x8ea9e4(0x1e4)],
                        'result': ![],
                        'doornum': 0x1,
                        'message': _0x407fac[_0x8ea9e4(0x19b)],
                        'title': _0x407fac[_0x8ea9e4(0x16d)],
                        'customerName': ''
                    });
                } catch (_0x24d30b) {
                    logger[_0x8ea9e4(0x197)](_0x8ea9e4(0x1e1) + _0x8ea9e4(0x15d) + _0x8ea9e4(0x225) + _0x8ea9e4(0x246) + _0x8ea9e4(0x257) + _0x8ea9e4(0x236) + _0x1915c6['sn'] + _0x8ea9e4(0x13f) + _0x24d30b[_0x8ea9e4(0x198)]);
                }
            }
            _0x49314[_0x8ea9e4(0x1e9)](JSON[_0x8ea9e4(0x1a5)]({
                'ret': _0x407fac[_0x8ea9e4(0x16c)],
                'result': !![],
                'count': _0xaefd71,
                'logindex': _0x367eec,
                'cloudtime': _0x407fac[_0x8ea9e4(0x148)](moment)[_0x8ea9e4(0x22e)](_0x407fac[_0x8ea9e4(0x1bc)]),
                'access': 0x1
            }));
            break;
        case _0x407fac[_0x8ea9e4(0x184)]:
            _0x1915c6[_0x8ea9e4(0x1d6)] && this[_0x8ea9e4(0x190)][_0x8ea9e4(0x15c)](_0x1915c6['sn'] || _0x49314['sn'], _0x1915c6[_0x8ea9e4(0x1d6)]);
            _0x49314[_0x8ea9e4(0x1e9)](JSON[_0x8ea9e4(0x1a5)]({
                'ret': _0x407fac[_0x8ea9e4(0x184)],
                'result': !![],
                'enrollid': _0x1915c6[_0x8ea9e4(0x25c)],
                'backupnum': _0x1915c6[_0x8ea9e4(0x20d)]
            }));
            break;
        }
    }
    [_0x3334da(0x131) + _0x3334da(0x270)](_0x4bfeca, _0x366a28, _0x148a3b) {
        const _0x570dec = _0x3334da, _0x3e97db = {
                'aBtuI': _0x570dec(0x271),
                'DhjlX': _0x570dec(0x151),
                'RkgCP': function (_0x279da9) {
                    return _0x279da9();
                },
                'SevXd': _0x570dec(0x15e) + _0x570dec(0x1a1),
                'sCkBT': _0x570dec(0x1d9),
                'aEvFx': _0x570dec(0x18b)
            }, _0x157936 = _0x148a3b[_0x570dec(0x207)] ? _0x3e97db[_0x570dec(0x182)] : _0x3e97db[_0x570dec(0x1d3)], _0x2474ce = _0x148a3b[_0x570dec(0x232)] ? _0x570dec(0x27d) + _0x148a3b[_0x570dec(0x232)] + ')' : '';
        console[_0x570dec(0x1d9)]('[' + _0x3e97db[_0x570dec(0x1e7)](moment)[_0x570dec(0x22e)](_0x3e97db[_0x570dec(0x22c)]) + (_0x570dec(0x1aa) + _0x570dec(0x1eb) + '\x20') + _0x366a28 + ':\x20' + _0x157936 + _0x2474ce);
        if (_0x4bfeca['sn']) {
            const _0x42578a = _0x4bfeca['sn'] + ':' + _0x366a28, _0x15f95c = this[_0x570dec(0x1ba) + _0x570dec(0x243)][_0x570dec(0x278)](_0x42578a);
            _0x15f95c && (_0x15f95c[_0x570dec(0x150)](_0x148a3b), this[_0x570dec(0x1ba) + _0x570dec(0x243)][_0x570dec(0x1d4)](_0x42578a));
        }
        this[_0x570dec(0x130)](_0x3e97db[_0x570dec(0x165)], {
            'timestamp': _0x3e97db[_0x570dec(0x1e7)](moment)[_0x570dec(0x22e)](_0x3e97db[_0x570dec(0x22c)]),
            'sn': _0x4bfeca['sn'],
            'type': _0x3e97db[_0x570dec(0x21d)],
            'command': _0x366a28,
            'result': _0x157936,
            'reason': _0x2474ce,
            'data': _0x148a3b
        });
    }
    async [_0x3334da(0x1b4) + 'e'](_0x40c921) {
        const _0x323086 = _0x3334da, _0x48973f = {
                'peJVu': _0x323086(0x1d9),
                'tdWcR': function (_0x497d32) {
                    return _0x497d32();
                },
                'hvABe': _0x323086(0x15e) + _0x323086(0x1a1),
                'UFLXe': _0x323086(0x177) + 'ED',
                'NeJCT': function (_0x1d24ed, _0x2912f5) {
                    return _0x1d24ed === _0x2912f5;
                },
                'rlVmm': function (_0x4ac794) {
                    return _0x4ac794();
                },
                'xKNJw': _0x323086(0x275),
                'OuNsa': _0x323086(0x247) + _0x323086(0x189) + _0x323086(0x1d1) + _0x323086(0x12b) + _0x323086(0x235),
                'tipyF': function (_0x36178c) {
                    return _0x36178c();
                }
            };
        if (_0x40c921['sn']) {
            this[_0x323086(0x130)](_0x48973f[_0x323086(0x1af)], {
                'timestamp': _0x48973f[_0x323086(0x161)](moment)[_0x323086(0x22e)](_0x48973f[_0x323086(0x180)]),
                'sn': _0x40c921['sn'],
                'type': _0x48973f[_0x323086(0x13d)],
                'message': _0x323086(0x23f) + _0x40c921['sn'] + (_0x323086(0x216) + _0x323086(0x276))
            });
            if (_0x48973f[_0x323086(0x1d8)](this[_0x323086(0x134) + _0x323086(0x208)][_0x323086(0x278)](_0x40c921['sn']), _0x40c921)) {
                this[_0x323086(0x134) + _0x323086(0x208)][_0x323086(0x1d4)](_0x40c921['sn']), console[_0x323086(0x1d9)]('[' + _0x48973f[_0x323086(0x223)](moment)[_0x323086(0x22e)](_0x48973f[_0x323086(0x180)]) + (_0x323086(0x25d) + _0x323086(0x222) + _0x323086(0x1ee)) + _0x40c921['sn']);
                try {
                    await Device[_0x323086(0x210)]({
                        'status': _0x48973f[_0x323086(0x1fb)],
                        'last_seen': new Date()
                    }, { 'where': { 'sn': _0x40c921['sn'] } });
                } catch (_0xb9e4ce) {
                    console[_0x323086(0x197)](_0x48973f[_0x323086(0x18c)], _0xb9e4ce[_0x323086(0x198)]);
                }
            } else
                console[_0x323086(0x1d9)]('[' + _0x48973f[_0x323086(0x17d)](moment)[_0x323086(0x22e)](_0x48973f[_0x323086(0x180)]) + (_0x323086(0x1d2) + _0x323086(0x1ff) + _0x323086(0x1dd) + _0x323086(0x20e)) + _0x40c921['sn']);
        }
    }
    [_0x3334da(0x135) + 'r'](_0x1fb09b, _0x50ef08) {
        const _0x381475 = _0x3334da, _0x4687a2 = {
                'WiSiJ': _0x381475(0x1d9),
                'okpXi': function (_0xa5f44a) {
                    return _0xa5f44a();
                },
                'kmOPd': _0x381475(0x15e) + _0x381475(0x1a1),
                'NLhHO': _0x381475(0x264)
            };
        _0x1fb09b['sn'] && this[_0x381475(0x130)](_0x4687a2[_0x381475(0x1f1)], {
            'timestamp': _0x4687a2[_0x381475(0x142)](moment)[_0x381475(0x22e)](_0x4687a2[_0x381475(0x226)]),
            'sn': _0x1fb09b['sn'],
            'type': _0x4687a2[_0x381475(0x1f7)],
            'message': _0x381475(0x239) + _0x381475(0x20b) + _0x1fb09b['sn'] + ':\x20' + _0x50ef08[_0x381475(0x198)]
        }), console[_0x381475(0x197)]('[' + _0x4687a2[_0x381475(0x142)](moment)[_0x381475(0x22e)](_0x4687a2[_0x381475(0x226)]) + (_0x381475(0x1b3) + _0x381475(0x13e)), _0x50ef08[_0x381475(0x198)]);
    }
    async [_0x3334da(0x1b6) + _0x3334da(0x13b)](_0x2a1bbf, _0x211db8, _0x4a741c = -0x4bb1 + -0x439d + -0x3 * -0x3cca) {
        const _0x2551c5 = _0x3334da, _0x1767df = {
                'BFsmg': function (_0x1cea41, _0x27fa34) {
                    return _0x1cea41(_0x27fa34);
                },
                'fBgOE': function (_0x41b0c6, _0x3ceaa4) {
                    return _0x41b0c6(_0x3ceaa4);
                },
                'TkkAz': function (_0x386b05, _0x1ef853) {
                    return _0x386b05(_0x1ef853);
                },
                'ggAsQ': function (_0x4fd48f, _0x5c5703, _0x44471c) {
                    return _0x4fd48f(_0x5c5703, _0x44471c);
                },
                'eDmEF': function (_0x2ae9f3, _0x396b75) {
                    return _0x2ae9f3 === _0x396b75;
                },
                'zMuya': function (_0x66228a) {
                    return _0x66228a();
                },
                'XEVZq': _0x2551c5(0x15e) + _0x2551c5(0x1a1),
                'nAYUC': _0x2551c5(0x1d9),
                'fFoYN': function (_0x12cdb7) {
                    return _0x12cdb7();
                },
                'fjdwU': _0x2551c5(0x1ed)
            }, _0x539a7e = this[_0x2551c5(0x134) + _0x2551c5(0x208)][_0x2551c5(0x278)](_0x2a1bbf);
        if (_0x539a7e && _0x1767df[_0x2551c5(0x1c1)](_0x539a7e[_0x2551c5(0x144)], -0x1 * -0x1f97 + -0x2 * -0xa54 + 0x343e * -0x1)) {
            const _0x412807 = _0x211db8[_0x2551c5(0x16f)], _0x4ce3f8 = _0x2a1bbf + ':' + _0x412807;
            return _0x539a7e[_0x2551c5(0x1e9)](JSON[_0x2551c5(0x1a5)](_0x211db8)), console[_0x2551c5(0x1d9)]('[' + _0x1767df[_0x2551c5(0x24b)](moment)[_0x2551c5(0x22e)](_0x1767df[_0x2551c5(0x219)]) + (_0x2551c5(0x196) + _0x2551c5(0x154)) + _0x2a1bbf + ':', JSON[_0x2551c5(0x1a5)](_0x211db8)), this[_0x2551c5(0x130)](_0x1767df[_0x2551c5(0x227)], {
                'timestamp': _0x1767df[_0x2551c5(0x21e)](moment)[_0x2551c5(0x22e)](_0x1767df[_0x2551c5(0x219)]),
                'sn': _0x2a1bbf,
                'type': _0x1767df[_0x2551c5(0x201)],
                'data': _0x211db8
            }), new Promise((_0x406240, _0x49fd58) => {
                const _0x13ce58 = _0x2551c5, _0x1e5c94 = {
                        'qcOmY': function (_0x554187, _0x45d1b6) {
                            const _0x189d48 = _0x3af3;
                            return _0x1767df[_0x189d48(0x209)](_0x554187, _0x45d1b6);
                        },
                        'cROzV': function (_0x236fd4, _0x85dcac) {
                            const _0x1135b1 = _0x3af3;
                            return _0x1767df[_0x1135b1(0x1e6)](_0x236fd4, _0x85dcac);
                        },
                        'JZoKX': function (_0x57d0c5, _0x2e1e24) {
                            const _0x28a766 = _0x3af3;
                            return _0x1767df[_0x28a766(0x26b)](_0x57d0c5, _0x2e1e24);
                        }
                    }, _0x1e0e84 = _0x1767df[_0x13ce58(0x1bd)](setTimeout, () => {
                        const _0x2a8773 = _0x13ce58;
                        this[_0x2a8773(0x1ba) + _0x2a8773(0x243)][_0x2a8773(0x220)](_0x4ce3f8) && (this[_0x2a8773(0x1ba) + _0x2a8773(0x243)][_0x2a8773(0x1d4)](_0x4ce3f8), _0x1e5c94[_0x2a8773(0x20c)](_0x406240, {
                            'result': ![],
                            'timeout': !![],
                            'message': _0x2a8773(0x146) + _0x2a8773(0x121) + _0x2a8773(0x1da) + _0x2a8773(0x1f2) + '\x20' + _0x2a1bbf + (_0x2a8773(0x169) + _0x2a8773(0x1ae)) + _0x412807
                        }));
                    }, _0x4a741c);
                this[_0x13ce58(0x1ba) + _0x13ce58(0x243)][_0x13ce58(0x15c)](_0x4ce3f8, {
                    'resolve': _0x2bb9d2 => {
                        const _0x23237f = _0x13ce58;
                        _0x1e5c94[_0x23237f(0x20c)](clearTimeout, _0x1e0e84), _0x1e5c94[_0x23237f(0x153)](_0x406240, _0x2bb9d2);
                    },
                    'reject': _0x31abe9 => {
                        const _0x3e9812 = _0x13ce58;
                        _0x1e5c94[_0x3e9812(0x20c)](clearTimeout, _0x1e0e84), _0x1e5c94[_0x3e9812(0x1e2)](_0x49fd58, _0x31abe9);
                    }
                });
            });
        }
        console[_0x2551c5(0x245)]('[' + _0x1767df[_0x2551c5(0x21e)](moment)[_0x2551c5(0x22e)](_0x1767df[_0x2551c5(0x219)]) + _0x2551c5(0x14c) + _0x2a1bbf + (_0x2551c5(0x241) + _0x2551c5(0x1cd) + _0x2551c5(0x269)));
        throw new Error(_0x2551c5(0x23f) + _0x2a1bbf + (_0x2551c5(0x241) + _0x2551c5(0x1cd) + _0x2551c5(0x14d)));
    }
    [_0x3334da(0x1f5) + _0x3334da(0x124)](_0x57e7a0, _0x9052ca) {
        const _0x2a7654 = _0x3334da, _0x5e6cd2 = {
                'oAmVq': function (_0x1e43f9, _0x431219) {
                    return _0x1e43f9 === _0x431219;
                },
                'mhNCh': _0x2a7654(0x1a9),
                'pdxQr': function (_0x2c8312) {
                    return _0x2c8312();
                },
                'BeZuS': _0x2a7654(0x15e) + _0x2a7654(0x1a1),
                'jEDHI': function (_0xe8d2bb) {
                    return _0xe8d2bb();
                }
            }, _0x2fbbd9 = this[_0x2a7654(0x1b2) + 'ts'][_0x2a7654(0x278)](_0x57e7a0);
        if (_0x2fbbd9 && _0x5e6cd2[_0x2a7654(0x274)](_0x2fbbd9[_0x2a7654(0x144)], 0x1 * -0x1d0b + -0x2577 + 0x4283))
            try {
                const _0x1461e4 = {
                    'cmd': _0x5e6cd2[_0x2a7654(0x22d)],
                    'event': _0x9052ca[_0x2a7654(0x126)],
                    'sn': _0x57e7a0,
                    'data': _0x9052ca[_0x2a7654(0x11e)],
                    'timestamp': _0x5e6cd2[_0x2a7654(0x178)](moment)[_0x2a7654(0x22e)](_0x5e6cd2[_0x2a7654(0x253)])
                };
                return _0x2fbbd9[_0x2a7654(0x1e9)](JSON[_0x2a7654(0x1a5)](_0x1461e4)), console[_0x2a7654(0x1d9)]('[' + _0x5e6cd2[_0x2a7654(0x178)](moment)[_0x2a7654(0x22e)](_0x5e6cd2[_0x2a7654(0x253)]) + (_0x2a7654(0x1ca) + _0x2a7654(0x192) + _0x2a7654(0x1ef) + '\x20') + _0x57e7a0 + ':\x20' + _0x9052ca[_0x2a7654(0x126)]), !![];
            } catch (_0xb235d0) {
                return console[_0x2a7654(0x197)]('[' + _0x5e6cd2[_0x2a7654(0x185)](moment)[_0x2a7654(0x22e)](_0x5e6cd2[_0x2a7654(0x253)]) + (_0x2a7654(0x17b) + _0x2a7654(0x1cb) + _0x2a7654(0x16a) + _0x2a7654(0x191)) + _0x57e7a0 + ':', _0xb235d0[_0x2a7654(0x198)]), ![];
            }
        else
            return console[_0x2a7654(0x1d9)]('[' + _0x5e6cd2[_0x2a7654(0x185)](moment)[_0x2a7654(0x22e)](_0x5e6cd2[_0x2a7654(0x253)]) + (_0x2a7654(0x233) + _0x2a7654(0x217) + _0x2a7654(0x15b) + _0x2a7654(0x1f0)) + _0x57e7a0), ![];
    }
    [_0x3334da(0x20f) + 'ge'](_0x33e024) {
        const _0x4dfcb5 = _0x3334da;
        return this[_0x4dfcb5(0x190)][_0x4dfcb5(0x278)](_0x33e024);
    }
    [_0x3334da(0x229) + _0x3334da(0x11c)](_0x2ec9cc) {
        const _0x1002eb = _0x3334da, _0x45d01c = {
                'JPfsL': function (_0x393143, _0x44e9c1) {
                    return _0x393143 === _0x44e9c1;
                },
                'koLGl': _0x1002eb(0x255),
                'TnHgT': function (_0xafeab1, _0xf5bb69) {
                    return _0xafeab1 > _0xf5bb69;
                },
                'dtzmr': function (_0x354eb8, _0x12705c) {
                    return _0x354eb8 + _0x12705c;
                },
                'BTfbW': _0x1002eb(0x248)
            };
        return JSON[_0x1002eb(0x1a5)](_0x2ec9cc, (_0x3adf6f, _0xab25a2) => {
            const _0x3d39dd = _0x1002eb;
            if (_0x45d01c[_0x3d39dd(0x11f)](typeof _0xab25a2, _0x45d01c[_0x3d39dd(0x1a6)]) && _0x45d01c[_0x3d39dd(0x23d)](_0xab25a2[_0x3d39dd(0x168)], 0x36 + 0x619 * 0x3 + -0x121d))
                return _0x45d01c[_0x3d39dd(0x1c2)](_0xab25a2[_0x3d39dd(0x132)](0x1e07 + 0x19 * 0x59 + -0x26b8, 0x1 * 0xe2f + -0x502 * 0x1 + -0x8c9), _0x45d01c[_0x3d39dd(0x1ce)]);
            return _0xab25a2;
        });
    }
}
module[_0x3334da(0x166)] = new WebSocketService();