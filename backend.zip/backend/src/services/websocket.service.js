function _0x55e9(_0x259d7e, _0x2203db) {
    _0x259d7e = _0x259d7e - (-0x80a * -0x3 + 0x2 * -0x7c9 + -0x6c9);
    const _0x2e380d = _0x4a27();
    let _0x6d7a49 = _0x2e380d[_0x259d7e];
    return _0x6d7a49;
}
const _0x549366 = _0x55e9;
(function (_0x3acc7f, _0x372f4e) {
    const _0x5df72c = _0x55e9, _0x3c98d6 = _0x3acc7f();
    while (!![]) {
        try {
            const _0x43ab1a = -parseInt(_0x5df72c(0x317)) / (0xaf1 * -0x1 + -0x46d + -0x5 * -0x313) * (-parseInt(_0x5df72c(0x23f)) / (0x1b80 + -0x1a3d + -0x141)) + parseInt(_0x5df72c(0x223)) / (-0x1397 + -0x6a2 * -0x1 + 0xcf8) + -parseInt(_0x5df72c(0x2b9)) / (-0x26d2 * -0x1 + 0x1969 + -0x4037) * (-parseInt(_0x5df72c(0x2cd)) / (-0x22da + -0x1be9 + -0xc4 * -0x52)) + -parseInt(_0x5df72c(0x295)) / (0x20e9 + -0x1 * 0x1145 + -0xf9e) * (parseInt(_0x5df72c(0x241)) / (-0x1 * -0xc17 + 0x1e * 0x1e + -0xf94)) + parseInt(_0x5df72c(0x248)) / (-0x4fe + -0x17e6 + 0x1cec) * (-parseInt(_0x5df72c(0x24a)) / (0x1 * -0x54b + -0x923 * 0x1 + -0x1 * -0xe77)) + parseInt(_0x5df72c(0x218)) / (0xc * -0x2f0 + 0x2540 + -0x1f6) + -parseInt(_0x5df72c(0x26a)) / (-0xc15 + 0x1589 + -0x969);
            if (_0x43ab1a === _0x372f4e)
                break;
            else
                _0x3c98d6['push'](_0x3c98d6['shift']());
        } catch (_0x5d994a) {
            _0x3c98d6['push'](_0x3c98d6['shift']());
        }
    }
}(_0x4a27, -0xdb0b + -0x17bd8 + 0x11 * 0x3c26));
const moment = require(_0x549366(0x24e)), Device = require(_0x549366(0x242) + _0x549366(0x2fb)), EventEmitter = require(_0x549366(0x236)), {callVerifyAPI, callNotifyMessage} = require(_0x549366(0x2ff) + _0x549366(0x328)), LicenseService = require(_0x549366(0x233) + _0x549366(0x210)), SessionPending = require(_0x549366(0x242) + _0x549366(0x1e1) + _0x549366(0x30f)), {getLogger} = require(_0x549366(0x31b) + _0x549366(0x1ed)), logger = getLogger({
        'logDir': _0x549366(0x277),
        'maxLogDays': 0x7,
        'dateFormat': _0x549366(0x29c),
        'logFormat': _0x549366(0x29c) + _0x549366(0x25a)
    });
class WebSocketService extends EventEmitter {
    constructor() {
        const _0x4bce4f = _0x549366, _0x4a22ca = { 'RwUAr': _0x4bce4f(0x2b4) + _0x4bce4f(0x301) }, _0x392763 = _0x4a22ca[_0x4bce4f(0x2fd)][_0x4bce4f(0x2d4)]('|');
        let _0x40b3e5 = 0xa28 + 0x1 * 0x78d + -0x11b5;
        while (!![]) {
            switch (_0x392763[_0x40b3e5++]) {
            case '0':
                super();
                continue;
            case '1':
                this[_0x4bce4f(0x214) + _0x4bce4f(0x220)] = new Map();
                continue;
            case '2':
                this[_0x4bce4f(0x2c3) + _0x4bce4f(0x2d3)] = new Map();
                continue;
            case '3':
                this[_0x4bce4f(0x302) + 'ts'] = new Map();
                continue;
            case '4':
                this[_0x4bce4f(0x1cc)] = null;
                continue;
            case '5':
                this[_0x4bce4f(0x302) + _0x4bce4f(0x239)] = new Map();
                continue;
            case '6':
                this[_0x4bce4f(0x26e)] = new Map();
                continue;
            }
            break;
        }
    }
    [_0x549366(0x327)](_0x3d33f3) {
        const _0x3e20c2 = _0x549366, _0x41e3aa = {
                'cpwTp': function (_0x29c353, _0x22caec) {
                    return _0x29c353 === _0x22caec;
                },
                'AGITg': function (_0x302289) {
                    return _0x302289();
                },
                'fjJHA': _0x3e20c2(0x29c) + _0x3e20c2(0x25a),
                'axLxZ': _0x3e20c2(0x216),
                'PwueW': _0x3e20c2(0x2cb),
                'MHtTn': function (_0x181bfa, _0x1fdf79, _0x4c4e5c) {
                    return _0x181bfa(_0x1fdf79, _0x4c4e5c);
                },
                'hjNew': _0x3e20c2(0x1d1)
            };
        this[_0x3e20c2(0x1cc)] = _0x3d33f3, this[_0x3e20c2(0x1cc)]['on'](_0x41e3aa[_0x3e20c2(0x21b)], (_0x3876bb, _0x242c35) => this[_0x3e20c2(0x222) + _0x3e20c2(0x28b)](_0x3876bb, _0x242c35));
        const _0x510bcf = _0x41e3aa[_0x3e20c2(0x258)](setInterval, () => {
            const _0x56be73 = _0x3e20c2, _0x1218a7 = {
                    'zPCdY': function (_0xc2ef0a, _0xf3eb93) {
                        const _0x1a52a8 = _0x55e9;
                        return _0x41e3aa[_0x1a52a8(0x28c)](_0xc2ef0a, _0xf3eb93);
                    },
                    'CYgef': function (_0x294545) {
                        const _0x136610 = _0x55e9;
                        return _0x41e3aa[_0x136610(0x2e7)](_0x294545);
                    },
                    'pFvKj': _0x41e3aa[_0x56be73(0x1f9)],
                    'nyHvh': _0x41e3aa[_0x56be73(0x1f2)]
                };
            this[_0x56be73(0x1cc)][_0x56be73(0x1de)][_0x56be73(0x1f4)](_0x11dbad => {
                const _0x578ad6 = _0x56be73;
                if (_0x1218a7[_0x578ad6(0x1f3)](_0x11dbad[_0x578ad6(0x311)], ![]))
                    return console[_0x578ad6(0x2c6)]('[' + _0x1218a7[_0x578ad6(0x1cb)](moment)[_0x578ad6(0x1eb)](_0x1218a7[_0x578ad6(0x290)]) + (_0x578ad6(0x2bb) + _0x578ad6(0x24b) + _0x578ad6(0x21d) + _0x578ad6(0x281)) + (_0x11dbad['sn'] || _0x1218a7[_0x578ad6(0x2bd)])), _0x11dbad[_0x578ad6(0x2fa)]();
                _0x11dbad[_0x578ad6(0x311)] = ![], _0x11dbad[_0x578ad6(0x22d)]();
            });
        }, -0xe46c + 0x1 * 0x3e09 + -0x5 * -0x38b7);
        this[_0x3e20c2(0x1cc)]['on'](_0x41e3aa[_0x3e20c2(0x319)], () => clearInterval(_0x510bcf));
    }
    async [_0x549366(0x2e3) + _0x549366(0x1ca)]() {
        const _0x10e87d = _0x549366, _0x39722e = {
                'WuvjG': _0x10e87d(0x288),
                'oXxXf': _0x10e87d(0x30c) + _0x10e87d(0x1c6) + _0x10e87d(0x1e9) + _0x10e87d(0x2f0),
                'WkVAt': _0x10e87d(0x1ef) + _0x10e87d(0x257) + _0x10e87d(0x2a3) + 's:'
            };
        try {
            await Device[_0x10e87d(0x1c7)]({ 'status': _0x39722e[_0x10e87d(0x1c3)] }, { 'where': {} }), console[_0x10e87d(0x2c6)](_0x39722e[_0x10e87d(0x2db)]);
        } catch (_0x5be1e5) {
            console[_0x10e87d(0x31c)](_0x39722e[_0x10e87d(0x2e5)], _0x5be1e5[_0x10e87d(0x29f)]);
        }
    }
    async [_0x549366(0x222) + _0x549366(0x28b)](_0x1a1fb6, _0x420789) {
        const _0x4929cb = _0x549366, _0x56dd7e = {
                'wJZCN': function (_0x21f835) {
                    return _0x21f835();
                },
                'vIERJ': _0x4929cb(0x29c) + _0x4929cb(0x25a),
                'GNJXV': _0x4929cb(0x2b1) + 'i',
                'hnUxE': _0x4929cb(0x266),
                'JmKLI': _0x4929cb(0x2ce),
                'zRdMD': function (_0x1bb93c) {
                    return _0x1bb93c();
                },
                'PYIkx': _0x4929cb(0x1d4) + _0x4929cb(0x269),
                'mWxeP': _0x4929cb(0x1e8) + _0x4929cb(0x1ce),
                'chyAn': _0x4929cb(0x282),
                'sNdhG': _0x4929cb(0x2fb),
                'wdDPC': function (_0x95af7c) {
                    return _0x95af7c();
                },
                'qeGMc': _0x4929cb(0x25d),
                'JJziS': _0x4929cb(0x29f),
                'chsfR': _0x4929cb(0x1d1),
                'vsjFa': _0x4929cb(0x31c)
            }, _0x57cafb = await LicenseService[_0x4929cb(0x306) + _0x4929cb(0x231)]();
        if (!_0x57cafb[_0x4929cb(0x1c8)]) {
            console[_0x4929cb(0x2c6)]('[' + _0x56dd7e[_0x4929cb(0x2a0)](moment)[_0x4929cb(0x1eb)](_0x56dd7e[_0x4929cb(0x1cd)]) + (_0x4929cb(0x253) + _0x4929cb(0x312) + _0x4929cb(0x26f)) + _0x57cafb[_0x4929cb(0x31c)]), _0x1a1fb6[_0x4929cb(0x1d1)](0x60 * -0x65 + 0x815 * -0x1 + 0x31e5, _0x4929cb(0x320) + _0x4929cb(0x316) + _0x57cafb[_0x4929cb(0x31c)]);
            return;
        }
        const _0x5d603a = _0x420789[_0x4929cb(0x2da)][_0x4929cb(0x287) + _0x4929cb(0x2ae)];
        _0x1a1fb6[_0x4929cb(0x321)] = _0x5d603a, _0x1a1fb6[_0x4929cb(0x311)] = !![];
        if (_0x420789[_0x4929cb(0x2b8)][_0x4929cb(0x200)](_0x56dd7e[_0x4929cb(0x31e)])) {
            _0x1a1fb6[_0x4929cb(0x284)] = _0x56dd7e[_0x4929cb(0x323)];
            const _0x499854 = _0x420789[_0x4929cb(0x2b8)][_0x4929cb(0x2d4)]('?'), _0x9ba6ff = new URLSearchParams(_0x499854[-0xa75 + 0x12af * 0x1 + -0x839] || ''), _0x39da8a = _0x9ba6ff[_0x4929cb(0x1cf)]('sn'), _0x47e6b6 = _0x9ba6ff[_0x4929cb(0x1cf)](_0x56dd7e[_0x4929cb(0x2bc)]) || _0x4929cb(0x24c) + Date[_0x4929cb(0x315)]() + '-' + Math[_0x4929cb(0x2fc)]()[_0x4929cb(0x264)](0x15 * -0x40 + 0x437 * 0x1 + 0x12d)[_0x4929cb(0x25f)](-0x3 * 0x7ed + 0x17eb + 0x2 * -0x11, -0x2543 + -0x1feb + -0xd * -0x553);
            if (!_0x39da8a) {
                console[_0x4929cb(0x2c6)]('[' + _0x56dd7e[_0x4929cb(0x1e4)](moment)[_0x4929cb(0x1eb)](_0x56dd7e[_0x4929cb(0x1cd)]) + (_0x4929cb(0x324) + _0x4929cb(0x2f9) + _0x4929cb(0x2ad) + _0x4929cb(0x29e))), _0x1a1fb6[_0x4929cb(0x1d1)](-0x1823 + -0x2 * -0xaea + 0x63f * 0x1, _0x56dd7e[_0x4929cb(0x2b3)]);
                return;
            }
            _0x1a1fb6[_0x4929cb(0x284)] = _0x56dd7e[_0x4929cb(0x323)], _0x1a1fb6['sn'] = _0x39da8a, _0x1a1fb6[_0x4929cb(0x2ce)] = _0x47e6b6, this[_0x4929cb(0x302) + 'ts'][_0x4929cb(0x27b)](_0x39da8a, _0x1a1fb6), this[_0x4929cb(0x302) + _0x4929cb(0x239)][_0x4929cb(0x27b)](_0x1a1fb6, {
                'clientId': _0x47e6b6,
                'sn': _0x39da8a,
                'connectedAt': new Date()
            }), console[_0x4929cb(0x2c6)]('[' + _0x56dd7e[_0x4929cb(0x2a0)](moment)[_0x4929cb(0x1eb)](_0x56dd7e[_0x4929cb(0x1cd)]) + (_0x4929cb(0x324) + _0x4929cb(0x20d) + _0x4929cb(0x263)) + _0x47e6b6 + (_0x4929cb(0x32a) + 'e\x20') + _0x39da8a + _0x4929cb(0x226) + _0x5d603a), _0x1a1fb6[_0x4929cb(0x1db)](JSON[_0x4929cb(0x307)]({
                'cmd': _0x56dd7e[_0x4929cb(0x245)],
                'ret': _0x56dd7e[_0x4929cb(0x229)],
                'result': !![],
                'sn': _0x39da8a,
                'clientId': _0x47e6b6,
                'message': _0x4929cb(0x29b) + _0x4929cb(0x32a) + 'e\x20' + _0x39da8a,
                'timestamp': _0x56dd7e[_0x4929cb(0x1e4)](moment)[_0x4929cb(0x1eb)](_0x56dd7e[_0x4929cb(0x1cd)])
            }));
        } else
            _0x1a1fb6[_0x4929cb(0x284)] = _0x56dd7e[_0x4929cb(0x303)];
        console[_0x4929cb(0x2c6)]('[' + _0x56dd7e[_0x4929cb(0x271)](moment)[_0x4929cb(0x1eb)](_0x56dd7e[_0x4929cb(0x1cd)]) + (_0x4929cb(0x1f6) + _0x4929cb(0x1d9) + 'm\x20') + _0x5d603a), _0x1a1fb6['on'](_0x56dd7e[_0x4929cb(0x205)], () => {
            const _0x3e78da = _0x4929cb;
            _0x1a1fb6[_0x3e78da(0x311)] = !![];
        }), _0x1a1fb6['on'](_0x56dd7e[_0x4929cb(0x298)], _0x461e3b => this[_0x4929cb(0x1e3) + _0x4929cb(0x265)](_0x1a1fb6, _0x461e3b)), _0x1a1fb6['on'](_0x56dd7e[_0x4929cb(0x2d5)], () => this[_0x4929cb(0x296) + 'e'](_0x1a1fb6)), _0x1a1fb6['on'](_0x56dd7e[_0x4929cb(0x1e0)], _0x2d787d => this[_0x4929cb(0x244) + 'r'](_0x1a1fb6, _0x2d787d));
    }
    async [_0x549366(0x1e3) + _0x549366(0x265)](_0x51f232, _0x4e1d4c) {
        const _0x574870 = _0x549366, _0x227c5a = {
                'UdBmh': function (_0x5c2572) {
                    return _0x5c2572();
                },
                'oYhTs': _0x574870(0x29c) + _0x574870(0x25a),
                'DiIvG': _0x574870(0x216),
                'xxVte': function (_0x32a5bb, _0x47941b) {
                    return _0x32a5bb === _0x47941b;
                },
                'RaMuA': _0x574870(0x266),
                'iosno': _0x574870(0x1d5) + _0x574870(0x25c),
                'KHTDU': function (_0xd8e7e8) {
                    return _0xd8e7e8();
                },
                'NnNtg': _0x574870(0x2c6),
                'VOtHF': function (_0x2cdda1) {
                    return _0x2cdda1();
                },
                'khRBm': _0x574870(0x225),
                'cmvsa': _0x574870(0x1e8) + _0x574870(0x1ce),
                'mcfKu': _0x574870(0x2a6) + _0x574870(0x247) + 'e:'
            };
        try {
            const _0x52241b = await LicenseService[_0x574870(0x306) + _0x574870(0x231)]();
            if (!_0x52241b[_0x574870(0x1c8)]) {
                console[_0x574870(0x2c6)]('[' + _0x227c5a[_0x574870(0x23e)](moment)[_0x574870(0x1eb)](_0x227c5a[_0x574870(0x1df)]) + (_0x574870(0x201) + _0x574870(0x255)) + (_0x51f232['sn'] || _0x227c5a[_0x574870(0x2a2)]) + (_0x574870(0x293) + '\x20') + _0x52241b[_0x574870(0x31c)]), _0x51f232[_0x574870(0x1d1)](0x1237 + -0x1 * 0xbf6 + -0x251, _0x574870(0x320) + _0x574870(0x316) + _0x52241b[_0x574870(0x31c)]);
                return;
            }
            const _0x33fcfb = _0x4e1d4c[_0x574870(0x264)](), _0x3d5bf1 = JSON[_0x574870(0x1c4)](_0x33fcfb), {
                    cmd: _0xc3a188,
                    ret: _0x309a8b
                } = _0x3d5bf1, _0x315360 = _0x227c5a[_0x574870(0x25b)](_0x51f232[_0x574870(0x284)], _0x227c5a[_0x574870(0x29a)]) ? _0x51f232[_0x574870(0x2ce)] + '\x20(' + _0x51f232['sn'] + ')' : _0x51f232['sn'] || _0x227c5a[_0x574870(0x299)];
            console[_0x574870(0x2c6)]('[' + _0x227c5a[_0x574870(0x2fe)](moment)[_0x574870(0x1eb)](_0x227c5a[_0x574870(0x1df)]) + (_0x574870(0x251) + _0x574870(0x226)) + _0x51f232[_0x574870(0x284)] + '\x20' + _0x315360 + ':', this[_0x574870(0x2a5) + _0x574870(0x2df)](_0x3d5bf1)), this[_0x574870(0x24d)](_0x227c5a[_0x574870(0x204)], {
                'timestamp': _0x227c5a[_0x574870(0x249)](moment)[_0x574870(0x1eb)](_0x227c5a[_0x574870(0x1df)]),
                'sn': _0x51f232['sn'],
                'clientId': _0x51f232[_0x574870(0x2ce)],
                'clientType': _0x51f232[_0x574870(0x284)],
                'sn': _0x51f232['sn'],
                'type': _0x227c5a[_0x574870(0x2b7)],
                'data': _0x3d5bf1
            });
            if (_0x227c5a[_0x574870(0x25b)](_0xc3a188, _0x227c5a[_0x574870(0x1f7)])) {
            } else {
                if (_0xc3a188)
                    this[_0x574870(0x2d0) + _0x574870(0x2d1)](_0x51f232, _0xc3a188, _0x3d5bf1);
                else
                    _0x309a8b && this[_0x574870(0x2d0) + _0x574870(0x24f)](_0x51f232, _0x309a8b, _0x3d5bf1);
            }
        } catch (_0x2087e3) {
            console[_0x574870(0x31c)](_0x227c5a[_0x574870(0x2f7)], _0x2087e3[_0x574870(0x29f)]);
        }
    }
    async [_0x549366(0x2d0) + _0x549366(0x2d1)](_0x40a80e, _0x5e4ef0, _0x100a4f) {
        const _0x402d4a = _0x549366, _0x27edee = {
                'uBnKi': function (_0x227cbf, _0x5f006e) {
                    return _0x227cbf + _0x5f006e;
                },
                'QDzNW': _0x402d4a(0x234) + _0x402d4a(0x29d) + _0x402d4a(0x213) + _0x402d4a(0x20a),
                'MSWwT': _0x402d4a(0x2c8),
                'RJyig': _0x402d4a(0x2ec),
                'sLhwY': _0x402d4a(0x1ef) + _0x402d4a(0x2af) + _0x402d4a(0x30e) + _0x402d4a(0x283),
                'wVROH': function (_0x4b0862) {
                    return _0x4b0862();
                },
                'SrRpv': _0x402d4a(0x29c) + _0x402d4a(0x25a),
                'ixBEO': _0x402d4a(0x21f),
                'SuSLU': function (_0x18185f, _0x3de496) {
                    return _0x18185f > _0x3de496;
                },
                'PaMyo': function (_0x5606f0, _0x23bf44, _0x27d15b) {
                    return _0x5606f0(_0x23bf44, _0x27d15b);
                },
                'eQNIa': function (_0x2b20e9, _0xad8520) {
                    return _0x2b20e9 === _0xad8520;
                },
                'DjQmc': _0x402d4a(0x2a8),
                'XoVKe': _0x402d4a(0x1fd),
                'HKdaO': _0x402d4a(0x1ee) + _0x402d4a(0x240) + _0x402d4a(0x217),
                'XicKw': _0x402d4a(0x2d8),
                'qEdaM': function (_0x272031) {
                    return _0x272031();
                },
                'fyrkr': _0x402d4a(0x28e)
            };
        console[_0x402d4a(0x2c6)](_0x27edee[_0x402d4a(0x22c)](_0x27edee[_0x402d4a(0x1ec)], _0x5e4ef0));
        switch (_0x5e4ef0) {
        case _0x27edee[_0x402d4a(0x2ba)]:
            const _0x585f33 = _0x100a4f['sn'];
            this[_0x402d4a(0x2c3) + _0x402d4a(0x2d3)][_0x402d4a(0x27b)](_0x585f33, _0x40a80e), _0x40a80e['sn'] = _0x585f33;
            try {
                await Device[_0x402d4a(0x2f4)]({
                    'sn': _0x585f33,
                    'status': _0x27edee[_0x402d4a(0x314)],
                    'last_seen': new Date(),
                    'ip_address': _0x40a80e[_0x402d4a(0x321)]
                });
            } catch (_0x5cc3b0) {
                console[_0x402d4a(0x31c)](_0x27edee[_0x402d4a(0x250)], _0x5cc3b0[_0x402d4a(0x29f)]);
            }
            _0x40a80e[_0x402d4a(0x1db)](JSON[_0x402d4a(0x307)]({
                'ret': _0x27edee[_0x402d4a(0x2ba)],
                'result': !![],
                'cloudtime': _0x27edee[_0x402d4a(0x1e5)](moment)[_0x402d4a(0x1eb)](_0x27edee[_0x402d4a(0x20e)]),
                'nosenduser': ![]
            })), console[_0x402d4a(0x2c6)]('[' + _0x27edee[_0x402d4a(0x1e5)](moment)[_0x402d4a(0x1eb)](_0x27edee[_0x402d4a(0x20e)]) + (_0x402d4a(0x2aa) + _0x402d4a(0x2b0) + '\x20') + _0x585f33);
            break;
        case _0x27edee[_0x402d4a(0x20b)]:
            const _0x50c028 = _0x100a4f[_0x402d4a(0x270)] || 0xd87 * -0x2 + -0x1ac6 + 0x35d4, _0x216339 = _0x100a4f[_0x402d4a(0x2ef)] || -0xab6 + 0x1d52 + 0x94e * -0x2;
            _0x100a4f[_0x402d4a(0x273)] && _0x27edee[_0x402d4a(0x227)](_0x100a4f[_0x402d4a(0x273)][_0x402d4a(0x313)], 0x1e3b + -0x2079 + 0x52 * 0x7) && _0x100a4f[_0x402d4a(0x273)][-0x19e * -0x12 + -0xe * 0x2c8 + -0x22 * -0x4a][_0x402d4a(0x2dc)] && this[_0x402d4a(0x26e)][_0x402d4a(0x27b)](_0x100a4f['sn'] || _0x40a80e['sn'], _0x100a4f[_0x402d4a(0x273)][0x4e4 * -0x5 + 0x1df5 + -0x1 * 0x581][_0x402d4a(0x2dc)]);
            try {
                const _0x159725 = await _0x27edee[_0x402d4a(0x2d2)](callVerifyAPI, _0x100a4f[_0x402d4a(0x273)][0x22e3 + -0x2df + -0x2004][_0x402d4a(0x2dc)], _0x100a4f['sn']);
                logger[_0x402d4a(0x28f)](_0x402d4a(0x2ac) + _0x402d4a(0x224) + _0x402d4a(0x1f1) + _0x402d4a(0x1fe) + '\x20' + _0x100a4f['sn'] + (_0x402d4a(0x26d) + ':\x20') + JSON[_0x402d4a(0x307)](_0x159725)), _0x27edee[_0x402d4a(0x267)](_0x159725[_0x402d4a(0x1dc)], _0x27edee[_0x402d4a(0x2c9)]) ? (this[_0x402d4a(0x1f5) + _0x402d4a(0x325)](_0x40a80e['sn'], {
                    'cmd': _0x27edee[_0x402d4a(0x1d8)],
                    'result': !![],
                    'doornum': 0x1,
                    'boardingPass': _0x159725[_0x402d4a(0x209) + 'ss'],
                    'title': _0x159725[_0x402d4a(0x2f1)],
                    'message': _0x159725[_0x402d4a(0x29f)],
                    'customerName': _0x159725[_0x402d4a(0x2f2) + 'me']
                }), logger[_0x402d4a(0x28f)](_0x402d4a(0x2ac) + _0x402d4a(0x224) + _0x402d4a(0x31d) + _0x402d4a(0x1e7) + ':\x20' + _0x100a4f['sn'] + (_0x402d4a(0x26d) + _0x402d4a(0x2a9) + _0x402d4a(0x2cc) + _0x402d4a(0x2f3))), SessionPending[_0x402d4a(0x274)]({
                    'sessionId': _0x159725[_0x402d4a(0x304)],
                    'status': 0x0,
                    'sn': _0x100a4f['sn']
                }), logger[_0x402d4a(0x28f)](_0x402d4a(0x2ac) + _0x402d4a(0x224) + _0x402d4a(0x232) + _0x402d4a(0x211) + _0x402d4a(0x203) + _0x402d4a(0x1e6) + _0x402d4a(0x32b) + _0x402d4a(0x2a7) + _0x100a4f['sn'] + (_0x402d4a(0x30b) + _0x402d4a(0x2c1)) + _0x159725[_0x402d4a(0x304)])) : await this[_0x402d4a(0x1f5) + _0x402d4a(0x325)](_0x40a80e['sn'], {
                    'cmd': _0x27edee[_0x402d4a(0x1d8)],
                    'result': ![],
                    'doornum': 0x1,
                    'boardingPass': _0x159725[_0x402d4a(0x209) + 'ss'],
                    'title': _0x159725[_0x402d4a(0x2f1)],
                    'message': _0x159725[_0x402d4a(0x29f)],
                    'customerName': _0x159725[_0x402d4a(0x2f2) + 'me']
                });
            } catch (_0x350a01) {
                logger[_0x402d4a(0x31c)](_0x402d4a(0x2ac) + _0x402d4a(0x224) + _0x402d4a(0x28a) + _0x402d4a(0x2ed) + _0x100a4f['sn'] + _0x402d4a(0x1d7) + _0x350a01[_0x402d4a(0x29f)]);
                try {
                    await this[_0x402d4a(0x1f5) + _0x402d4a(0x325)](_0x100a4f['sn'], {
                        'cmd': _0x27edee[_0x402d4a(0x1d8)],
                        'result': ![],
                        'doornum': 0x1,
                        'message': _0x27edee[_0x402d4a(0x2e4)],
                        'title': _0x27edee[_0x402d4a(0x25e)],
                        'customerName': ''
                    });
                } catch (_0x21e82e) {
                    logger[_0x402d4a(0x31c)](_0x402d4a(0x2ac) + _0x402d4a(0x224) + _0x402d4a(0x23d) + _0x402d4a(0x2eb) + _0x402d4a(0x2d7) + _0x402d4a(0x310) + _0x100a4f['sn'] + _0x402d4a(0x1d7) + _0x21e82e[_0x402d4a(0x29f)]);
                }
            }
            _0x40a80e[_0x402d4a(0x1db)](JSON[_0x402d4a(0x307)]({
                'ret': _0x27edee[_0x402d4a(0x20b)],
                'result': !![],
                'count': _0x50c028,
                'logindex': _0x216339,
                'cloudtime': _0x27edee[_0x402d4a(0x22a)](moment)[_0x402d4a(0x1eb)](_0x27edee[_0x402d4a(0x20e)]),
                'access': 0x1
            }));
            break;
        case _0x27edee[_0x402d4a(0x206)]:
            _0x100a4f[_0x402d4a(0x273)] && this[_0x402d4a(0x26e)][_0x402d4a(0x27b)](_0x100a4f['sn'] || _0x40a80e['sn'], _0x100a4f[_0x402d4a(0x273)]);
            _0x40a80e[_0x402d4a(0x1db)](JSON[_0x402d4a(0x307)]({
                'ret': _0x27edee[_0x402d4a(0x206)],
                'result': !![],
                'enrollid': _0x100a4f[_0x402d4a(0x322)],
                'backupnum': _0x100a4f[_0x402d4a(0x27a)]
            }));
            break;
        }
    }
    [_0x549366(0x2d0) + _0x549366(0x24f)](_0x3dcfa2, _0x33e6b2, _0x46c92a) {
        const _0x5cb0fc = _0x549366, _0x2338a0 = {
                'Yqmdq': _0x5cb0fc(0x1ff),
                'AOfab': _0x5cb0fc(0x1d3),
                'dowlf': function (_0x220b48) {
                    return _0x220b48();
                },
                'VEDoQ': _0x5cb0fc(0x29c) + _0x5cb0fc(0x25a),
                'zJWyL': _0x5cb0fc(0x2c6),
                'mizaS': function (_0x125187) {
                    return _0x125187();
                },
                'VrmvC': _0x5cb0fc(0x254)
            }, _0x11ecdf = _0x46c92a[_0x5cb0fc(0x308)] ? _0x2338a0[_0x5cb0fc(0x2b5)] : _0x2338a0[_0x5cb0fc(0x28d)], _0x192040 = _0x46c92a[_0x5cb0fc(0x2b2)] ? _0x5cb0fc(0x260) + _0x46c92a[_0x5cb0fc(0x2b2)] + ')' : '';
        console[_0x5cb0fc(0x2c6)]('[' + _0x2338a0[_0x5cb0fc(0x1f8)](moment)[_0x5cb0fc(0x1eb)](_0x2338a0[_0x5cb0fc(0x1d2)]) + (_0x5cb0fc(0x2aa) + _0x5cb0fc(0x2e8) + '\x20') + _0x33e6b2 + ':\x20' + _0x11ecdf + _0x192040);
        if (_0x3dcfa2['sn']) {
            const _0xa6e429 = _0x3dcfa2['sn'] + ':' + _0x33e6b2, _0x259d7f = this[_0x5cb0fc(0x214) + _0x5cb0fc(0x220)][_0x5cb0fc(0x1cf)](_0xa6e429);
            _0x259d7f && (_0x259d7f[_0x5cb0fc(0x272)](_0x46c92a), this[_0x5cb0fc(0x214) + _0x5cb0fc(0x220)][_0x5cb0fc(0x2d6)](_0xa6e429));
        }
        this[_0x5cb0fc(0x24d)](_0x2338a0[_0x5cb0fc(0x2c7)], {
            'timestamp': _0x2338a0[_0x5cb0fc(0x21a)](moment)[_0x5cb0fc(0x1eb)](_0x2338a0[_0x5cb0fc(0x1d2)]),
            'sn': _0x3dcfa2['sn'],
            'type': _0x2338a0[_0x5cb0fc(0x27c)],
            'command': _0x33e6b2,
            'result': _0x11ecdf,
            'reason': _0x192040,
            'data': _0x46c92a
        });
    }
    async [_0x549366(0x296) + 'e'](_0x43e9c3) {
        const _0x2a9ae7 = _0x549366, _0x2d131 = {
                'dQjCr': _0x2a9ae7(0x2c6),
                'YpvXU': function (_0x495795) {
                    return _0x495795();
                },
                'afLFM': _0x2a9ae7(0x29c) + _0x2a9ae7(0x25a),
                'Tgslk': _0x2a9ae7(0x31a) + 'ED',
                'iLvZo': function (_0x1bfbfe, _0x39a88a) {
                    return _0x1bfbfe === _0x39a88a;
                },
                'BmkVH': function (_0x15dd44) {
                    return _0x15dd44();
                },
                'VPhOb': _0x2a9ae7(0x288),
                'Urqfw': _0x2a9ae7(0x1ef) + _0x2a9ae7(0x2be) + _0x2a9ae7(0x2de) + _0x2a9ae7(0x2ca) + _0x2a9ae7(0x212)
            };
        if (_0x43e9c3['sn']) {
            this[_0x2a9ae7(0x24d)](_0x2d131[_0x2a9ae7(0x297)], {
                'timestamp': _0x2d131[_0x2a9ae7(0x268)](moment)[_0x2a9ae7(0x1eb)](_0x2d131[_0x2a9ae7(0x27d)]),
                'sn': _0x43e9c3['sn'],
                'type': _0x2d131[_0x2a9ae7(0x1dd)],
                'message': _0x2a9ae7(0x228) + _0x43e9c3['sn'] + (_0x2a9ae7(0x221) + _0x2a9ae7(0x2c4))
            });
            if (_0x2d131[_0x2a9ae7(0x26c)](this[_0x2a9ae7(0x2c3) + _0x2a9ae7(0x2d3)][_0x2a9ae7(0x1cf)](_0x43e9c3['sn']), _0x43e9c3)) {
                this[_0x2a9ae7(0x2c3) + _0x2a9ae7(0x2d3)][_0x2a9ae7(0x2d6)](_0x43e9c3['sn']), console[_0x2a9ae7(0x2c6)]('[' + _0x2d131[_0x2a9ae7(0x2d9)](moment)[_0x2a9ae7(0x1eb)](_0x2d131[_0x2a9ae7(0x27d)]) + (_0x2a9ae7(0x23b) + _0x2a9ae7(0x2e9) + _0x2a9ae7(0x26f)) + _0x43e9c3['sn']);
                try {
                    await Device[_0x2a9ae7(0x1c7)]({
                        'status': _0x2d131[_0x2a9ae7(0x2a1)],
                        'last_seen': new Date()
                    }, { 'where': { 'sn': _0x43e9c3['sn'] } });
                } catch (_0x1b52d7) {
                    console[_0x2a9ae7(0x31c)](_0x2d131[_0x2a9ae7(0x2f6)], _0x1b52d7[_0x2a9ae7(0x29f)]);
                }
            } else
                console[_0x2a9ae7(0x2c6)]('[' + _0x2d131[_0x2a9ae7(0x268)](moment)[_0x2a9ae7(0x1eb)](_0x2d131[_0x2a9ae7(0x27d)]) + (_0x2a9ae7(0x21e) + _0x2a9ae7(0x285) + _0x2a9ae7(0x2b6) + _0x2a9ae7(0x202)) + _0x43e9c3['sn']);
        }
    }
    [_0x549366(0x244) + 'r'](_0x55fcfc, _0x5a4189) {
        const _0x1519c1 = _0x549366, _0x5fbb27 = {
                'gtFbj': _0x1519c1(0x2c6),
                'xTXBe': function (_0x8bb1a4) {
                    return _0x8bb1a4();
                },
                'zoeTV': _0x1519c1(0x29c) + _0x1519c1(0x25a),
                'JwMLs': _0x1519c1(0x2ab)
            };
        _0x55fcfc['sn'] && this[_0x1519c1(0x24d)](_0x5fbb27[_0x1519c1(0x2dd)], {
            'timestamp': _0x5fbb27[_0x1519c1(0x20c)](moment)[_0x1519c1(0x1eb)](_0x5fbb27[_0x1519c1(0x326)]),
            'sn': _0x55fcfc['sn'],
            'type': _0x5fbb27[_0x1519c1(0x219)],
            'message': _0x1519c1(0x1fa) + _0x1519c1(0x1c9) + _0x55fcfc['sn'] + ':\x20' + _0x5a4189[_0x1519c1(0x29f)]
        }), console[_0x1519c1(0x31c)]('[' + _0x5fbb27[_0x1519c1(0x20c)](moment)[_0x1519c1(0x1eb)](_0x5fbb27[_0x1519c1(0x326)]) + (_0x1519c1(0x294) + _0x1519c1(0x2e2)), _0x5a4189[_0x1519c1(0x29f)]);
    }
    async [_0x549366(0x1f5) + _0x549366(0x325)](_0xb4e0b0, _0x247317, _0x2264c5 = 0x4a9d + 0x952 * -0x2 + -0x10e9) {
        const _0x59e1f0 = _0x549366, _0x5dfc5f = {
                'loNxJ': function (_0x573b16, _0x562d6d) {
                    return _0x573b16(_0x562d6d);
                },
                'GKmhr': function (_0x3bcc23, _0x23d5d8) {
                    return _0x3bcc23(_0x23d5d8);
                },
                'FVHQH': function (_0x4fd1fd, _0x351bf6) {
                    return _0x4fd1fd(_0x351bf6);
                },
                'zkGdj': function (_0x5a73b6, _0xa2a4b7, _0x2bd185) {
                    return _0x5a73b6(_0xa2a4b7, _0x2bd185);
                },
                'CjTZS': function (_0x479fce, _0x9e92c2) {
                    return _0x479fce === _0x9e92c2;
                },
                'uVuHZ': function (_0x30b079) {
                    return _0x30b079();
                },
                'VoEMk': _0x59e1f0(0x29c) + _0x59e1f0(0x25a),
                'eZQpH': _0x59e1f0(0x2c6),
                'EYYRo': _0x59e1f0(0x22f),
                'ASyfT': function (_0x3bcdb1) {
                    return _0x3bcdb1();
                }
            }, _0xf2d67c = this[_0x59e1f0(0x2c3) + _0x59e1f0(0x2d3)][_0x59e1f0(0x1cf)](_0xb4e0b0);
        if (_0xf2d67c && _0x5dfc5f[_0x59e1f0(0x1c5)](_0xf2d67c[_0x59e1f0(0x252)], -0x86 * -0x38 + 0x1f83 * 0x1 + -0x3cd2)) {
            const _0x1d6a24 = _0x247317[_0x59e1f0(0x30d)], _0xd77610 = _0xb4e0b0 + ':' + _0x1d6a24;
            return _0xf2d67c[_0x59e1f0(0x1db)](JSON[_0x59e1f0(0x307)](_0x247317)), console[_0x59e1f0(0x2c6)]('[' + _0x5dfc5f[_0x59e1f0(0x246)](moment)[_0x59e1f0(0x1eb)](_0x5dfc5f[_0x59e1f0(0x2e1)]) + (_0x59e1f0(0x2a4) + _0x59e1f0(0x23a)) + _0xb4e0b0 + ':', JSON[_0x59e1f0(0x307)](_0x247317)), this[_0x59e1f0(0x24d)](_0x5dfc5f[_0x59e1f0(0x230)], {
                'timestamp': _0x5dfc5f[_0x59e1f0(0x246)](moment)[_0x59e1f0(0x1eb)](_0x5dfc5f[_0x59e1f0(0x2e1)]),
                'sn': _0xb4e0b0,
                'type': _0x5dfc5f[_0x59e1f0(0x22e)],
                'data': _0x247317
            }), new Promise((_0x2129e0, _0x4f38fd) => {
                const _0x12ad32 = _0x59e1f0, _0x573db8 = {
                        'Cmeej': function (_0x4c2a65, _0x3e3fb0) {
                            const _0x516de8 = _0x55e9;
                            return _0x5dfc5f[_0x516de8(0x2e0)](_0x4c2a65, _0x3e3fb0);
                        },
                        'XmFLp': function (_0x1be8f7, _0x56239a) {
                            const _0x51f62e = _0x55e9;
                            return _0x5dfc5f[_0x51f62e(0x2e0)](_0x1be8f7, _0x56239a);
                        },
                        'lfzXM': function (_0x158e69, _0x29bfcd) {
                            const _0x1b9eb5 = _0x55e9;
                            return _0x5dfc5f[_0x1b9eb5(0x1d6)](_0x158e69, _0x29bfcd);
                        }
                    }, _0x4f55fa = _0x5dfc5f[_0x12ad32(0x309)](setTimeout, () => {
                        const _0x76c53 = _0x12ad32;
                        this[_0x76c53(0x214) + _0x76c53(0x220)][_0x76c53(0x2f5)](_0xd77610) && (this[_0x76c53(0x214) + _0x76c53(0x220)][_0x76c53(0x2d6)](_0xd77610), _0x573db8[_0x76c53(0x286)](_0x2129e0, {
                            'result': ![],
                            'timeout': !![],
                            'message': _0x76c53(0x279) + _0x76c53(0x26b) + _0x76c53(0x243) + _0x76c53(0x278) + '\x20' + _0xb4e0b0 + (_0x76c53(0x237) + _0x76c53(0x2ea)) + _0x1d6a24
                        }));
                    }, _0x2264c5);
                this[_0x12ad32(0x214) + _0x12ad32(0x220)][_0x12ad32(0x27b)](_0xd77610, {
                    'resolve': _0x55666f => {
                        const _0x176d44 = _0x12ad32;
                        _0x573db8[_0x176d44(0x318)](clearTimeout, _0x4f55fa), _0x573db8[_0x176d44(0x27e)](_0x2129e0, _0x55666f);
                    },
                    'reject': _0x5bafc4 => {
                        const _0x576174 = _0x12ad32;
                        _0x5dfc5f[_0x576174(0x2e0)](clearTimeout, _0x4f55fa), _0x5dfc5f[_0x576174(0x1fb)](_0x4f38fd, _0x5bafc4);
                    }
                });
            });
        }
        console[_0x59e1f0(0x215)]('[' + _0x5dfc5f[_0x59e1f0(0x275)](moment)[_0x59e1f0(0x1eb)](_0x5dfc5f[_0x59e1f0(0x2e1)]) + _0x59e1f0(0x238) + _0xb4e0b0 + (_0x59e1f0(0x20f) + _0x59e1f0(0x2e6) + _0x59e1f0(0x2f8)));
        throw new Error(_0x59e1f0(0x228) + _0xb4e0b0 + (_0x59e1f0(0x20f) + _0x59e1f0(0x2e6) + _0x59e1f0(0x329)));
    }
    [_0x549366(0x2c5) + _0x549366(0x207)](_0x4af2f2, _0x14231d) {
        const _0x2f0652 = _0x549366, _0x50da38 = {
                'pOMlj': function (_0x181a97, _0x239a53) {
                    return _0x181a97 === _0x239a53;
                },
                'lSYgT': _0x2f0652(0x1e2),
                'qHCZg': function (_0x19782e) {
                    return _0x19782e();
                },
                'FMGPZ': _0x2f0652(0x29c) + _0x2f0652(0x25a),
                'MEAgZ': function (_0x430e6d) {
                    return _0x430e6d();
                },
                'bWBUj': function (_0x5727d1) {
                    return _0x5727d1();
                }
            }, _0x1d26a8 = this[_0x2f0652(0x302) + 'ts'][_0x2f0652(0x1cf)](_0x4af2f2);
        if (_0x1d26a8 && _0x50da38[_0x2f0652(0x208)](_0x1d26a8[_0x2f0652(0x252)], -0x1 * -0x23dd + -0xc4d + 0xa3 * -0x25))
            try {
                const _0xfff756 = {
                    'cmd': _0x50da38[_0x2f0652(0x2cf)],
                    'event': _0x14231d[_0x2f0652(0x1fc)],
                    'sn': _0x4af2f2,
                    'data': _0x14231d[_0x2f0652(0x1f0)],
                    'timestamp': _0x50da38[_0x2f0652(0x23c)](moment)[_0x2f0652(0x1eb)](_0x50da38[_0x2f0652(0x300)])
                };
                return _0x1d26a8[_0x2f0652(0x1db)](JSON[_0x2f0652(0x307)](_0xfff756)), console[_0x2f0652(0x2c6)]('[' + _0x50da38[_0x2f0652(0x259)](moment)[_0x2f0652(0x1eb)](_0x50da38[_0x2f0652(0x300)]) + (_0x2f0652(0x2bf) + _0x2f0652(0x27f) + _0x2f0652(0x261) + '\x20') + _0x4af2f2 + ':\x20' + _0x14231d[_0x2f0652(0x1fc)]), !![];
            } catch (_0x4b29d2) {
                return console[_0x2f0652(0x31c)]('[' + _0x50da38[_0x2f0652(0x259)](moment)[_0x2f0652(0x1eb)](_0x50da38[_0x2f0652(0x300)]) + (_0x2f0652(0x291) + _0x2f0652(0x1ea) + _0x2f0652(0x1d0) + _0x2f0652(0x256)) + _0x4af2f2 + ':', _0x4b29d2[_0x2f0652(0x29f)]), ![];
            }
        else
            return console[_0x2f0652(0x2c6)]('[' + _0x50da38[_0x2f0652(0x276)](moment)[_0x2f0652(0x1eb)](_0x50da38[_0x2f0652(0x300)]) + (_0x2f0652(0x2c0) + _0x2f0652(0x280) + _0x2f0652(0x262) + _0x2f0652(0x292)) + _0x4af2f2), ![];
    }
    [_0x549366(0x2c2) + 'ge'](_0x3ba7e0) {
        const _0x1b1a8b = _0x549366;
        return this[_0x1b1a8b(0x26e)][_0x1b1a8b(0x1cf)](_0x3ba7e0);
    }
    [_0x549366(0x2a5) + _0x549366(0x2df)](_0x2a79a8) {
        const _0xc02d64 = _0x549366, _0x17a556 = {
                'JZglk': function (_0x3084b9, _0x2f5fc7) {
                    return _0x3084b9 === _0x2f5fc7;
                },
                'wkcNX': _0xc02d64(0x289),
                'WVwFE': function (_0x5eb084, _0x1dc9f0) {
                    return _0x5eb084 > _0x1dc9f0;
                },
                'tPqSd': function (_0x9503fa, _0x237639) {
                    return _0x9503fa + _0x237639;
                },
                'yalIZ': _0xc02d64(0x30a)
            };
        return JSON[_0xc02d64(0x307)](_0x2a79a8, (_0x2e404f, _0x564eeb) => {
            const _0x364891 = _0xc02d64;
            if (_0x17a556[_0x364891(0x1da)](typeof _0x564eeb, _0x17a556[_0x364891(0x235)]) && _0x17a556[_0x364891(0x31f)](_0x564eeb[_0x364891(0x313)], 0x4e1 * -0x2 + 0x148b + -0xa65))
                return _0x17a556[_0x364891(0x21c)](_0x564eeb[_0x364891(0x305)](-0x537 + -0x39c + 0x8d3, 0x8d1 + -0x449 * 0x5 + 0xd00), _0x17a556[_0x364891(0x22b)]);
            return _0x564eeb;
        });
    }
}
function _0x4a27() {
    const _0x125a1 = [
        'VPhOb',
        'DiIvG',
        'ce\x20statuse',
        ']\x20Command\x20',
        'stringifyT',
        'Error\x20pars',
        'ce:\x20',
        'OPEN',
        ':\x20Notify\x20s',
        ']\x20Device\x20r',
        'ERROR',
        '[handleDev',
        'có\x20sn,\x20đón',
        'ess',
        'sync\x20devic',
        'egistered:',
        '/SpeedWsCl',
        'reason',
        'PYIkx',
        '0|2|3|5|6|',
        'Yqmdq',
        'n\x20closed\x20f',
        'khRBm',
        'url',
        '4vcprQA',
        'MSWwT',
        ']\x20Terminat',
        'JmKLI',
        'nyHvh',
        'update\x20dev',
        ']\x20Forwarde',
        ']\x20No\x20Speed',
        'ID:\x20',
        'getFaceIma',
        'registered',
        'ted.',
        'forwardToS',
        'log',
        'zJWyL',
        'reg',
        'DjQmc',
        'e\x20status\x20i',
        'connection',
        'ent\x20with\x20O',
        '812095MlDplX',
        'clientId',
        'lSYgT',
        'handleDevi',
        'ceRequest',
        'PaMyo',
        'Devices',
        'split',
        'chsfR',
        'delete',
        'fydoor]\x20De',
        'Error',
        'BmkVH',
        'socket',
        'oXxXf',
        'image',
        'gtFbj',
        'ice\x20offlin',
        'runcated',
        'loNxJ',
        'VoEMk',
        't\x20error:',
        'resetAllSt',
        'HKdaO',
        'WkVAt',
        '\x20or\x20not\x20co',
        'AGITg',
        'esponse\x20to',
        'isconnecte',
        'nd\x20',
        'nding\x20noti',
        'online',
        'evice:\x20',
        'exports',
        'logindex',
        'ffline.',
        'title',
        'customerNa',
        'PEN\x20status',
        'upsert',
        'has',
        'Urqfw',
        'mcfKu',
        'nnected.',
        'ent\x20không\x20',
        'terminate',
        'device',
        'random',
        'RwUAr',
        'KHTDU',
        './sun.api.',
        'FMGPZ',
        '1|4',
        'speedClien',
        'sNdhG',
        'sessionId',
        'substring',
        'checkActiv',
        'stringify',
        'result',
        'zkGdj',
        '...',
        ',\x20Session\x20',
        'All\x20device',
        'cmd',
        'e\x20status\x20t',
        'ding.js',
        'vice:\x20',
        'isAlive',
        'on\x20rejecte',
        'length',
        'RJyig',
        'now',
        'ror:\x20',
        '10415mevLMf',
        'XmFLp',
        'hjNew',
        'DISCONNECT',
        './LogHelpe',
        'error',
        '][notifydo',
        'GNJXV',
        'WVwFE',
        'License\x20Er',
        'remoteIp',
        'enrollid',
        'hnUxE',
        ']\x20SpeedCli',
        'dToDevice',
        'zoeTV',
        'init',
        'service.js',
        'nnected',
        '\x20for\x20devic',
        'n\x20for\x20Devi',
        'WuvjG',
        'parse',
        'CjTZS',
        '\x20statuses\x20',
        'update',
        'isValid',
        'error\x20for\x20',
        'atuses',
        'CYgef',
        'wss',
        'vIERJ',
        'ent',
        'get',
        'o\x20SpeedCli',
        'close',
        'VEDoQ',
        'FAILED',
        'Missing\x20sn',
        'unknown\x20de',
        'FVHQH',
        ',\x20Error:\x20',
        'XoVKe',
        'ection\x20fro',
        'JZglk',
        'send',
        'status',
        'Tgslk',
        'clients',
        'oYhTs',
        'vsjFa',
        'sessionpen',
        'forward',
        'handleMess',
        'zRdMD',
        'wVROH',
        'ing\x20sessio',
        'or]\x20Device',
        'SpeedWsCli',
        'reset\x20to\x20o',
        'rwarding\x20t',
        'format',
        'QDzNW',
        'rs.js',
        'Error\x20proc',
        'Failed\x20to\x20',
        'data',
        '][verifyAP',
        'axLxZ',
        'zPCdY',
        'forEach',
        'sendComman',
        ']\x20New\x20conn',
        'cmvsa',
        'dowlf',
        'fjJHA',
        'WebSocket\x20',
        'GKmhr',
        'event',
        'notifydoor',
        'I]\x20Device:',
        'SUCCESS',
        'includes',
        ']\x20Message\x20',
        'or\x20',
        'eated\x20pend',
        'NnNtg',
        'qeGMc',
        'fyrkr',
        'peedClient',
        'pOMlj',
        'boardingPa',
        'md:\x20',
        'ixBEO',
        'xTXBe',
        'ent\x20connec',
        'SrRpv',
        '\x20not\x20found',
        'service',
        'ending]\x20Cr',
        'n\x20DB:',
        'est\x20with\x20c',
        'pendingReq',
        'warn',
        'unknown',
        'uest',
        '972540JziPNu',
        'JwMLs',
        'mizaS',
        'PwueW',
        'tPqSd',
        'onnection\x20',
        ']\x20Obsolete',
        'sendlog',
        'uests',
        '\x20disconnec',
        'handleConn',
        '513753jJzCNs',
        'iceRequest',
        'RECEIVED',
        '\x20from\x20',
        'SuSLU',
        'Device\x20',
        'chyAn',
        'qEdaM',
        'yalIZ',
        'uBnKi',
        'ping',
        'EYYRo',
        'SENT',
        'eZQpH',
        'eLicense',
        '][SessionP',
        './license.',
        'run\x20handle',
        'wkcNX',
        'events',
        '\x20for\x20comma',
        ']\x20Device\x20',
        'tInfo',
        'sent\x20to\x20',
        ']\x20Device\x20d',
        'qHCZg',
        '][Error\x20se',
        'UdBmh',
        '34KoKUgb',
        'essing\x20req',
        '28DTUOHY',
        '../models/',
        'response\x20f',
        'handleErro',
        'mWxeP',
        'uVuHZ',
        'ing\x20messag',
        '8NiWBXQ',
        'VOtHF',
        '960633bTqaIV',
        'ing\x20dead\x20c',
        'speed-',
        'emit',
        'moment',
        'ceResponse',
        'sLhwY',
        ']\x20Received',
        'readyState',
        ']\x20Connecti',
        'RESPONSE',
        'from\x20',
        'ent\x20',
        'reset\x20devi',
        'MHtTn',
        'MEAgZ',
        '\x20HH:mm:ss',
        'xxVte',
        'vice',
        'pong',
        'XicKw',
        'substr',
        '\x20(Reason:\x20',
        'Client\x20for',
        'tening\x20for',
        'ted:\x20',
        'toString',
        'age',
        'speed',
        'eQNIa',
        'YpvXU',
        '\x20parameter',
        '2120657nMzXDh',
        'iting\x20for\x20',
        'iLvZo',
        ',\x20Response',
        'faceCache',
        'd:\x20',
        'count',
        'wdDPC',
        'resolve',
        'record',
        'create',
        'ASyfT',
        'bWBUj',
        './logs',
        'rom\x20device',
        'Timeout\x20wa',
        'backupnum',
        'set',
        'VrmvC',
        'afLFM',
        'lfzXM',
        'd\x20to\x20Speed',
        'Client\x20lis',
        'for\x20',
        'connect',
        'o\x20DB:',
        'clientType',
        '\x20connectio',
        'Cmeej',
        'remoteAddr',
        'offline',
        'string',
        '][Error]\x20D',
        'ection',
        'cpwTp',
        'AOfab',
        'senduser',
        'info',
        'pFvKj',
        ']\x20Error\x20fo',
        '\x20device\x20',
        '\x20rejected:',
        ']\x20WebSocke',
        '300006SdWELo',
        'handleClos',
        'dQjCr',
        'JJziS',
        'iosno',
        'RaMuA',
        'Registered',
        'YYYY-MM-DD',
        'DeviceRequ',
        'g\x20kết\x20nối',
        'message',
        'wJZCN'
    ];
    _0x4a27 = function () {
        return _0x125a1;
    };
    return _0x4a27();
}
module[_0x549366(0x2ee)] = new WebSocketService();