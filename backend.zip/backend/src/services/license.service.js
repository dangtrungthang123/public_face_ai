const _0x57bd63 = _0x3f41;
(function (_0x36938a, _0x5e92c5) {
    const _0x57921f = _0x3f41, _0x1425cc = _0x36938a();
    while (!![]) {
        try {
            const _0x109f01 = parseInt(_0x57921f(0xf7)) / (-0x215 + -0x2 * 0xb7b + 0xe5 * 0x1c) * (-parseInt(_0x57921f(0xe8)) / (-0xc2 * 0x22 + 0x2 * 0x10a5 + -0x784)) + parseInt(_0x57921f(0xe4)) / (-0x38f * 0xa + -0x278 + -0x2611 * -0x1) * (parseInt(_0x57921f(0xdb)) / (-0x1796 + 0x8 * 0x43f + -0xa5e)) + parseInt(_0x57921f(0xf8)) / (0xc1 * -0x16 + 0x2334 + -0x1299) + parseInt(_0x57921f(0xe3)) / (-0x7 * -0x569 + 0xd0 * 0xd + -0x3069) * (parseInt(_0x57921f(0xea)) / (0x14ec + -0xa45 + -0xaa0)) + -parseInt(_0x57921f(0x106)) / (-0x4 * -0x86f + -0x8d0 + -0x18e4) + parseInt(_0x57921f(0x107)) / (0x4 * 0x4d5 + 0xe * -0x1a7 + 0x3d7) * (-parseInt(_0x57921f(0xd5)) / (-0x12c3 + -0x79e + 0x1a6b * 0x1)) + -parseInt(_0x57921f(0xc4)) / (0xb * -0x202 + 0x8d3 + 0x2 * 0x6a7);
            if (_0x109f01 === _0x5e92c5)
                break;
            else
                _0x1425cc['push'](_0x1425cc['shift']());
        } catch (_0xa4c2a7) {
            _0x1425cc['push'](_0x1425cc['shift']());
        }
    }
}(_0x892b, 0x1 * -0x77273 + 0xe3eca + 0x1ab5b));
const crypto = require(_0x57bd63(0xcd)), License = require(_0x57bd63(0xd3) + _0x57bd63(0xc7)), KeyManager = require(_0x57bd63(0x108) + _0x57bd63(0xd7) + 'r');
function _0x3f41(_0x108f0c, _0x2b2d3f) {
    _0x108f0c = _0x108f0c - (0x108b + 0x1e74 + 0x1 * -0x2e3c);
    const _0x49f694 = _0x892b();
    let _0x698559 = _0x49f694[_0x108f0c];
    return _0x698559;
}
function _0x892b() {
    const _0x572370 = [
        'rification',
        'parse',
        '298kYIlaw',
        'sha256',
        '4487qdEhlZ',
        'ature',
        'nHCoJ',
        'signLicens',
        'toString',
        'error',
        'message',
        'saveLicens',
        'license\x20fo',
        'qNtoM',
        'verifyLice',
        'tUOjJ',
        'inactive',
        '4364EcgLVF',
        '4370935ErFKBF',
        'pired',
        'end',
        'License\x20ex',
        'from',
        'Invalid\x20li',
        'QgodX',
        'License\x20Ve',
        'findOne',
        'getPrivate',
        'No\x20active\x20',
        'exports',
        'createVeri',
        'utf8',
        '1125040oSSVDu',
        '63punWYo',
        '../config/',
        'EIYbk',
        'active',
        '9179841tjGame',
        'createSign',
        'create',
        'license',
        'Mkcuz',
        'und',
        'expiresAt',
        '\x20Error:',
        'BGKEP',
        'crypto',
        'ZEAgL',
        'eLicense',
        'getPublicK',
        'eyjkk',
        'nnIGf',
        '../models/',
        'Key',
        '351410dcuIRh',
        'sign',
        'key-manage',
        'stringify',
        'UbAZS',
        'checkActiv',
        '172cydhzj',
        'base64',
        'update',
        'cense\x20sign',
        'verify',
        'licenseKey',
        'mpaJY',
        'nseData',
        '8838vJxyzp',
        '42414AommtP',
        'BMTmZ'
    ];
    _0x892b = function () {
        return _0x572370;
    };
    return _0x892b();
}
class LicenseService {
    static [_0x57bd63(0xd0) + 'ey']() {
        const _0x575a5e = _0x57bd63;
        return KeyManager[_0x575a5e(0xd0) + 'ey']();
    }
    static [_0x57bd63(0x101) + _0x57bd63(0xd4)]() {
        const _0x27a315 = _0x57bd63;
        return KeyManager[_0x27a315(0x101) + _0x27a315(0xd4)]();
    }
    static [_0x57bd63(0xf4) + _0x57bd63(0xe2)](_0x2eb9e7) {
        const _0x12c6ff = _0x57bd63, _0x5b608c = {
                'UbAZS': _0x12c6ff(0xdc),
                'nnIGf': _0x12c6ff(0x105),
                'eyjkk': _0x12c6ff(0xe9),
                'ZEAgL': _0x12c6ff(0xfd) + _0x12c6ff(0xde) + _0x12c6ff(0xeb),
                'BGKEP': function (_0x47189f, _0x12b502) {
                    return _0x47189f < _0x12b502;
                },
                'QgodX': _0x12c6ff(0xfb) + _0x12c6ff(0xf9),
                'BMTmZ': _0x12c6ff(0xff) + _0x12c6ff(0xe6) + _0x12c6ff(0xcb)
            };
        try {
            const _0x1715e6 = this[_0x12c6ff(0xd0) + 'ey'](), _0xee3034 = JSON[_0x12c6ff(0xe7)](Buffer[_0x12c6ff(0xfc)](_0x2eb9e7, _0x5b608c[_0x12c6ff(0xd9)])[_0x12c6ff(0xee)](_0x5b608c[_0x12c6ff(0xd2)])), {
                    data: _0x32c1fe,
                    signature: _0x55a906
                } = _0xee3034, _0x25fdc2 = crypto[_0x12c6ff(0x104) + 'fy'](_0x5b608c[_0x12c6ff(0xd1)]);
            _0x25fdc2[_0x12c6ff(0xdd)](JSON[_0x12c6ff(0xd8)](_0x32c1fe)), _0x25fdc2[_0x12c6ff(0xfa)]();
            const _0x560932 = _0x25fdc2[_0x12c6ff(0xdf)](_0x1715e6, _0x55a906, _0x5b608c[_0x12c6ff(0xd9)]);
            if (!_0x560932)
                throw new Error(_0x5b608c[_0x12c6ff(0xce)]);
            const _0x3314a7 = new Date(_0x32c1fe[_0x12c6ff(0xca)]);
            if (_0x5b608c[_0x12c6ff(0xcc)](_0x3314a7, new Date()))
                throw new Error(_0x5b608c[_0x12c6ff(0xfe)]);
            return {
                'isValid': !![],
                'expiresAt': _0x3314a7,
                'data': _0x32c1fe
            };
        } catch (_0x13a96b) {
            return console[_0x12c6ff(0xef)](_0x5b608c[_0x12c6ff(0xe5)], _0x13a96b[_0x12c6ff(0xf0)]), {
                'isValid': ![],
                'error': _0x13a96b[_0x12c6ff(0xf0)]
            };
        }
    }
    static [_0x57bd63(0xed) + 'e'](_0x2b415a) {
        const _0x1b769a = _0x57bd63, _0x1fec4b = {
                'EIYbk': _0x1b769a(0xe9),
                'mpaJY': _0x1b769a(0xdc)
            }, _0x2f52ca = this[_0x1b769a(0x101) + _0x1b769a(0xd4)](), _0x3df912 = crypto[_0x1b769a(0xc5)](_0x1fec4b[_0x1b769a(0x109)]);
        _0x3df912[_0x1b769a(0xdd)](JSON[_0x1b769a(0xd8)](_0x2b415a)), _0x3df912[_0x1b769a(0xfa)]();
        const _0x371466 = _0x3df912[_0x1b769a(0xd6)](_0x2f52ca, _0x1fec4b[_0x1b769a(0xe1)]);
        return Buffer[_0x1b769a(0xfc)](JSON[_0x1b769a(0xd8)]({
            'data': _0x2b415a,
            'signature': _0x371466
        }))[_0x1b769a(0xee)](_0x1fec4b[_0x1b769a(0xe1)]);
    }
    static async [_0x57bd63(0xf1) + 'e'](_0x29f2e4, _0x432b40) {
        const _0xbc43e1 = _0x57bd63, _0x85e28c = {
                'tUOjJ': _0xbc43e1(0xf6),
                'Mkcuz': _0xbc43e1(0xc3)
            };
        return await License[_0xbc43e1(0xdd)]({ 'status': _0x85e28c[_0xbc43e1(0xf5)] }, { 'where': { 'status': _0x85e28c[_0xbc43e1(0xc8)] } }), await License[_0xbc43e1(0xc6)]({
            'licenseKey': _0x29f2e4,
            'expiresAt': _0x432b40,
            'status': _0x85e28c[_0xbc43e1(0xc8)]
        });
    }
    static async [_0x57bd63(0xda) + _0x57bd63(0xcf)]() {
        const _0xe484d2 = _0x57bd63, _0x24cc98 = {
                'nHCoJ': _0xe484d2(0xc3),
                'qNtoM': _0xe484d2(0x102) + _0xe484d2(0xf2) + _0xe484d2(0xc9)
            }, _0x11fbf4 = await License[_0xe484d2(0x100)]({ 'where': { 'status': _0x24cc98[_0xe484d2(0xec)] } });
        if (!_0x11fbf4)
            return {
                'isValid': ![],
                'error': _0x24cc98[_0xe484d2(0xf3)]
            };
        return this[_0xe484d2(0xf4) + _0xe484d2(0xe2)](_0x11fbf4[_0xe484d2(0xe0)]);
    }
}
module[_0x57bd63(0x103)] = LicenseService;