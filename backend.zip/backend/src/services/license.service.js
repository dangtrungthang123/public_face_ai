const _0x4e317d = _0x1686;
(function (_0x4defb2, _0x572422) {
    const _0x4abd96 = _0x1686, _0xd8fce2 = _0x4defb2();
    while (!![]) {
        try {
            const _0x2b1bd3 = parseInt(_0x4abd96(0x93)) / (-0x2 * -0x962 + 0x1 * -0x2239 + 0xf76) + parseInt(_0x4abd96(0x85)) / (-0x14 * -0x1d5 + -0x5 * -0x683 + 0x1 * -0x4531) * (parseInt(_0x4abd96(0x90)) / (-0x13 * -0x31 + -0x4f7 + -0x157 * -0x1)) + -parseInt(_0x4abd96(0xa4)) / (-0x8b9 + 0xcc8 * -0x1 + 0x1585) + parseInt(_0x4abd96(0x86)) / (-0x1d41 * -0x1 + 0xe4b * 0x1 + -0x2b87) + -parseInt(_0x4abd96(0xa5)) / (-0xb2e + -0x1a69 + 0x259d) * (-parseInt(_0x4abd96(0x7a)) / (-0x2486 + -0xb71 * 0x3 + 0x17a0 * 0x3)) + -parseInt(_0x4abd96(0x9d)) / (0x12cd + -0x13a9 + -0x26 * -0x6) + parseInt(_0x4abd96(0x81)) / (-0x2500 + -0x22f3 + 0x47fc) * (-parseInt(_0x4abd96(0x6c)) / (-0x2530 + -0x3eb + 0x2925));
            if (_0x2b1bd3 === _0x572422)
                break;
            else
                _0xd8fce2['push'](_0xd8fce2['shift']());
        } catch (_0x41bfba) {
            _0xd8fce2['push'](_0xd8fce2['shift']());
        }
    }
}(_0x3220, 0x16f * 0x12c1 + -0x1b5e03 + -0xa20 * -0x175));
function _0x3220() {
    const _0x52238b = [
        'end',
        'signLicens',
        'ature',
        '10347827BnImYT',
        'utf8',
        'license\x20fo',
        'getPublicK',
        'FEkLa',
        'sign',
        'message',
        '27bTWAoN',
        'exports',
        'sCsvS',
        'koOjq',
        '22oDufUJ',
        '6667445vOngKi',
        'toString',
        'license',
        'hEbND',
        'TKShp',
        '../config/',
        'sha256',
        'expiresAt',
        'saveLicens',
        'from',
        '216789ztBfmH',
        'stringify',
        'Key',
        '779654igurJh',
        'ObWAf',
        'createSign',
        'gANNI',
        'DmoWa',
        'error',
        'lBYYr',
        'inactive',
        'Invalid\x20li',
        'checkActiv',
        '14571936ymXucf',
        'update',
        'active',
        'nseData',
        'eLicense',
        'VuSJh',
        'DTvJs',
        '5188536lTSRUr',
        '6oFcxWe',
        'base64',
        'verify',
        'getPrivate',
        'ZPvRz',
        '\x20Error:',
        'License\x20Ve',
        '../models/',
        'findOne',
        'pired',
        'rification',
        'verifyLice',
        'create',
        '1108090YeflWf',
        'ePUIu',
        'License\x20ex',
        'crypto',
        'key-manage',
        'parse',
        'cense\x20sign',
        'createVeri',
        'und',
        'licenseKey',
        'No\x20active\x20'
    ];
    _0x3220 = function () {
        return _0x52238b;
    };
    return _0x3220();
}
const crypto = require(_0x4e317d(0x6f)), License = require(_0x4e317d(0xac) + _0x4e317d(0x88)), KeyManager = require(_0x4e317d(0x8b) + _0x4e317d(0x70) + 'r');
class LicenseService {
    static [_0x4e317d(0x7d) + 'ey']() {
        const _0x58c786 = _0x4e317d;
        return KeyManager[_0x58c786(0x7d) + 'ey']();
    }
    static [_0x4e317d(0xa8) + _0x4e317d(0x92)]() {
        const _0x5be28e = _0x4e317d;
        return KeyManager[_0x5be28e(0xa8) + _0x5be28e(0x92)]();
    }
    static [_0x4e317d(0x6a) + _0x4e317d(0xa0)](_0x45b963) {
        const _0xe30062 = _0x4e317d, _0x1c49bf = {
                'DmoWa': _0xe30062(0xa6),
                'ObWAf': _0xe30062(0x7b),
                'lBYYr': _0xe30062(0x8c),
                'gANNI': _0xe30062(0x9b) + _0xe30062(0x72) + _0xe30062(0x79),
                'hEbND': function (_0x439d15, _0x29936d) {
                    return _0x439d15 < _0x29936d;
                },
                'ePUIu': _0xe30062(0x6e) + _0xe30062(0xae),
                'FEkLa': _0xe30062(0xab) + _0xe30062(0xaf) + _0xe30062(0xaa)
            };
        try {
            const _0x327274 = this[_0xe30062(0x7d) + 'ey'](), _0x10bcd4 = JSON[_0xe30062(0x71)](Buffer[_0xe30062(0x8f)](_0x45b963, _0x1c49bf[_0xe30062(0x97)])[_0xe30062(0x87)](_0x1c49bf[_0xe30062(0x94)])), {
                    data: _0x10c1f0,
                    signature: _0x47229b
                } = _0x10bcd4, _0x54a197 = crypto[_0xe30062(0x73) + 'fy'](_0x1c49bf[_0xe30062(0x99)]);
            _0x54a197[_0xe30062(0x9e)](JSON[_0xe30062(0x91)](_0x10c1f0)), _0x54a197[_0xe30062(0x77)]();
            const _0x5c74e4 = _0x54a197[_0xe30062(0xa7)](_0x327274, _0x47229b, _0x1c49bf[_0xe30062(0x97)]);
            if (!_0x5c74e4)
                throw new Error(_0x1c49bf[_0xe30062(0x96)]);
            const _0x4a8576 = new Date(_0x10c1f0[_0xe30062(0x8d)]);
            if (_0x1c49bf[_0xe30062(0x89)](_0x4a8576, new Date()))
                throw new Error(_0x1c49bf[_0xe30062(0x6d)]);
            return {
                'isValid': !![],
                'expiresAt': _0x4a8576,
                'data': _0x10c1f0
            };
        } catch (_0x234a1a) {
            return console[_0xe30062(0x98)](_0x1c49bf[_0xe30062(0x7e)], _0x234a1a[_0xe30062(0x80)]), {
                'isValid': ![],
                'error': _0x234a1a[_0xe30062(0x80)]
            };
        }
    }
    static [_0x4e317d(0x78) + 'e'](_0x5cd149) {
        const _0x1ceb6d = _0x4e317d, _0x3477f7 = {
                'VuSJh': _0x1ceb6d(0x8c),
                'ZPvRz': _0x1ceb6d(0xa6)
            }, _0x18b912 = this[_0x1ceb6d(0xa8) + _0x1ceb6d(0x92)](), _0x47274f = crypto[_0x1ceb6d(0x95)](_0x3477f7[_0x1ceb6d(0xa2)]);
        _0x47274f[_0x1ceb6d(0x9e)](JSON[_0x1ceb6d(0x91)](_0x5cd149)), _0x47274f[_0x1ceb6d(0x77)]();
        const _0x48c872 = _0x47274f[_0x1ceb6d(0x7f)](_0x18b912, _0x3477f7[_0x1ceb6d(0xa9)]);
        return Buffer[_0x1ceb6d(0x8f)](JSON[_0x1ceb6d(0x91)]({
            'data': _0x5cd149,
            'signature': _0x48c872
        }))[_0x1ceb6d(0x87)](_0x3477f7[_0x1ceb6d(0xa9)]);
    }
    static async [_0x4e317d(0x8e) + 'e'](_0x438e25, _0x38f834) {
        const _0x1a92cd = _0x4e317d, _0x436171 = {
                'DTvJs': _0x1a92cd(0x9a),
                'koOjq': _0x1a92cd(0x9f)
            };
        return await License[_0x1a92cd(0x9e)]({ 'status': _0x436171[_0x1a92cd(0xa3)] }, { 'where': { 'status': _0x436171[_0x1a92cd(0x84)] } }), await License[_0x1a92cd(0x6b)]({
            'licenseKey': _0x438e25,
            'expiresAt': _0x38f834,
            'status': _0x436171[_0x1a92cd(0x84)]
        });
    }
    static async [_0x4e317d(0x9c) + _0x4e317d(0xa1)]() {
        const _0x594256 = _0x4e317d, _0x213d96 = {
                'sCsvS': _0x594256(0x9f),
                'TKShp': _0x594256(0x76) + _0x594256(0x7c) + _0x594256(0x74)
            }, _0x41fe3c = await License[_0x594256(0xad)]({ 'where': { 'status': _0x213d96[_0x594256(0x83)] } });
        if (!_0x41fe3c)
            return {
                'isValid': ![],
                'error': _0x213d96[_0x594256(0x8a)]
            };
        return this[_0x594256(0x6a) + _0x594256(0xa0)](_0x41fe3c[_0x594256(0x75)]);
    }
}
function _0x1686(_0x2b51bc, _0x34a5e4) {
    _0x2b51bc = _0x2b51bc - (-0x38b * -0x7 + 0x2627 * -0x1 + 0xdc4);
    const _0x32e981 = _0x3220();
    let _0x1764a9 = _0x32e981[_0x2b51bc];
    return _0x1764a9;
}
module[_0x4e317d(0x82)] = LicenseService;