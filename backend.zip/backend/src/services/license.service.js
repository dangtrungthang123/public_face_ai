function _0x11b5(_0x1649e2, _0x278a1d) {
    _0x1649e2 = _0x1649e2 - (-0x59 * -0x13 + 0x596 + -0xbb8);
    const _0x378296 = _0x3e8a();
    let _0x4dd29 = _0x378296[_0x1649e2];
    return _0x4dd29;
}
const _0x115df7 = _0x11b5;
(function (_0x4bc221, _0x4b4957) {
    const _0x49215b = _0x11b5, _0x28a936 = _0x4bc221();
    while (!![]) {
        try {
            const _0x1b6063 = -parseInt(_0x49215b(0xb2)) / (0x229 * 0x5 + -0x1 * 0x14a7 + -0x9db * -0x1) * (parseInt(_0x49215b(0x95)) / (-0x1842 + 0x1 * 0x2135 + -0x3 * 0x2fb)) + parseInt(_0x49215b(0x9f)) / (-0x1 * 0x490 + -0x729 + 0xbbc) + -parseInt(_0x49215b(0x93)) / (-0x593 + -0x1d42 + 0x22d9) + -parseInt(_0x49215b(0x7c)) / (-0x591 + -0x1223 + 0x17b9) + -parseInt(_0x49215b(0x81)) / (0x1be0 + 0x1 * 0x859 + 0x3 * -0xc11) + -parseInt(_0x49215b(0xb7)) / (0x53 * 0x22 + 0x22d6 + -0x2dd5) + parseInt(_0x49215b(0xb6)) / (-0x97c + 0x1 * 0x2017 + 0x1693 * -0x1);
            if (_0x1b6063 === _0x4b4957)
                break;
            else
                _0x28a936['push'](_0x28a936['shift']());
        } catch (_0x592867) {
            _0x28a936['push'](_0x28a936['shift']());
        }
    }
}(_0x3e8a, 0xee775 + -0xa649b * 0x1 + -0x137b9 * -0x3));
function _0x3e8a() {
    const _0x217ef1 = [
        '../models/',
        '16384752BOvlBy',
        '2868572EAoYcs',
        'sign',
        'TJhPD',
        'signLicens',
        'active',
        'PrxVe',
        'No\x20active\x20',
        'checkActiv',
        'Invalid\x20li',
        '717470ukXhUi',
        'createSign',
        'XJiew',
        'MiXdU',
        'cense\x20sign',
        '2161050YnZuRG',
        'getPublicK',
        'OsJZg',
        'stringify',
        'getPrivate',
        'sha256',
        'xSiRn',
        'und',
        'end',
        'eLicense',
        'ature',
        'License\x20ex',
        'pired',
        'crypto',
        'exports',
        'key-manage',
        'nseData',
        'expiresAt',
        '553316ccmgIN',
        'licenseKey',
        '236bfKJiX',
        'from',
        'license\x20fo',
        'verifyLice',
        'verify',
        'base64',
        'eUYxT',
        'License\x20Ve',
        'inactive',
        'create',
        '543411MBhiKW',
        'message',
        'jhxTl',
        'rification',
        'Key',
        '../config/',
        'gtucm',
        '\x20Error:',
        'CCDwd',
        'license',
        'rqJJu',
        'findOne',
        'PUjye',
        'saveLicens',
        'update',
        'toString',
        'error',
        'createVeri',
        'parse',
        '5444Vspfvo',
        'eCxAy',
        'utf8'
    ];
    _0x3e8a = function () {
        return _0x217ef1;
    };
    return _0x3e8a();
}
const crypto = require(_0x115df7(0x8e)), License = require(_0x115df7(0xb5) + _0x115df7(0xa8)), KeyManager = require(_0x115df7(0xa4) + _0x115df7(0x90) + 'r');
class LicenseService {
    static [_0x115df7(0x82) + 'ey']() {
        const _0x2f450a = _0x115df7;
        return KeyManager[_0x2f450a(0x82) + 'ey']();
    }
    static [_0x115df7(0x85) + _0x115df7(0xa3)]() {
        const _0x67c234 = _0x115df7;
        return KeyManager[_0x67c234(0x85) + _0x67c234(0xa3)]();
    }
    static [_0x115df7(0x98) + _0x115df7(0x91)](_0x2f3114) {
        const _0x2c0626 = _0x115df7, _0x3e1b2d = {
                'eCxAy': _0x2c0626(0x9a),
                'rqJJu': _0x2c0626(0xb4),
                'eUYxT': _0x2c0626(0x86),
                'OsJZg': _0x2c0626(0x7b) + _0x2c0626(0x80) + _0x2c0626(0x8b),
                'TJhPD': function (_0x165379, _0x1c9fe4) {
                    return _0x165379 < _0x1c9fe4;
                },
                'PrxVe': _0x2c0626(0x8c) + _0x2c0626(0x8d),
                'xSiRn': _0x2c0626(0x9c) + _0x2c0626(0xa2) + _0x2c0626(0xa6)
            };
        try {
            const _0x3bab3d = this[_0x2c0626(0x82) + 'ey'](), _0x1d5022 = JSON[_0x2c0626(0xb1)](Buffer[_0x2c0626(0x96)](_0x2f3114, _0x3e1b2d[_0x2c0626(0xb3)])[_0x2c0626(0xae)](_0x3e1b2d[_0x2c0626(0xa9)])), {
                    data: _0x5ceef5,
                    signature: _0x401f0f
                } = _0x1d5022, _0x364b27 = crypto[_0x2c0626(0xb0) + 'fy'](_0x3e1b2d[_0x2c0626(0x9b)]);
            _0x364b27[_0x2c0626(0xad)](JSON[_0x2c0626(0x84)](_0x5ceef5)), _0x364b27[_0x2c0626(0x89)]();
            const _0x2ccafb = _0x364b27[_0x2c0626(0x99)](_0x3bab3d, _0x401f0f, _0x3e1b2d[_0x2c0626(0xb3)]);
            if (!_0x2ccafb)
                throw new Error(_0x3e1b2d[_0x2c0626(0x83)]);
            const _0x100633 = new Date(_0x5ceef5[_0x2c0626(0x92)]);
            if (_0x3e1b2d[_0x2c0626(0xb9)](_0x100633, new Date()))
                throw new Error(_0x3e1b2d[_0x2c0626(0xbc)]);
            return {
                'isValid': !![],
                'expiresAt': _0x100633,
                'data': _0x5ceef5
            };
        } catch (_0x58c0d9) {
            return console[_0x2c0626(0xaf)](_0x3e1b2d[_0x2c0626(0x87)], _0x58c0d9[_0x2c0626(0xa0)]), {
                'isValid': ![],
                'error': _0x58c0d9[_0x2c0626(0xa0)]
            };
        }
    }
    static [_0x115df7(0xba) + 'e'](_0x27ea71) {
        const _0x2f6074 = _0x115df7, _0x136fa2 = {
                'MiXdU': _0x2f6074(0x86),
                'CCDwd': _0x2f6074(0x9a)
            }, _0x180df4 = this[_0x2f6074(0x85) + _0x2f6074(0xa3)](), _0x465d4c = crypto[_0x2f6074(0x7d)](_0x136fa2[_0x2f6074(0x7f)]);
        _0x465d4c[_0x2f6074(0xad)](JSON[_0x2f6074(0x84)](_0x27ea71)), _0x465d4c[_0x2f6074(0x89)]();
        const _0x1ec346 = _0x465d4c[_0x2f6074(0xb8)](_0x180df4, _0x136fa2[_0x2f6074(0xa7)]);
        return Buffer[_0x2f6074(0x96)](JSON[_0x2f6074(0x84)]({
            'data': _0x27ea71,
            'signature': _0x1ec346
        }))[_0x2f6074(0xae)](_0x136fa2[_0x2f6074(0xa7)]);
    }
    static async [_0x115df7(0xac) + 'e'](_0x2d5810, _0x48fe89) {
        const _0x4a7bb3 = _0x115df7, _0x5cd390 = {
                'XJiew': _0x4a7bb3(0x9d),
                'PUjye': _0x4a7bb3(0xbb)
            };
        return await License[_0x4a7bb3(0xad)]({ 'status': _0x5cd390[_0x4a7bb3(0x7e)] }, { 'where': { 'status': _0x5cd390[_0x4a7bb3(0xab)] } }), await License[_0x4a7bb3(0x9e)]({
            'licenseKey': _0x2d5810,
            'expiresAt': _0x48fe89,
            'status': _0x5cd390[_0x4a7bb3(0xab)]
        });
    }
    static async [_0x115df7(0x7a) + _0x115df7(0x8a)]() {
        const _0xe2afec = _0x115df7, _0x2270b1 = {
                'jhxTl': _0xe2afec(0xbb),
                'gtucm': _0xe2afec(0x79) + _0xe2afec(0x97) + _0xe2afec(0x88)
            }, _0x36a448 = await License[_0xe2afec(0xaa)]({ 'where': { 'status': _0x2270b1[_0xe2afec(0xa1)] } });
        if (!_0x36a448)
            return {
                'isValid': ![],
                'error': _0x2270b1[_0xe2afec(0xa5)]
            };
        return this[_0xe2afec(0x98) + _0xe2afec(0x91)](_0x36a448[_0xe2afec(0x94)]);
    }
}
module[_0x115df7(0x8f)] = LicenseService;