function _0x1c89(_0x522cae, _0x4322d7) {
    _0x522cae = _0x522cae - (-0x6 * -0x5ab + -0x1ade * -0x1 + -0x3c21);
    const _0x2b8149 = _0x3057();
    let _0x234fcd = _0x2b8149[_0x522cae];
    return _0x234fcd;
}
const _0x2d0eac = _0x1c89;
(function (_0x5c82cf, _0x3b6343) {
    const _0x50c908 = _0x1c89, _0x5cc035 = _0x5c82cf();
    while (!![]) {
        try {
            const _0x396e13 = parseInt(_0x50c908(0xc2)) / (-0x1342 * -0x2 + -0x1 * -0x1a89 + 0x2e * -0x16a) + parseInt(_0x50c908(0xf4)) / (0x4ad * 0x2 + -0x2630 + -0xd * -0x238) * (-parseInt(_0x50c908(0xce)) / (0x116 + -0x807 * -0x4 + -0x5 * 0x6a3)) + -parseInt(_0x50c908(0xff)) / (0xf3 * -0x4 + -0x2 * 0x149 + 0x26 * 0x2b) + -parseInt(_0x50c908(0xeb)) / (-0xd * -0x2bb + -0x7ce + 0xdd6 * -0x2) + -parseInt(_0x50c908(0xd7)) / (0x315 * 0x7 + 0xd16 + -0x22a3) + -parseInt(_0x50c908(0xe5)) / (0x11fd + -0x6b * 0x28 + -0x2 * 0x9f) + -parseInt(_0x50c908(0xcd)) / (-0xd8c + -0x1 * 0x1be5 + 0x2979) * (-parseInt(_0x50c908(0xd2)) / (-0x4 * 0x820 + 0x12 * 0xed + 0xfdf));
            if (_0x396e13 === _0x3b6343)
                break;
            else
                _0x5cc035['push'](_0x5cc035['shift']());
        } catch (_0x17c440) {
            _0x5cc035['push'](_0x5cc035['shift']());
        }
    }
}(_0x3057, -0x4cf72 + 0x4 * 0x568cf + -0x4d * 0xb57));
function _0x3057() {
    const _0x35e873 = [
        'license\x20fo',
        '../config/',
        'expiresAt',
        '3919761tvctMB',
        'GEfBh',
        '../models/',
        'verifyLice',
        'sign',
        '10404438DfhNPv',
        'inactive',
        'key-manage',
        'MoYnO',
        'saveLicens',
        'ature',
        'utf8',
        'parse',
        'getPublicK',
        'end',
        'licenseKey',
        'license',
        'from',
        'ShpkU',
        '10234518AxOckm',
        'create',
        'checkActiv',
        'stringify',
        'getPrivate',
        'wAqKN',
        '8705510ATtVgs',
        'message',
        'fmEUH',
        'XKPsy',
        'findOne',
        'Invalid\x20li',
        'MTkzT',
        'AJFaV',
        'toString',
        '696646uSeVSB',
        'sha256',
        '\x20Error:',
        'hmuXM',
        'DQrzn',
        'nseData',
        'createSign',
        'error',
        'aUkfp',
        'verify',
        'License\x20ex',
        '736988FMuyNR',
        'rification',
        'update',
        'Key',
        'nMfVL',
        'signLicens',
        'eLicense',
        'exports',
        '687205zYhxjF',
        'base64',
        'crypto',
        'HTKuG',
        'active',
        'pired',
        'cense\x20sign',
        'und',
        'createVeri',
        'No\x20active\x20',
        'License\x20Ve',
        '104tNaldK',
        '3WJqJOi'
    ];
    _0x3057 = function () {
        return _0x35e873;
    };
    return _0x3057();
}
const crypto = require(_0x2d0eac(0xc4)), License = require(_0x2d0eac(0xd4) + _0x2d0eac(0xe2)), KeyManager = require(_0x2d0eac(0xd0) + _0x2d0eac(0xd9) + 'r');
class LicenseService {
    static [_0x2d0eac(0xdf) + 'ey']() {
        const _0x265947 = _0x2d0eac;
        return KeyManager[_0x265947(0xdf) + 'ey']();
    }
    static [_0x2d0eac(0xe9) + _0x2d0eac(0x102)]() {
        const _0x1d8cbd = _0x2d0eac;
        return KeyManager[_0x1d8cbd(0xe9) + _0x1d8cbd(0x102)]();
    }
    static [_0x2d0eac(0xd5) + _0x2d0eac(0xf9)](_0x53a188) {
        const _0x1a82dd = _0x2d0eac, _0x515a8a = {
                'GEfBh': _0x1a82dd(0xc3),
                'wAqKN': _0x1a82dd(0xdd),
                'MTkzT': _0x1a82dd(0xf5),
                'aUkfp': _0x1a82dd(0xf0) + _0x1a82dd(0xc8) + _0x1a82dd(0xdc),
                'ShpkU': function (_0xd8e0ff, _0x25a142) {
                    return _0xd8e0ff < _0x25a142;
                },
                'DQrzn': _0x1a82dd(0xfe) + _0x1a82dd(0xc7),
                'AJFaV': _0x1a82dd(0xcc) + _0x1a82dd(0x100) + _0x1a82dd(0xf6)
            };
        try {
            const _0x4dca4f = this[_0x1a82dd(0xdf) + 'ey'](), _0x3b3b9b = JSON[_0x1a82dd(0xde)](Buffer[_0x1a82dd(0xe3)](_0x53a188, _0x515a8a[_0x1a82dd(0xd3)])[_0x1a82dd(0xf3)](_0x515a8a[_0x1a82dd(0xea)])), {
                    data: _0x2e33cb,
                    signature: _0x1ce37c
                } = _0x3b3b9b, _0x93dbbc = crypto[_0x1a82dd(0xca) + 'fy'](_0x515a8a[_0x1a82dd(0xf1)]);
            _0x93dbbc[_0x1a82dd(0x101)](JSON[_0x1a82dd(0xe8)](_0x2e33cb)), _0x93dbbc[_0x1a82dd(0xe0)]();
            const _0x176a95 = _0x93dbbc[_0x1a82dd(0xfd)](_0x4dca4f, _0x1ce37c, _0x515a8a[_0x1a82dd(0xd3)]);
            if (!_0x176a95)
                throw new Error(_0x515a8a[_0x1a82dd(0xfc)]);
            const _0x54176f = new Date(_0x2e33cb[_0x1a82dd(0xd1)]);
            if (_0x515a8a[_0x1a82dd(0xe4)](_0x54176f, new Date()))
                throw new Error(_0x515a8a[_0x1a82dd(0xf8)]);
            return {
                'isValid': !![],
                'expiresAt': _0x54176f,
                'data': _0x2e33cb
            };
        } catch (_0x4226d0) {
            return console[_0x1a82dd(0xfb)](_0x515a8a[_0x1a82dd(0xf2)], _0x4226d0[_0x1a82dd(0xec)]), {
                'isValid': ![],
                'error': _0x4226d0[_0x1a82dd(0xec)]
            };
        }
    }
    static [_0x2d0eac(0xbf) + 'e'](_0x2828f8) {
        const _0x4dbc91 = _0x2d0eac, _0x21bad8 = {
                'XKPsy': _0x4dbc91(0xf5),
                'MoYnO': _0x4dbc91(0xc3)
            }, _0x59dc74 = this[_0x4dbc91(0xe9) + _0x4dbc91(0x102)](), _0x221b7a = crypto[_0x4dbc91(0xfa)](_0x21bad8[_0x4dbc91(0xee)]);
        _0x221b7a[_0x4dbc91(0x101)](JSON[_0x4dbc91(0xe8)](_0x2828f8)), _0x221b7a[_0x4dbc91(0xe0)]();
        const _0x474780 = _0x221b7a[_0x4dbc91(0xd6)](_0x59dc74, _0x21bad8[_0x4dbc91(0xda)]);
        return Buffer[_0x4dbc91(0xe3)](JSON[_0x4dbc91(0xe8)]({
            'data': _0x2828f8,
            'signature': _0x474780
        }))[_0x4dbc91(0xf3)](_0x21bad8[_0x4dbc91(0xda)]);
    }
    static async [_0x2d0eac(0xdb) + 'e'](_0x4384f7, _0x299bfb) {
        const _0xcc9504 = _0x2d0eac, _0x1af206 = {
                'fmEUH': _0xcc9504(0xd8),
                'HTKuG': _0xcc9504(0xc6)
            };
        return await License[_0xcc9504(0x101)]({ 'status': _0x1af206[_0xcc9504(0xed)] }, { 'where': { 'status': _0x1af206[_0xcc9504(0xc5)] } }), await License[_0xcc9504(0xe6)]({
            'licenseKey': _0x4384f7,
            'expiresAt': _0x299bfb,
            'status': _0x1af206[_0xcc9504(0xc5)]
        });
    }
    static async [_0x2d0eac(0xe7) + _0x2d0eac(0xc0)]() {
        const _0x1ceeac = _0x2d0eac, _0x1a0124 = {
                'hmuXM': _0x1ceeac(0xc6),
                'nMfVL': _0x1ceeac(0xcb) + _0x1ceeac(0xcf) + _0x1ceeac(0xc9)
            }, _0x478f59 = await License[_0x1ceeac(0xef)]({ 'where': { 'status': _0x1a0124[_0x1ceeac(0xf7)] } });
        if (!_0x478f59)
            return {
                'isValid': ![],
                'error': _0x1a0124[_0x1ceeac(0x103)]
            };
        return this[_0x1ceeac(0xd5) + _0x1ceeac(0xf9)](_0x478f59[_0x1ceeac(0xe1)]);
    }
}
module[_0x2d0eac(0xc1)] = LicenseService;