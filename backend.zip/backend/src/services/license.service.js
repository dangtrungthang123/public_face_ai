const _0xc7b27c = _0x3a39;
(function (_0x3acd3d, _0x39fef7) {
    const _0x237a1f = _0x3a39, _0x4b3617 = _0x3acd3d();
    while (!![]) {
        try {
            const _0xe79083 = parseInt(_0x237a1f(0x191)) / (0x23c1 + 0x1 * -0x1597 + 0x7d * -0x1d) * (parseInt(_0x237a1f(0x187)) / (-0x32 + -0x5a * 0x34 + -0xb6 * -0x1a)) + parseInt(_0x237a1f(0x1ae)) / (-0x19ba + -0x47f * 0x3 + 0x139d * 0x2) + parseInt(_0x237a1f(0x183)) / (0x1682 + -0x2 * -0x136f + -0x3d5c) * (parseInt(_0x237a1f(0x1b6)) / (0x22b2 + -0x1 * 0xf9d + -0x1310)) + parseInt(_0x237a1f(0x182)) / (0x494 + -0x1 * 0x1215 + 0xd87) * (parseInt(_0x237a1f(0x199)) / (0x2639 + 0x11e5 * -0x1 + 0x144d * -0x1)) + -parseInt(_0x237a1f(0x18d)) / (0x262 * 0x2 + 0x1 * -0xbd3 + 0x717) + -parseInt(_0x237a1f(0x18b)) / (-0x1 * 0x11eb + -0x1cb0 + 0x2ea4) + -parseInt(_0x237a1f(0x1bb)) / (-0x36e * -0x8 + -0xd * -0x10d + -0x290f) * (parseInt(_0x237a1f(0x18e)) / (0x1336 + 0x1 * 0x1b4f + -0x6 * 0x7bf));
            if (_0xe79083 === _0x39fef7)
                break;
            else
                _0x4b3617['push'](_0x4b3617['shift']());
        } catch (_0xdccca7) {
            _0x4b3617['push'](_0x4b3617['shift']());
        }
    }
}(_0x44f9, -0x14659 + 0x7f789 + -0x103 * -0x1c1));
const crypto = require(_0xc7b27c(0x1b8)), License = require(_0xc7b27c(0x1b1) + _0xc7b27c(0x1b0)), KeyManager = require(_0xc7b27c(0x194) + _0xc7b27c(0x1b2) + 'r');
class LicenseService {
    static [_0xc7b27c(0x1b4) + 'ey']() {
        const _0xa738c4 = _0xc7b27c;
        return KeyManager[_0xa738c4(0x1b4) + 'ey']();
    }
    static [_0xc7b27c(0x1bd) + _0xc7b27c(0x1bc)]() {
        const _0x34f83d = _0xc7b27c;
        return KeyManager[_0x34f83d(0x1bd) + _0x34f83d(0x1bc)]();
    }
    static [_0xc7b27c(0x192) + _0xc7b27c(0x185)](_0x1cff70) {
        const _0x64a97d = _0xc7b27c, _0x7842fb = {
                'BmuzC': _0x64a97d(0x1b9),
                'VSQEg': _0x64a97d(0x1ba),
                'ZCjgI': _0x64a97d(0x195),
                'OpkQM': _0x64a97d(0x1a7) + _0x64a97d(0x18a) + _0x64a97d(0x18f),
                'gbYNT': function (_0x40c10c, _0x217a9d) {
                    return _0x40c10c < _0x217a9d;
                },
                'bWsul': _0x64a97d(0x184) + _0x64a97d(0x1aa),
                'kanuY': _0x64a97d(0x17d) + _0x64a97d(0x1b7) + _0x64a97d(0x1ad)
            };
        try {
            const _0x5e8b42 = this[_0x64a97d(0x1b4) + 'ey'](), _0x33571c = JSON[_0x64a97d(0x181)](Buffer[_0x64a97d(0x186)](_0x1cff70, _0x7842fb[_0x64a97d(0x190)])[_0x64a97d(0x188)](_0x7842fb[_0x64a97d(0x19b)])), {
                    data: _0x16c565,
                    signature: _0x454615
                } = _0x33571c, _0x26afbc = crypto[_0x64a97d(0x1a8) + 'fy'](_0x7842fb[_0x64a97d(0x198)]);
            _0x26afbc[_0x64a97d(0x19a)](JSON[_0x64a97d(0x196)](_0x16c565)), _0x26afbc[_0x64a97d(0x1be)]();
            const _0x51231d = _0x26afbc[_0x64a97d(0x17a)](_0x5e8b42, _0x454615, _0x7842fb[_0x64a97d(0x190)]);
            if (!_0x51231d)
                throw new Error(_0x7842fb[_0x64a97d(0x19f)]);
            const _0x46f89b = new Date(_0x16c565[_0x64a97d(0x1a6)]);
            if (_0x7842fb[_0x64a97d(0x178)](_0x46f89b, new Date()))
                throw new Error(_0x7842fb[_0x64a97d(0x1a1)]);
            return {
                'isValid': !![],
                'expiresAt': _0x46f89b,
                'data': _0x16c565
            };
        } catch (_0x29c89) {
            return console[_0x64a97d(0x189)](_0x7842fb[_0x64a97d(0x18c)], _0x29c89[_0x64a97d(0x19e)]), {
                'isValid': ![],
                'error': _0x29c89[_0x64a97d(0x19e)]
            };
        }
    }
    static [_0xc7b27c(0x17f) + 'e'](_0x30c76e) {
        const _0x5ebc2f = _0xc7b27c, _0x1753c9 = {
                'mNDUO': _0x5ebc2f(0x195),
                'KacWi': _0x5ebc2f(0x1b9)
            }, _0x36e4a0 = this[_0x5ebc2f(0x1bd) + _0x5ebc2f(0x1bc)](), _0x3d76ff = crypto[_0x5ebc2f(0x1a5)](_0x1753c9[_0x5ebc2f(0x1a9)]);
        _0x3d76ff[_0x5ebc2f(0x19a)](JSON[_0x5ebc2f(0x196)](_0x30c76e)), _0x3d76ff[_0x5ebc2f(0x1be)]();
        const _0x22899f = _0x3d76ff[_0x5ebc2f(0x1af)](_0x36e4a0, _0x1753c9[_0x5ebc2f(0x197)]);
        return Buffer[_0x5ebc2f(0x186)](JSON[_0x5ebc2f(0x196)]({
            'data': _0x30c76e,
            'signature': _0x22899f
        }))[_0x5ebc2f(0x188)](_0x1753c9[_0x5ebc2f(0x197)]);
    }
    static async [_0xc7b27c(0x1a4) + 'e'](_0x5f0fc8, _0x5cc96e) {
        const _0x38b73c = _0xc7b27c, _0x17edcb = {
                'Rsyke': _0x38b73c(0x17b),
                'YWhyO': _0x38b73c(0x1ac)
            };
        return await License[_0x38b73c(0x19a)]({ 'status': _0x17edcb[_0x38b73c(0x19c)] }, { 'where': { 'status': _0x17edcb[_0x38b73c(0x1b3)] } }), await License[_0x38b73c(0x17e)]({
            'licenseKey': _0x5f0fc8,
            'expiresAt': _0x5cc96e,
            'status': _0x17edcb[_0x38b73c(0x1b3)]
        });
    }
    static async [_0xc7b27c(0x19d) + _0xc7b27c(0x180)]() {
        const _0x3a9185 = _0xc7b27c, _0xd9c728 = {
                'WLqci': _0x3a9185(0x1ac),
                'HxyeZ': _0x3a9185(0x17c) + _0x3a9185(0x1ab) + _0x3a9185(0x1a2)
            }, _0x4104cb = await License[_0x3a9185(0x193)]({ 'where': { 'status': _0xd9c728[_0x3a9185(0x1a3)] } });
        if (!_0x4104cb)
            return {
                'isValid': ![],
                'error': _0xd9c728[_0x3a9185(0x1a0)]
            };
        return this[_0x3a9185(0x192) + _0x3a9185(0x185)](_0x4104cb[_0x3a9185(0x1b5)]);
    }
}
function _0x3a39(_0x2c6430, _0x2559b3) {
    _0x2c6430 = _0x2c6430 - (0x1 * -0x57a + -0x3d5 + 0xac7);
    const _0x550982 = _0x44f9();
    let _0x225706 = _0x550982[_0x2c6430];
    return _0x225706;
}
function _0x44f9() {
    const _0x1970f3 = [
        'verifyLice',
        'findOne',
        '../config/',
        'sha256',
        'stringify',
        'KacWi',
        'ZCjgI',
        '2870315oeeeEF',
        'update',
        'VSQEg',
        'Rsyke',
        'checkActiv',
        'message',
        'OpkQM',
        'HxyeZ',
        'bWsul',
        'und',
        'WLqci',
        'saveLicens',
        'createSign',
        'expiresAt',
        'Invalid\x20li',
        'createVeri',
        'mNDUO',
        'pired',
        'license\x20fo',
        'active',
        '\x20Error:',
        '1517436CgZNtX',
        'sign',
        'license',
        '../models/',
        'key-manage',
        'YWhyO',
        'getPublicK',
        'licenseKey',
        '20jMxqkp',
        'rification',
        'crypto',
        'base64',
        'utf8',
        '10lUASMF',
        'Key',
        'getPrivate',
        'end',
        'gbYNT',
        'exports',
        'verify',
        'inactive',
        'No\x20active\x20',
        'License\x20Ve',
        'create',
        'signLicens',
        'eLicense',
        'parse',
        '12chHCqV',
        '129228nosFME',
        'License\x20ex',
        'nseData',
        'from',
        '2driUur',
        'toString',
        'error',
        'cense\x20sign',
        '7513587qTcIBw',
        'kanuY',
        '5436952yBBVwf',
        '2718034togrNU',
        'ature',
        'BmuzC',
        '861293xiCUMW'
    ];
    _0x44f9 = function () {
        return _0x1970f3;
    };
    return _0x44f9();
}
module[_0xc7b27c(0x179)] = LicenseService;