function _0x4b7f(_0x4c793a, _0xda7723) {
    _0x4c793a = _0x4c793a - (0x6b * 0x3a + -0xe0e * 0x1 + -0x59 * 0x19);
    const _0x92f710 = _0x4920();
    let _0x20b5b2 = _0x92f710[_0x4c793a];
    return _0x20b5b2;
}
function _0x4920() {
    const _0x472b3b = [
        'No\x20active\x20',
        'wtWEy',
        'expiresAt',
        'parse',
        'Key',
        'utf8',
        'ybkDO',
        'TQySb',
        'signLicens',
        'pired',
        'inactive',
        'YFbCb',
        'active',
        '2706802BJIrlU',
        '330oKMSKw',
        'base64',
        'key-manage',
        '39076xCuZGC',
        'License\x20Ve',
        '../config/',
        'licenseKey',
        'Invalid\x20li',
        'stringify',
        'und',
        'create',
        'ature',
        '758856JLlAJw',
        'license',
        'update',
        'XtWQt',
        'nseData',
        'error',
        '1618705enOmmj',
        'NuRXb',
        'getPublicK',
        'rification',
        'sha256',
        'eLicense',
        'xGFaC',
        'KTCJP',
        '\x20Error:',
        'cense\x20sign',
        'License\x20ex',
        'toString',
        'InuDe',
        'license\x20fo',
        '1333020UZvYhP',
        'message',
        'crypto',
        'createVeri',
        '16632468GHALDS',
        'createSign',
        'KcDad',
        'from',
        'findOne',
        '../models/',
        'tVwAX',
        'verify',
        '982948kjBgOC',
        'checkActiv',
        'exports',
        'kAfQm',
        'verifyLice',
        'end',
        'getPrivate',
        '16NSUsYt',
        'saveLicens',
        'fsPHL',
        'sign'
    ];
    _0x4920 = function () {
        return _0x472b3b;
    };
    return _0x4920();
}
const _0x54b854 = _0x4b7f;
(function (_0x481895, _0x3b8cf1) {
    const _0x1f7028 = _0x4b7f, _0x4b31a8 = _0x481895();
    while (!![]) {
        try {
            const _0x3dbfd9 = -parseInt(_0x1f7028(0x1b2)) / (-0x2071 + 0x25 * 0x1a + 0x1cb0) + -parseInt(_0x1f7028(0x18d)) / (-0x230d * 0x1 + 0x45f + -0xf58 * -0x2) + -parseInt(_0x1f7028(0x1a6)) / (-0x1a57 + -0x2474 + -0x1 * -0x3ece) * (-parseInt(_0x1f7028(0x1a9)) / (0x1c6f + 0x2500 + -0x416b * 0x1)) + -parseInt(_0x1f7028(0x1b8)) / (-0x1 * -0xad3 + 0x19 * 0x59 + -0x137f) + parseInt(_0x1f7028(0x181)) / (0x1 * 0x774 + 0x1 * 0x2429 + -0x1 * 0x2b97) + -parseInt(_0x1f7028(0x1a5)) / (-0x10e5 + -0x1e3e * -0x1 + -0xd52) * (parseInt(_0x1f7028(0x194)) / (0x6fd + -0x1 * 0x7b5 + 0x6 * 0x20)) + parseInt(_0x1f7028(0x185)) / (0x2142 + 0x16b9 + -0x7fe * 0x7);
            if (_0x3dbfd9 === _0x3b8cf1)
                break;
            else
                _0x4b31a8['push'](_0x4b31a8['shift']());
        } catch (_0x149cde) {
            _0x4b31a8['push'](_0x4b31a8['shift']());
        }
    }
}(_0x4920, 0x99cc8 + -0x151041 * -0x1 + -0x128250));
const crypto = require(_0x54b854(0x183)), License = require(_0x54b854(0x18a) + _0x54b854(0x1b3)), KeyManager = require(_0x54b854(0x1ab) + _0x54b854(0x1a8) + 'r');
class LicenseService {
    static [_0x54b854(0x1ba) + 'ey']() {
        const _0x29e8aa = _0x54b854;
        return KeyManager[_0x29e8aa(0x1ba) + 'ey']();
    }
    static [_0x54b854(0x193) + _0x54b854(0x19c)]() {
        const _0x23ef7c = _0x54b854;
        return KeyManager[_0x23ef7c(0x193) + _0x23ef7c(0x19c)]();
    }
    static [_0x54b854(0x191) + _0x54b854(0x1b6)](_0x4d8075) {
        const _0x43384b = _0x54b854, _0x45c248 = {
                'fsPHL': _0x43384b(0x1a7),
                'kAfQm': _0x43384b(0x19d),
                'ybkDO': _0x43384b(0x1bc),
                'KTCJP': _0x43384b(0x1ad) + _0x43384b(0x1c1) + _0x43384b(0x1b1),
                'XtWQt': function (_0x5dd00b, _0x5dc4b2) {
                    return _0x5dd00b < _0x5dc4b2;
                },
                'tVwAX': _0x43384b(0x1c2) + _0x43384b(0x1a1),
                'TQySb': _0x43384b(0x1aa) + _0x43384b(0x1bb) + _0x43384b(0x1c0)
            };
        try {
            const _0x2cdb44 = this[_0x43384b(0x1ba) + 'ey'](), _0x27232e = JSON[_0x43384b(0x19b)](Buffer[_0x43384b(0x188)](_0x4d8075, _0x45c248[_0x43384b(0x196)])[_0x43384b(0x1c3)](_0x45c248[_0x43384b(0x190)])), {
                    data: _0xa71737,
                    signature: _0x36ae4f
                } = _0x27232e, _0x401ada = crypto[_0x43384b(0x184) + 'fy'](_0x45c248[_0x43384b(0x19e)]);
            _0x401ada[_0x43384b(0x1b4)](JSON[_0x43384b(0x1ae)](_0xa71737)), _0x401ada[_0x43384b(0x192)]();
            const _0x3bae6d = _0x401ada[_0x43384b(0x18c)](_0x2cdb44, _0x36ae4f, _0x45c248[_0x43384b(0x196)]);
            if (!_0x3bae6d)
                throw new Error(_0x45c248[_0x43384b(0x1bf)]);
            const _0x40b8ff = new Date(_0xa71737[_0x43384b(0x19a)]);
            if (_0x45c248[_0x43384b(0x1b5)](_0x40b8ff, new Date()))
                throw new Error(_0x45c248[_0x43384b(0x18b)]);
            return {
                'isValid': !![],
                'expiresAt': _0x40b8ff,
                'data': _0xa71737
            };
        } catch (_0x299869) {
            return console[_0x43384b(0x1b7)](_0x45c248[_0x43384b(0x19f)], _0x299869[_0x43384b(0x182)]), {
                'isValid': ![],
                'error': _0x299869[_0x43384b(0x182)]
            };
        }
    }
    static [_0x54b854(0x1a0) + 'e'](_0x333e4f) {
        const _0x5b9b91 = _0x54b854, _0x5c466c = {
                'xGFaC': _0x5b9b91(0x1bc),
                'YFbCb': _0x5b9b91(0x1a7)
            }, _0x21ef10 = this[_0x5b9b91(0x193) + _0x5b9b91(0x19c)](), _0x413579 = crypto[_0x5b9b91(0x186)](_0x5c466c[_0x5b9b91(0x1be)]);
        _0x413579[_0x5b9b91(0x1b4)](JSON[_0x5b9b91(0x1ae)](_0x333e4f)), _0x413579[_0x5b9b91(0x192)]();
        const _0x4fb80c = _0x413579[_0x5b9b91(0x197)](_0x21ef10, _0x5c466c[_0x5b9b91(0x1a3)]);
        return Buffer[_0x5b9b91(0x188)](JSON[_0x5b9b91(0x1ae)]({
            'data': _0x333e4f,
            'signature': _0x4fb80c
        }))[_0x5b9b91(0x1c3)](_0x5c466c[_0x5b9b91(0x1a3)]);
    }
    static async [_0x54b854(0x195) + 'e'](_0xdc37e4, _0x3ba7c1) {
        const _0xe800d2 = _0x54b854, _0x3b71df = {
                'NuRXb': _0xe800d2(0x1a2),
                'KcDad': _0xe800d2(0x1a4)
            };
        return await License[_0xe800d2(0x1b4)]({ 'status': _0x3b71df[_0xe800d2(0x1b9)] }, { 'where': { 'status': _0x3b71df[_0xe800d2(0x187)] } }), await License[_0xe800d2(0x1b0)]({
            'licenseKey': _0xdc37e4,
            'expiresAt': _0x3ba7c1,
            'status': _0x3b71df[_0xe800d2(0x187)]
        });
    }
    static async [_0x54b854(0x18e) + _0x54b854(0x1bd)]() {
        const _0x3dfc1e = _0x54b854, _0x2b367e = {
                'InuDe': _0x3dfc1e(0x1a4),
                'wtWEy': _0x3dfc1e(0x198) + _0x3dfc1e(0x180) + _0x3dfc1e(0x1af)
            }, _0x336169 = await License[_0x3dfc1e(0x189)]({ 'where': { 'status': _0x2b367e[_0x3dfc1e(0x17f)] } });
        if (!_0x336169)
            return {
                'isValid': ![],
                'error': _0x2b367e[_0x3dfc1e(0x199)]
            };
        return this[_0x3dfc1e(0x191) + _0x3dfc1e(0x1b6)](_0x336169[_0x3dfc1e(0x1ac)]);
    }
}
module[_0x54b854(0x18f)] = LicenseService;