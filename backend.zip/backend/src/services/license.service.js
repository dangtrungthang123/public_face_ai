function _0x129a() {
    const _0x285e52 = [
        '1070498lUdeNc',
        'verifyLice',
        'License\x20Ve',
        'key-manage',
        'verify',
        'exports',
        'sRTGO',
        'olkyx',
        'findOne',
        'mdXat',
        'ature',
        '77010DWxHDK',
        '4466648WzeVGg',
        '../config/',
        'rification',
        'create',
        'toString',
        'WrOeH',
        'AxkpR',
        'License\x20ex',
        'checkActiv',
        'utf8',
        'INBfe',
        '15BXmMQt',
        'ytigD',
        'update',
        '\x20Error:',
        'expiresAt',
        'sign',
        'base64',
        '../models/',
        '2049670fQteRG',
        'IxxNh',
        'signLicens',
        'error',
        '461756AdNkGu',
        'Invalid\x20li',
        'Key',
        'rcwyA',
        'saveLicens',
        'crypto',
        '85671ZLZCJx',
        'ervJF',
        'from',
        'inactive',
        'getPublicK',
        'pired',
        'license\x20fo',
        'sha256',
        'end',
        'und',
        'stringify',
        'hvGny',
        'xYrlg',
        'eLicense',
        '36SjQSFI',
        'message',
        'licenseKey',
        'No\x20active\x20',
        'getPrivate',
        'cense\x20sign',
        'nseData',
        'license',
        'createSign',
        'parse',
        'active',
        'VPDEG',
        'createVeri',
        '4265952qlxuSB'
    ];
    _0x129a = function () {
        return _0x285e52;
    };
    return _0x129a();
}
const _0x1d0256 = _0xd01f;
(function (_0x5f9952, _0x41e03c) {
    const _0x3c4ad0 = _0xd01f, _0x15e597 = _0x5f9952();
    while (!![]) {
        try {
            const _0x38ee1c = parseInt(_0x3c4ad0(0x136)) / (-0x26a9 + -0x54d * 0x2 + 0x3144) + parseInt(_0x3c4ad0(0x10d)) / (0x228f + 0x1678 + -0x3905) + -parseInt(_0x3c4ad0(0x10c)) / (0xae1 + -0x2 * -0x11f5 + -0xbb2 * 0x4) + -parseInt(_0x3c4ad0(0x130)) / (-0x236 * 0x9 + 0xd * -0x179 + 0x270f) * (parseInt(_0x3c4ad0(0x124)) / (-0x1276 + 0xcb + 0x11b0)) + -parseInt(_0x3c4ad0(0x118)) / (-0x20d3 + 0xb5 * -0x3 + -0x45f * -0x8) + -parseInt(_0x3c4ad0(0x12c)) / (-0x1521 + -0xf23 + -0x13 * -0x1e9) + -parseInt(_0x3c4ad0(0x119)) / (-0x29 * -0x67 + 0x1742 + -0x27b9) * (-parseInt(_0x3c4ad0(0x144)) / (-0x1314 + 0x41a + -0xf03 * -0x1));
            if (_0x38ee1c === _0x41e03c)
                break;
            else
                _0x15e597['push'](_0x15e597['shift']());
        } catch (_0x1f10aa) {
            _0x15e597['push'](_0x15e597['shift']());
        }
    }
}(_0x129a, -0x940ab * 0x1 + -0x104833 + 0x95c3a * 0x4));
function _0xd01f(_0x4641d7, _0x2c80c5) {
    _0x4641d7 = _0x4641d7 - (-0x2072 + 0x1d0a + 0x46c);
    const _0x787795 = _0x129a();
    let _0x2f23ea = _0x787795[_0x4641d7];
    return _0x2f23ea;
}
const crypto = require(_0x1d0256(0x135)), License = require(_0x1d0256(0x12b) + _0x1d0256(0x106)), KeyManager = require(_0x1d0256(0x11a) + _0x1d0256(0x110) + 'r');
class LicenseService {
    static [_0x1d0256(0x13a) + 'ey']() {
        const _0xfce272 = _0x1d0256;
        return KeyManager[_0xfce272(0x13a) + 'ey']();
    }
    static [_0x1d0256(0x148) + _0x1d0256(0x132)]() {
        const _0xc5eec5 = _0x1d0256;
        return KeyManager[_0xc5eec5(0x148) + _0xc5eec5(0x132)]();
    }
    static [_0x1d0256(0x10e) + _0x1d0256(0x105)](_0x3a70c6) {
        const _0x25e812 = _0x1d0256, _0x5c76ac = {
                'hvGny': _0x25e812(0x12a),
                'sRTGO': _0x25e812(0x122),
                'ytigD': _0x25e812(0x13d),
                'AxkpR': _0x25e812(0x131) + _0x25e812(0x104) + _0x25e812(0x117),
                'IxxNh': function (_0x3d58cb, _0x230ac8) {
                    return _0x3d58cb < _0x230ac8;
                },
                'rcwyA': _0x25e812(0x120) + _0x25e812(0x13b),
                'xYrlg': _0x25e812(0x10f) + _0x25e812(0x11b) + _0x25e812(0x127)
            };
        try {
            const _0x1a42aa = this[_0x25e812(0x13a) + 'ey'](), _0x20db35 = JSON[_0x25e812(0x108)](Buffer[_0x25e812(0x138)](_0x3a70c6, _0x5c76ac[_0x25e812(0x141)])[_0x25e812(0x11d)](_0x5c76ac[_0x25e812(0x113)])), {
                    data: _0x4011f5,
                    signature: _0x4cfabc
                } = _0x20db35, _0x51a431 = crypto[_0x25e812(0x10b) + 'fy'](_0x5c76ac[_0x25e812(0x125)]);
            _0x51a431[_0x25e812(0x126)](JSON[_0x25e812(0x140)](_0x4011f5)), _0x51a431[_0x25e812(0x13e)]();
            const _0x4a5842 = _0x51a431[_0x25e812(0x111)](_0x1a42aa, _0x4cfabc, _0x5c76ac[_0x25e812(0x141)]);
            if (!_0x4a5842)
                throw new Error(_0x5c76ac[_0x25e812(0x11f)]);
            const _0x541218 = new Date(_0x4011f5[_0x25e812(0x128)]);
            if (_0x5c76ac[_0x25e812(0x12d)](_0x541218, new Date()))
                throw new Error(_0x5c76ac[_0x25e812(0x133)]);
            return {
                'isValid': !![],
                'expiresAt': _0x541218,
                'data': _0x4011f5
            };
        } catch (_0x3f68cb) {
            return console[_0x25e812(0x12f)](_0x5c76ac[_0x25e812(0x142)], _0x3f68cb[_0x25e812(0x145)]), {
                'isValid': ![],
                'error': _0x3f68cb[_0x25e812(0x145)]
            };
        }
    }
    static [_0x1d0256(0x12e) + 'e'](_0x10ce84) {
        const _0x1ac2d1 = _0x1d0256, _0x3de0bb = {
                'ervJF': _0x1ac2d1(0x13d),
                'mdXat': _0x1ac2d1(0x12a)
            }, _0x3accc3 = this[_0x1ac2d1(0x148) + _0x1ac2d1(0x132)](), _0x256e93 = crypto[_0x1ac2d1(0x107)](_0x3de0bb[_0x1ac2d1(0x137)]);
        _0x256e93[_0x1ac2d1(0x126)](JSON[_0x1ac2d1(0x140)](_0x10ce84)), _0x256e93[_0x1ac2d1(0x13e)]();
        const _0x34e89d = _0x256e93[_0x1ac2d1(0x129)](_0x3accc3, _0x3de0bb[_0x1ac2d1(0x116)]);
        return Buffer[_0x1ac2d1(0x138)](JSON[_0x1ac2d1(0x140)]({
            'data': _0x10ce84,
            'signature': _0x34e89d
        }))[_0x1ac2d1(0x11d)](_0x3de0bb[_0x1ac2d1(0x116)]);
    }
    static async [_0x1d0256(0x134) + 'e'](_0x25eebe, _0x2d01be) {
        const _0x1cf774 = _0x1d0256, _0x5a52d1 = {
                'INBfe': _0x1cf774(0x139),
                'WrOeH': _0x1cf774(0x109)
            };
        return await License[_0x1cf774(0x126)]({ 'status': _0x5a52d1[_0x1cf774(0x123)] }, { 'where': { 'status': _0x5a52d1[_0x1cf774(0x11e)] } }), await License[_0x1cf774(0x11c)]({
            'licenseKey': _0x25eebe,
            'expiresAt': _0x2d01be,
            'status': _0x5a52d1[_0x1cf774(0x11e)]
        });
    }
    static async [_0x1d0256(0x121) + _0x1d0256(0x143)]() {
        const _0x5b552f = _0x1d0256, _0x3afaf7 = {
                'olkyx': _0x5b552f(0x109),
                'VPDEG': _0x5b552f(0x147) + _0x5b552f(0x13c) + _0x5b552f(0x13f)
            }, _0x1e0b17 = await License[_0x5b552f(0x115)]({ 'where': { 'status': _0x3afaf7[_0x5b552f(0x114)] } });
        if (!_0x1e0b17)
            return {
                'isValid': ![],
                'error': _0x3afaf7[_0x5b552f(0x10a)]
            };
        return this[_0x5b552f(0x10e) + _0x5b552f(0x105)](_0x1e0b17[_0x5b552f(0x146)]);
    }
}
module[_0x1d0256(0x112)] = LicenseService;