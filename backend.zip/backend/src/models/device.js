function _0x58d4() {
    const _0x43590d = [
        '3633682YCfEuj',
        'exports',
        '16tvZieC',
        'define',
        '18199310QpWPIX',
        '1671912TdUFoP',
        'ENUM',
        '137270sFrCkh',
        '1044581CWOgsW',
        'STRING',
        '11oDceBA',
        'DATE',
        'Device',
        'offline',
        'sequelize',
        'NOW',
        'New\x20Device',
        '3ZsEDBy',
        '1099Qfxkrf',
        '../config/',
        '3782732ZTyQxM',
        'online',
        '27582YAGwnV',
        'devices',
        'database'
    ];
    _0x58d4 = function () {
        return _0x43590d;
    };
    return _0x58d4();
}
const _0xad69f = _0x5de6;
(function (_0x2a2e9c, _0xbe8121) {
    const _0xe305ef = _0x5de6, _0x1b0d44 = _0x2a2e9c();
    while (!![]) {
        try {
            const _0x325d08 = parseInt(_0xe305ef(0x1fa)) / (0x1744 + -0x1 * -0xa97 + -0x2 * 0x10ed) + parseInt(_0xe305ef(0x1f2)) / (-0x161 * -0x13 + -0xf12 + -0xb1f) * (parseInt(_0xe305ef(0x1ea)) / (-0x19d5 + -0x2255 + 0x3c2d)) + parseInt(_0xe305ef(0x1ed)) / (0x63a * 0x6 + 0x3e * -0x4 + -0x2460) + parseInt(_0xe305ef(0x1f9)) / (0x5 * -0x501 + 0x4a * -0x2 + 0x6 * 0x445) + parseInt(_0xe305ef(0x1ef)) / (-0x184 * -0x1 + 0x11 * 0x23b + -0x2769) * (-parseInt(_0xe305ef(0x1eb)) / (-0x1f1e + 0x2 * 0xb99 + 0x197 * 0x5)) + parseInt(_0xe305ef(0x1f4)) / (-0x5 * -0x619 + -0x1c2 + 0x4f * -0x5d) * (-parseInt(_0xe305ef(0x1f7)) / (-0x1 * -0xf23 + 0x389 + 0x1 * -0x12a3)) + -parseInt(_0xe305ef(0x1f6)) / (-0x2 * 0xcff + 0xa4d * -0x3 + 0x38ef) * (parseInt(_0xe305ef(0x1e3)) / (-0x4 * -0x8cf + -0x144c + -0xee5));
            if (_0x325d08 === _0xbe8121)
                break;
            else
                _0x1b0d44['push'](_0x1b0d44['shift']());
        } catch (_0x1b011c) {
            _0x1b0d44['push'](_0x1b0d44['shift']());
        }
    }
}(_0x58d4, 0x100b40 + -0xd883f + -0xb8c12 * -0x1));
function _0x5de6(_0xe0be57, _0x2edefb) {
    _0xe0be57 = _0xe0be57 - (0x256b * 0x1 + -0x89 * -0x5 + -0x2635);
    const _0xf343a2 = _0x58d4();
    let _0x57091a = _0xf343a2[_0xe0be57];
    return _0x57091a;
}
const {DataTypes} = require(_0xad69f(0x1e7)), sequelize = require(_0xad69f(0x1ec) + _0xad69f(0x1f1)), Device = sequelize[_0xad69f(0x1f5)](_0xad69f(0x1e5), {
        'sn': {
            'type': DataTypes[_0xad69f(0x1fb)],
            'primaryKey': !![],
            'allowNull': ![]
        },
        'name': {
            'type': DataTypes[_0xad69f(0x1fb)],
            'defaultValue': _0xad69f(0x1e9)
        },
        'status': {
            'type': DataTypes[_0xad69f(0x1f8)](_0xad69f(0x1ee), _0xad69f(0x1e6)),
            'defaultValue': _0xad69f(0x1e6)
        },
        'last_seen': {
            'type': DataTypes[_0xad69f(0x1e4)],
            'defaultValue': DataTypes[_0xad69f(0x1e8)]
        },
        'ip_address': {
            'type': DataTypes[_0xad69f(0x1fb)],
            'allowNull': !![]
        }
    }, {
        'tableName': _0xad69f(0x1f0),
        'timestamps': !![]
    });
module[_0xad69f(0x1f3)] = Device;