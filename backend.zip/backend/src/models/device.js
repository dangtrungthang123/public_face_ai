const _0x28e9cf = _0x454d;
function _0x454d(_0x23e836, _0x101e5e) {
    _0x23e836 = _0x23e836 - (-0x116b + 0x2 * -0x1381 + -0x46a * -0xd);
    const _0x5e001f = _0x1516();
    let _0x2b070a = _0x5e001f[_0x23e836];
    return _0x2b070a;
}
(function (_0x25400c, _0x59d31a) {
    const _0x22eade = _0x454d, _0x1be6de = _0x25400c();
    while (!![]) {
        try {
            const _0x5a3f39 = -parseInt(_0x22eade(0xfe)) / (0xdf0 + 0xda7 + -0x1b96) + parseInt(_0x22eade(0xfc)) / (0x186 + 0x10 * 0x15d + -0x2 * 0xbaa) * (parseInt(_0x22eade(0x104)) / (0x25f3 + -0x1dc0 + -0x830)) + -parseInt(_0x22eade(0x101)) / (0x2089 + 0x120e + -0x3293) + parseInt(_0x22eade(0xff)) / (-0x2049 + -0x1c * -0x31 + 0x1af2) + parseInt(_0x22eade(0x100)) / (0xcfc + -0x1169 * 0x1 + 0x473 * 0x1) + -parseInt(_0x22eade(0xf6)) / (-0x1ea7 + 0x1 * 0x502 + 0x19ac) * (-parseInt(_0x22eade(0x102)) / (-0x9c2 + 0x47f + 0x54b * 0x1)) + -parseInt(_0x22eade(0xfd)) / (-0x3 * -0x7e2 + 0x1d42 + -0x34df) * (-parseInt(_0x22eade(0xf5)) / (-0x440 * 0x5 + -0x208f * 0x1 + -0xac5 * -0x5));
            if (_0x5a3f39 === _0x59d31a)
                break;
            else
                _0x1be6de['push'](_0x1be6de['shift']());
        } catch (_0x6defbf) {
            _0x1be6de['push'](_0x1be6de['shift']());
        }
    }
}(_0x1516, 0x1 * 0x7b2b4 + 0x55a * 0x1cc + -0x54af * 0x1d));
function _0x1516() {
    const _0x2565a6 = [
        'exports',
        'NOW',
        '../config/',
        'sequelize',
        'Device',
        'ENUM',
        'offline',
        'STRING',
        '644330xxIAmS',
        '2343383ykWCWX',
        'database',
        'New\x20Device',
        'DATE',
        'online',
        'define',
        '211142xXzijo',
        '108EHhMEj',
        '395684JnJtoA',
        '1435520pNcSZK',
        '2088660FdFIrN',
        '3788228wOJyqw',
        '8kZNyxn',
        'devices',
        '3LnYQIr'
    ];
    _0x1516 = function () {
        return _0x2565a6;
    };
    return _0x1516();
}
const {DataTypes} = require(_0x28e9cf(0x108)), sequelize = require(_0x28e9cf(0x107) + _0x28e9cf(0xf7)), Device = sequelize[_0x28e9cf(0xfb)](_0x28e9cf(0x109), {
        'sn': {
            'type': DataTypes[_0x28e9cf(0x10c)],
            'primaryKey': !![],
            'allowNull': ![]
        },
        'name': {
            'type': DataTypes[_0x28e9cf(0x10c)],
            'defaultValue': _0x28e9cf(0xf8)
        },
        'status': {
            'type': DataTypes[_0x28e9cf(0x10a)](_0x28e9cf(0xfa), _0x28e9cf(0x10b)),
            'defaultValue': _0x28e9cf(0x10b)
        },
        'last_seen': {
            'type': DataTypes[_0x28e9cf(0xf9)],
            'defaultValue': DataTypes[_0x28e9cf(0x106)]
        },
        'ip_address': {
            'type': DataTypes[_0x28e9cf(0x10c)],
            'allowNull': !![]
        },
        'list_airline_enable_com': {
            'type': DataTypes[_0x28e9cf(0x10c)],
            'allowNull': !![],
            'defaultValue': ''
        }
    }, {
        'tableName': _0x28e9cf(0x103),
        'timestamps': !![]
    });
module[_0x28e9cf(0x105)] = Device;