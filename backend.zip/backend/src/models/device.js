const _0x24f994 = _0x7539;
function _0x2c1e() {
    const _0x3fb9f3 = [
        '11JUURqW',
        'NOW',
        '310hHJaEJ',
        'DATE',
        '29544pdtjWU',
        'database',
        'sequelize',
        '1534735mjgGNq',
        '3566616RrsJPN',
        'Device',
        '../config/',
        '131180vjqDyL',
        'devices',
        'offline',
        'exports',
        '540qbSYXN',
        '45JNUryy',
        '3571610JsNdhG',
        'define',
        '14Yiqota',
        '1346bHKuDZ',
        'STRING',
        'New\x20Device',
        'online',
        'ENUM',
        '1593366ptwUpT'
    ];
    _0x2c1e = function () {
        return _0x3fb9f3;
    };
    return _0x2c1e();
}
(function (_0x3c3a90, _0x4f7050) {
    const _0x50542e = _0x7539, _0x2eb728 = _0x3c3a90();
    while (!![]) {
        try {
            const _0xc3200a = parseInt(_0x50542e(0x1b5)) / (-0xad4 + -0xc95 + 0x176a) * (-parseInt(_0x50542e(0x1ad)) / (0x2f9 * 0x1 + -0x1 * 0xff1 + -0xb * -0x12e)) + parseInt(_0x50542e(0x1c3)) / (0x21a * 0x5 + 0x2 * -0xa2b + 0x9d7) * (parseInt(_0x50542e(0x1be)) / (-0xb5b + 0x235f * 0x1 + 0x2 * -0xc00)) + -parseInt(_0x50542e(0x1ba)) / (-0x499 + -0x196a + 0x1e08 * 0x1) + parseInt(_0x50542e(0x1b2)) / (-0x342 + -0x3 * 0x79d + 0x1a1f) * (parseInt(_0x50542e(0x1ac)) / (0x7ed + -0x7f8 + 0x12)) + -parseInt(_0x50542e(0x1b7)) / (-0x4e8 + 0x1a0 * -0x12 + 0x2230) * (parseInt(_0x50542e(0x1c2)) / (0x1f41 + 0x5f * -0x47 + -0x1d * 0x2b)) + parseInt(_0x50542e(0x1c4)) / (-0x2433 * 0x1 + 0x1f76 + 0x4c7 * 0x1) + -parseInt(_0x50542e(0x1b3)) / (0x26f9 + -0x13a3 * 0x1 + 0x1c1 * -0xb) * (parseInt(_0x50542e(0x1bb)) / (0x109e + 0xb * 0x31f + 0x32e7 * -0x1));
            if (_0xc3200a === _0x4f7050)
                break;
            else
                _0x2eb728['push'](_0x2eb728['shift']());
        } catch (_0x2cdbc1) {
            _0x2eb728['push'](_0x2eb728['shift']());
        }
    }
}(_0x2c1e, -0x2 * 0x9f7d + -0xa753e + -0x3 * -0x5a90b));
const {DataTypes} = require(_0x24f994(0x1b9)), sequelize = require(_0x24f994(0x1bd) + _0x24f994(0x1b8)), Device = sequelize[_0x24f994(0x1c5)](_0x24f994(0x1bc), {
        'sn': {
            'type': DataTypes[_0x24f994(0x1ae)],
            'primaryKey': !![],
            'allowNull': ![]
        },
        'name': {
            'type': DataTypes[_0x24f994(0x1ae)],
            'defaultValue': _0x24f994(0x1af)
        },
        'status': {
            'type': DataTypes[_0x24f994(0x1b1)](_0x24f994(0x1b0), _0x24f994(0x1c0)),
            'defaultValue': _0x24f994(0x1c0)
        },
        'last_seen': {
            'type': DataTypes[_0x24f994(0x1b6)],
            'defaultValue': DataTypes[_0x24f994(0x1b4)]
        },
        'ip_address': {
            'type': DataTypes[_0x24f994(0x1ae)],
            'allowNull': !![]
        }
    }, {
        'tableName': _0x24f994(0x1bf),
        'timestamps': !![]
    });
function _0x7539(_0x233419, _0x1bc8a7) {
    _0x233419 = _0x233419 - (-0x1072 + 0x697 + 0xb87);
    const _0x347686 = _0x2c1e();
    let _0x409a48 = _0x347686[_0x233419];
    return _0x409a48;
}
module[_0x24f994(0x1c1)] = Device;