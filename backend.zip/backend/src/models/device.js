const _0x3d8ff9 = _0x3572;
function _0x3572(_0x2eeda0, _0x25cf46) {
    _0x2eeda0 = _0x2eeda0 - (0x1 * -0x1c06 + -0x2108 + -0x23 * -0x1c3);
    const _0x43a8c5 = _0x556b();
    let _0x3ee865 = _0x43a8c5[_0x2eeda0];
    return _0x3ee865;
}
(function (_0x6c76f2, _0x5d5bd9) {
    const _0x1d4fb4 = _0x3572, _0x57f644 = _0x6c76f2();
    while (!![]) {
        try {
            const _0x2632f8 = -parseInt(_0x1d4fb4(0xa2)) / (-0x853 * 0x4 + -0xe2a + 0x1 * 0x2f77) * (parseInt(_0x1d4fb4(0xa4)) / (0x77a + -0x1807 + -0x1b * -0x9d)) + -parseInt(_0x1d4fb4(0xad)) / (-0x11cf + -0x2 * 0x9e9 + 0x25a4) * (parseInt(_0x1d4fb4(0xb1)) / (0x9ff + -0x2 * -0xecd + -0x2795)) + -parseInt(_0x1d4fb4(0xa5)) / (-0x177e + -0x10d3 + 0x2856) + parseInt(_0x1d4fb4(0x9d)) / (-0x281 * 0x1 + 0x333 + -0xac * 0x1) + parseInt(_0x1d4fb4(0xaf)) / (0x1 * 0x1d39 + 0x23b4 + -0x40e6) + -parseInt(_0x1d4fb4(0xb0)) / (-0x1a3d * 0x1 + -0x2a9 * -0x1 + 0x4 * 0x5e7) + parseInt(_0x1d4fb4(0xa6)) / (0x788 + -0x1b3 + -0x5cc);
            if (_0x2632f8 === _0x5d5bd9)
                break;
            else
                _0x57f644['push'](_0x57f644['shift']());
        } catch (_0x4e6ebb) {
            _0x57f644['push'](_0x57f644['shift']());
        }
    }
}(_0x556b, 0x2a5 * 0x2c5 + -0x2f1e7 * 0x7 + 0x17dfe2 * 0x1));
const {DataTypes} = require(_0x3d8ff9(0xa0)), sequelize = require(_0x3d8ff9(0x9b) + _0x3d8ff9(0x9c)), Device = sequelize[_0x3d8ff9(0xa9)](_0x3d8ff9(0x9e), {
        'sn': {
            'type': DataTypes[_0x3d8ff9(0xa3)],
            'primaryKey': !![],
            'allowNull': ![]
        },
        'name': {
            'type': DataTypes[_0x3d8ff9(0xa3)],
            'defaultValue': _0x3d8ff9(0xab)
        },
        'status': {
            'type': DataTypes[_0x3d8ff9(0xac)](_0x3d8ff9(0xae), _0x3d8ff9(0xa8)),
            'defaultValue': _0x3d8ff9(0xa8)
        },
        'last_seen': {
            'type': DataTypes[_0x3d8ff9(0x9f)],
            'defaultValue': DataTypes[_0x3d8ff9(0xaa)]
        },
        'ip_address': {
            'type': DataTypes[_0x3d8ff9(0xa3)],
            'allowNull': !![]
        }
    }, {
        'tableName': _0x3d8ff9(0xa1),
        'timestamps': !![]
    });
module[_0x3d8ff9(0xa7)] = Device;
function _0x556b() {
    const _0x41f9d5 = [
        'ENUM',
        '78gbFtJd',
        'online',
        '7157633MsUqlI',
        '7941856JmZkyz',
        '30392tXXyRJ',
        '../config/',
        'database',
        '4950846YyjVyJ',
        'Device',
        'DATE',
        'sequelize',
        'devices',
        '1964XuqntO',
        'STRING',
        '892JnPHNZ',
        '4802960NRDKza',
        '16855182WcCsHE',
        'exports',
        'offline',
        'define',
        'NOW',
        'New\x20Device'
    ];
    _0x556b = function () {
        return _0x41f9d5;
    };
    return _0x556b();
}