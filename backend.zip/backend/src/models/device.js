const _0x270cce = _0x38d3;
function _0x4b35() {
    const _0xa9c2f8 = [
        '3787648LPaCHJ',
        'define',
        'database',
        'STRING',
        'exports',
        '268705aNfsUH',
        '7951005IjtNGR',
        'New\x20Device',
        '4390884ucJhgS',
        'Device',
        'online',
        'sequelize',
        '1598064ForbdA',
        'DATE',
        'NOW',
        '144001JYDVvy',
        'devices',
        'offline',
        'ENUM',
        '372Clwhpk',
        '../config/',
        '4uTOGsY',
        '54936LYiYLr'
    ];
    _0x4b35 = function () {
        return _0xa9c2f8;
    };
    return _0x4b35();
}
(function (_0x24192e, _0x189360) {
    const _0x5a5771 = _0x38d3, _0x232df7 = _0x24192e();
    while (!![]) {
        try {
            const _0x1013d2 = -parseInt(_0x5a5771(0x1b3)) / (0x255d + -0xf93 + 0x1ad * -0xd) * (-parseInt(_0x5a5771(0x1a2)) / (-0x2f4 * -0x8 + 0x15b8 + -0x2d56)) + parseInt(_0x5a5771(0x1b0)) / (0x63b + 0x2f * 0x1 + 0x1 * -0x667) + -parseInt(_0x5a5771(0x1ac)) / (-0x39 * -0x3b + -0x10fb + -0x4 * -0xf7) + parseInt(_0x5a5771(0x1a9)) / (-0x26b6 + 0x5 * -0x7ac + 0x5 * 0xf6b) + parseInt(_0x5a5771(0x1a0)) / (-0x28 + -0x14cb + 0x14f9) * (-parseInt(_0x5a5771(0x1a3)) / (-0x13c2 + 0x2629 + -0x93 * 0x20)) + parseInt(_0x5a5771(0x1a4)) / (0x3c * 0xa3 + -0x97 * -0x29 + 0x33 * -0x139) + parseInt(_0x5a5771(0x1aa)) / (0xa0b + 0x54 * -0x5b + 0x13da);
            if (_0x1013d2 === _0x189360)
                break;
            else
                _0x232df7['push'](_0x232df7['shift']());
        } catch (_0x176dcf) {
            _0x232df7['push'](_0x232df7['shift']());
        }
    }
}(_0x4b35, -0x1960b * 0x1 + -0x3 * 0x65c6d + -0x241 * -0xd8d));
function _0x38d3(_0x2b696a, _0x5e5ea4) {
    _0x2b696a = _0x2b696a - (0x2 * 0x2e + 0x18b9 + -0x1778);
    const _0x290c2a = _0x4b35();
    let _0x4cf4e3 = _0x290c2a[_0x2b696a];
    return _0x4cf4e3;
}
const {DataTypes} = require(_0x270cce(0x1af)), sequelize = require(_0x270cce(0x1a1) + _0x270cce(0x1a6)), Device = sequelize[_0x270cce(0x1a5)](_0x270cce(0x1ad), {
        'sn': {
            'type': DataTypes[_0x270cce(0x1a7)],
            'primaryKey': !![],
            'allowNull': ![]
        },
        'name': {
            'type': DataTypes[_0x270cce(0x1a7)],
            'defaultValue': _0x270cce(0x1ab)
        },
        'status': {
            'type': DataTypes[_0x270cce(0x19f)](_0x270cce(0x1ae), _0x270cce(0x19e)),
            'defaultValue': _0x270cce(0x19e)
        },
        'last_seen': {
            'type': DataTypes[_0x270cce(0x1b1)],
            'defaultValue': DataTypes[_0x270cce(0x1b2)]
        },
        'ip_address': {
            'type': DataTypes[_0x270cce(0x1a7)],
            'allowNull': !![]
        },
        'list_airline_enable_com': {
            'type': DataTypes[_0x270cce(0x1a7)],
            'allowNull': !![],
            'defaultValue': ''
        }
    }, {
        'tableName': _0x270cce(0x19d),
        'timestamps': !![]
    });
module[_0x270cce(0x1a8)] = Device;