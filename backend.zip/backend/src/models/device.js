const _0x6fa4f0 = _0x5be4;
function _0x4f39() {
    const _0x14b880 = [
        'database',
        '3210xJPPKx',
        '11290152QcxFCz',
        'ENUM',
        '3627335lPdSXO',
        '9588WgAjMu',
        '728bgaCDb',
        'exports',
        'Device',
        '11hGwLXW',
        'online',
        'offline',
        '4536RGLpWo',
        '8918870WbOAzM',
        'New\x20Device',
        '../config/',
        'sequelize',
        'STRING',
        '236UVggiS',
        '48NqFQQn',
        '502128uvjyiL',
        '9266YGbMEn',
        'NOW',
        'devices',
        'DATE',
        'define'
    ];
    _0x4f39 = function () {
        return _0x14b880;
    };
    return _0x4f39();
}
(function (_0x4afdc1, _0x1cd71a) {
    const _0x48244a = _0x5be4, _0x5a3e57 = _0x4afdc1();
    while (!![]) {
        try {
            const _0xd1bf59 = parseInt(_0x48244a(0x1f7)) / (0x101 * -0x10 + -0x414 * 0x7 + 0x2c9d) * (-parseInt(_0x48244a(0x1fa)) / (-0xc8d + -0x1a6d + -0x1f3 * -0x14)) + -parseInt(_0x48244a(0x204)) / (0x9 * -0x40d + -0x1893 + 0x3d0b) * (-parseInt(_0x48244a(0x205)) / (0x2323 * 0x1 + -0x3b * -0x1d + -0x29ce)) + -parseInt(_0x48244a(0x203)) / (0x20c3 + -0xa64 + -0x165a) + parseInt(_0x48244a(0x200)) / (0x248 + 0x255a + -0x14 * 0x1fb) * (parseInt(_0x48244a(0x1f1)) / (0x1d * 0xa + 0x1 * -0x577 + 0x45c)) + parseInt(_0x48244a(0x1f8)) / (0xd3f + 0x1 * -0xb11 + -0x113 * 0x2) * (-parseInt(_0x48244a(0x1f9)) / (-0x2 * -0x7d8 + 0x1bd * 0x10 + -0xe7d * 0x3)) + -parseInt(_0x48244a(0x1f2)) / (-0x89 * -0x1d + -0x13f2 + -0x477 * -0x1) * (-parseInt(_0x48244a(0x208)) / (-0x102 * -0x19 + 0x168 + -0x1a8f)) + parseInt(_0x48244a(0x201)) / (-0x153b + -0x6d * 0x5 + 0x1768);
            if (_0xd1bf59 === _0x1cd71a)
                break;
            else
                _0x5a3e57['push'](_0x5a3e57['shift']());
        } catch (_0x4b2ba2) {
            _0x5a3e57['push'](_0x5a3e57['shift']());
        }
    }
}(_0x4f39, 0x50571 + -0x5 * -0x75db + 0x9f7 * 0x32));
function _0x5be4(_0x400124, _0xc8e93f) {
    _0x400124 = _0x400124 - (0x2141 * -0x1 + -0x1d32 + -0x1019 * -0x4);
    const _0x5700a9 = _0x4f39();
    let _0x35c748 = _0x5700a9[_0x400124];
    return _0x35c748;
}
const {DataTypes} = require(_0x6fa4f0(0x1f5)), sequelize = require(_0x6fa4f0(0x1f4) + _0x6fa4f0(0x1ff)), Device = sequelize[_0x6fa4f0(0x1fe)](_0x6fa4f0(0x207), {
        'sn': {
            'type': DataTypes[_0x6fa4f0(0x1f6)],
            'primaryKey': !![],
            'allowNull': ![]
        },
        'name': {
            'type': DataTypes[_0x6fa4f0(0x1f6)],
            'defaultValue': _0x6fa4f0(0x1f3)
        },
        'status': {
            'type': DataTypes[_0x6fa4f0(0x202)](_0x6fa4f0(0x209), _0x6fa4f0(0x20a)),
            'defaultValue': _0x6fa4f0(0x20a)
        },
        'last_seen': {
            'type': DataTypes[_0x6fa4f0(0x1fd)],
            'defaultValue': DataTypes[_0x6fa4f0(0x1fb)]
        },
        'ip_address': {
            'type': DataTypes[_0x6fa4f0(0x1f6)],
            'allowNull': !![]
        }
    }, {
        'tableName': _0x6fa4f0(0x1fc),
        'timestamps': !![]
    });
module[_0x6fa4f0(0x206)] = Device;