const _0x7a12a4 = _0x4a23;
function _0x4a23(_0x646ea5, _0x19639b) {
    _0x646ea5 = _0x646ea5 - (0xa35 + 0x194 * 0x16 + 0x1 * -0x2baf);
    const _0x4594d6 = _0x2532();
    let _0x11407e = _0x4594d6[_0x646ea5];
    return _0x11407e;
}
(function (_0x4f66eb, _0x214524) {
    const _0x471ab3 = _0x4a23, _0x41e428 = _0x4f66eb();
    while (!![]) {
        try {
            const _0xc4a1ea = parseInt(_0x471ab3(0x14f)) / (0xd7a + 0x3 * 0x6fb + -0x371 * 0xa) * (-parseInt(_0x471ab3(0x154)) / (-0x6a * 0x19 + -0x18e6 + 0x2342)) + -parseInt(_0x471ab3(0x152)) / (0x4 * -0x32e + 0x15c9 + -0x90e) + -parseInt(_0x471ab3(0x151)) / (-0x107c + 0x1079 * -0x1 + 0x1 * 0x20f9) + parseInt(_0x471ab3(0x13f)) / (-0x1bcd * -0x1 + 0x1cd * 0xe + -0x34fe) * (-parseInt(_0x471ab3(0x143)) / (0x44 * -0x29 + -0x399 * -0x1 + 0x751)) + -parseInt(_0x471ab3(0x148)) / (-0x1212 + 0x16 * 0x1ba + -0x13e3) + -parseInt(_0x471ab3(0x14a)) / (0x2b * 0x8 + -0x3e * 0x8b + 0x205a) * (parseInt(_0x471ab3(0x147)) / (-0x1468 * -0x1 + -0x949 + -0xb16)) + parseInt(_0x471ab3(0x149)) / (-0x1e7f + 0xc59 + 0x918 * 0x2);
            if (_0xc4a1ea === _0x214524)
                break;
            else
                _0x41e428['push'](_0x41e428['shift']());
        } catch (_0x487363) {
            _0x41e428['push'](_0x41e428['shift']());
        }
    }
}(_0x2532, 0x2b * -0x351 + 0x7c748 + 0x1 * -0x3365d));
function _0x2532() {
    const _0x357e41 = [
        '../config/',
        'active',
        '4259520AwEtJV',
        '1739066dKHadm',
        '22302190voEFrO',
        '8jEMEiT',
        'License',
        'sequelize',
        'TEXT',
        'exports',
        '176489EnnpsH',
        'UUIDV4',
        '1225720ynDCHB',
        '793977Klxyys',
        'DATE',
        '4vQwDOy',
        'database',
        '10YJCZQQ',
        'licenses',
        'UUID',
        'define',
        '965094uxHXti',
        'STRING'
    ];
    _0x2532 = function () {
        return _0x357e41;
    };
    return _0x2532();
}
const {DataTypes} = require(_0x7a12a4(0x14c)), sequelize = require(_0x7a12a4(0x145) + _0x7a12a4(0x13e)), License = sequelize[_0x7a12a4(0x142)](_0x7a12a4(0x14b), {
        'id': {
            'type': DataTypes[_0x7a12a4(0x141)],
            'defaultValue': DataTypes[_0x7a12a4(0x150)],
            'primaryKey': !![]
        },
        'licenseKey': {
            'type': DataTypes[_0x7a12a4(0x14d)],
            'allowNull': ![]
        },
        'status': {
            'type': DataTypes[_0x7a12a4(0x144)],
            'defaultValue': _0x7a12a4(0x146)
        },
        'expiresAt': {
            'type': DataTypes[_0x7a12a4(0x153)],
            'allowNull': ![]
        }
    }, {
        'tableName': _0x7a12a4(0x140),
        'timestamps': !![]
    });
module[_0x7a12a4(0x14e)] = License;