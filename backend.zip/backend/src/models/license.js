const _0x192c21 = _0x4e57;
(function (_0x44fcc1, _0x312c6b) {
    const _0x19b92f = _0x4e57, _0x409bc5 = _0x44fcc1();
    while (!![]) {
        try {
            const _0x39fb04 = -parseInt(_0x19b92f(0x1e9)) / (0x2360 + 0xb * 0x11b + -0x2f88) + -parseInt(_0x19b92f(0x1e8)) / (-0x4f + 0x221f + -0x21ce) + parseInt(_0x19b92f(0x1dc)) / (0x7 * -0x229 + -0x17cc + 0x97 * 0x42) * (-parseInt(_0x19b92f(0x1d5)) / (0x13 * -0xcc + -0xe68 + -0x4 * -0x764)) + parseInt(_0x19b92f(0x1d8)) / (0x11b5 * 0x2 + -0x1ead + 0x4b8 * -0x1) * (parseInt(_0x19b92f(0x1ea)) / (-0x11b7 + -0x99b * 0x1 + 0x23 * 0xc8)) + -parseInt(_0x19b92f(0x1d6)) / (-0x1030 + -0x13e3 + -0x1 * -0x241a) * (-parseInt(_0x19b92f(0x1de)) / (0x245c + 0x2 * -0x173 + -0x216e)) + parseInt(_0x19b92f(0x1db)) / (-0x161e + -0xe7d + -0x29e * -0xe) * (parseInt(_0x19b92f(0x1e0)) / (0x2 * -0x72a + -0x21fa + 0x2 * 0x182c)) + parseInt(_0x19b92f(0x1e3)) / (0x26bc + -0xf7d + 0x4a4 * -0x5);
            if (_0x39fb04 === _0x312c6b)
                break;
            else
                _0x409bc5['push'](_0x409bc5['shift']());
        } catch (_0x4648dc) {
            _0x409bc5['push'](_0x409bc5['shift']());
        }
    }
}(_0x3602, 0x634a * -0xc + 0x3 * 0xf90b + 0x258c5 * 0x4));
const {DataTypes} = require(_0x192c21(0x1dd)), sequelize = require(_0x192c21(0x1e5) + _0x192c21(0x1df)), License = sequelize[_0x192c21(0x1e7)](_0x192c21(0x1d3), {
        'id': {
            'type': DataTypes[_0x192c21(0x1e4)],
            'defaultValue': DataTypes[_0x192c21(0x1e2)],
            'primaryKey': !![]
        },
        'licenseKey': {
            'type': DataTypes[_0x192c21(0x1d4)],
            'allowNull': ![]
        },
        'status': {
            'type': DataTypes[_0x192c21(0x1d9)],
            'defaultValue': _0x192c21(0x1e1)
        },
        'expiresAt': {
            'type': DataTypes[_0x192c21(0x1da)],
            'allowNull': ![]
        }
    }, {
        'tableName': _0x192c21(0x1d7),
        'timestamps': !![]
    });
function _0x4e57(_0x5d33aa, _0x4dffd0) {
    _0x5d33aa = _0x5d33aa - (0x337 * 0x4 + 0x296 * -0xe + 0x192b);
    const _0x349085 = _0x3602();
    let _0x2a8b07 = _0x349085[_0x5d33aa];
    return _0x2a8b07;
}
module[_0x192c21(0x1e6)] = License;
function _0x3602() {
    const _0x4c4d55 = [
        '15jzjzCz',
        'STRING',
        'DATE',
        '20484QXKNJG',
        '1093983jMcNxN',
        'sequelize',
        '43424ONbtzs',
        'database',
        '2880NaxKgG',
        'active',
        'UUIDV4',
        '1240899tmiVBj',
        'UUID',
        '../config/',
        'exports',
        'define',
        '854286qXBsXi',
        '924562WVlZrO',
        '1639716CzgYOX',
        'License',
        'TEXT',
        '4pnkhcT',
        '812nborFn',
        'licenses'
    ];
    _0x3602 = function () {
        return _0x4c4d55;
    };
    return _0x3602();
}