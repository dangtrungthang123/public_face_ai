const _0x3973ce = _0x123a;
(function (_0x45064d, _0x507610) {
    const _0x741d8f = _0x123a, _0x29ca7f = _0x45064d();
    while (!![]) {
        try {
            const _0x4e6960 = -parseInt(_0x741d8f(0x14e)) / (0x38 * -0x39 + -0x1d13 + 0x298c) * (parseInt(_0x741d8f(0x163)) / (-0x1 * -0x59 + -0xb * 0x19f + -0x8bf * -0x2)) + parseInt(_0x741d8f(0x157)) / (-0x1a9a + 0x1 * 0x653 + 0x144a) + parseInt(_0x741d8f(0x15d)) / (-0x2 * -0x35d + 0x4d2 + -0xb88) * (-parseInt(_0x741d8f(0x15e)) / (0xc15 + -0x1eda + -0x965 * -0x2)) + -parseInt(_0x741d8f(0x150)) / (0x6 * 0x53a + -0x31c + -0x1 * 0x1c3a) * (parseInt(_0x741d8f(0x152)) / (-0x1051 + -0x2 * -0x458 + -0x62 * -0x14)) + parseInt(_0x741d8f(0x151)) / (-0x1 * -0x16ac + -0x35 * 0xa + -0x1492) + parseInt(_0x741d8f(0x14d)) / (0x11f3 + 0x8ed + -0x1ad7 * 0x1) + parseInt(_0x741d8f(0x153)) / (-0x719 + 0x129 * -0x6 + 0xe19);
            if (_0x4e6960 === _0x507610)
                break;
            else
                _0x29ca7f['push'](_0x29ca7f['shift']());
        } catch (_0x213945) {
            _0x29ca7f['push'](_0x29ca7f['shift']());
        }
    }
}(_0x1940, -0x39a * -0x431 + -0xee7aa + 0x9d0ac));
const {DataTypes} = require(_0x3973ce(0x155)), sequelize = require(_0x3973ce(0x156) + _0x3973ce(0x162)), License = sequelize[_0x3973ce(0x160)](_0x3973ce(0x158), {
        'id': {
            'type': DataTypes[_0x3973ce(0x161)],
            'defaultValue': DataTypes[_0x3973ce(0x154)],
            'primaryKey': !![]
        },
        'licenseKey': {
            'type': DataTypes[_0x3973ce(0x15a)],
            'allowNull': ![]
        },
        'status': {
            'type': DataTypes[_0x3973ce(0x15f)],
            'defaultValue': _0x3973ce(0x15c)
        },
        'expiresAt': {
            'type': DataTypes[_0x3973ce(0x14f)],
            'allowNull': ![]
        }
    }, {
        'tableName': _0x3973ce(0x159),
        'timestamps': !![]
    });
function _0x1940() {
    const _0x58f835 = [
        '2980521akLVKL',
        '1ZkAkLT',
        'DATE',
        '493548MgRiYt',
        '3233968jGOJcm',
        '63GnChlz',
        '13737430eSTciH',
        'UUIDV4',
        'sequelize',
        '../config/',
        '2274195vjRxMd',
        'License',
        'licenses',
        'TEXT',
        'exports',
        'active',
        '1515912aiBczn',
        '15LnpGZx',
        'STRING',
        'define',
        'UUID',
        'database',
        '668454wWwugq'
    ];
    _0x1940 = function () {
        return _0x58f835;
    };
    return _0x1940();
}
function _0x123a(_0x40cafa, _0x414996) {
    _0x40cafa = _0x40cafa - (-0x1b2d + -0x1dc9 + -0x5f * -0x9d);
    const _0x361eeb = _0x1940();
    let _0x193908 = _0x361eeb[_0x40cafa];
    return _0x193908;
}
module[_0x3973ce(0x15b)] = License;