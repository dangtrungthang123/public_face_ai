const _0x19388d = _0x3732;
function _0x3732(_0x4b3602, _0x41fa72) {
    _0x4b3602 = _0x4b3602 - (-0x1c03 + 0xdf * -0x9 + 0x1 * 0x2456);
    const _0x59dd93 = _0xaef4();
    let _0x9fce9f = _0x59dd93[_0x4b3602];
    return _0x9fce9f;
}
function _0xaef4() {
    const _0x68388e = [
        'sequelize',
        '../config/',
        '917895IWSERW',
        '4165434SPePop',
        'licenses',
        '98096zqYDZs',
        'DATE',
        '1037604TfDAtx',
        'database',
        '1984632VuTWHM',
        '32uzblys',
        '235522CbERDR',
        'define',
        'UUIDV4',
        'TEXT',
        'STRING',
        '2267tcZisQ',
        'exports',
        'UUID',
        '52LQsruc',
        'License',
        'active'
    ];
    _0xaef4 = function () {
        return _0x68388e;
    };
    return _0xaef4();
}
(function (_0x54ec79, _0x55536d) {
    const _0x5304ba = _0x3732, _0x3da863 = _0x54ec79();
    while (!![]) {
        try {
            const _0x43bd2d = -parseInt(_0x5304ba(0x86)) / (0x1650 + -0x3 * 0x869 + 0x2ec) * (-parseInt(_0x5304ba(0x89)) / (-0x1 * -0x7b3 + 0x155 + -0x906)) + parseInt(_0x5304ba(0x7d)) / (-0x1bab + -0x6c * -0x3e + 0x3 * 0x82) + -parseInt(_0x5304ba(0x91)) / (-0x7 * -0x309 + -0x1b15 + -0x2ed * -0x2) + -parseInt(_0x5304ba(0x8e)) / (-0x2 * 0x175 + 0x3b * 0x7c + -0x65 * 0x41) + -parseInt(_0x5304ba(0x7f)) / (-0x128f + 0x8c + -0x201 * -0x9) + parseInt(_0x5304ba(0x81)) / (-0x11 * 0x177 + 0x16de + 0x16 * 0x18) * (-parseInt(_0x5304ba(0x80)) / (-0x146f + 0xa3 * 0x10 + 0xa47)) + parseInt(_0x5304ba(0x8f)) / (0x59 * -0x53 + -0x9ac * -0x1 + 0x1338);
            if (_0x43bd2d === _0x55536d)
                break;
            else
                _0x3da863['push'](_0x3da863['shift']());
        } catch (_0x3554d0) {
            _0x3da863['push'](_0x3da863['shift']());
        }
    }
}(_0xaef4, -0x2173d + 0x41c5d + -0x1 * -0xf161));
const {DataTypes} = require(_0x19388d(0x8c)), sequelize = require(_0x19388d(0x8d) + _0x19388d(0x7e)), License = sequelize[_0x19388d(0x82)](_0x19388d(0x8a), {
        'id': {
            'type': DataTypes[_0x19388d(0x88)],
            'defaultValue': DataTypes[_0x19388d(0x83)],
            'primaryKey': !![]
        },
        'licenseKey': {
            'type': DataTypes[_0x19388d(0x84)],
            'allowNull': ![]
        },
        'status': {
            'type': DataTypes[_0x19388d(0x85)],
            'defaultValue': _0x19388d(0x8b)
        },
        'expiresAt': {
            'type': DataTypes[_0x19388d(0x7c)],
            'allowNull': ![]
        }
    }, {
        'tableName': _0x19388d(0x90),
        'timestamps': !![]
    });
module[_0x19388d(0x87)] = License;