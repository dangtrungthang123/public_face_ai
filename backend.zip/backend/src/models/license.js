const _0x3a5ac6 = _0x2cf1;
(function (_0x32f2bd, _0x38099f) {
    const _0x4cc30f = _0x2cf1, _0xd99ce5 = _0x32f2bd();
    while (!![]) {
        try {
            const _0x4bbcce = -parseInt(_0x4cc30f(0x1a5)) / (-0x9b3 + 0xbc9 * -0x2 + -0x1 * -0x2146) + parseInt(_0x4cc30f(0x1a3)) / (-0x1baa + -0x3 * -0x4ae + -0x5 * -0x2ba) * (parseInt(_0x4cc30f(0x1a6)) / (0x1533 + 0x2e * -0x65 + -0x185 * 0x2)) + parseInt(_0x4cc30f(0x1ae)) / (0x167d + -0x1238 + -0x1 * 0x441) + parseInt(_0x4cc30f(0x1a4)) / (-0x23ad + -0x1260 + 0x3612) + -parseInt(_0x4cc30f(0x1aa)) / (-0x10a5 + -0x1075 + -0x8 * -0x424) * (parseInt(_0x4cc30f(0x19e)) / (0x1 * -0x24f5 + 0x208d + 0x1 * 0x46f)) + -parseInt(_0x4cc30f(0x1a1)) / (-0x1379 * 0x1 + 0x1 * 0xe66 + -0x51b * -0x1) * (parseInt(_0x4cc30f(0x19f)) / (0x24 + 0x9e3 * -0x1 + 0x9c8)) + parseInt(_0x4cc30f(0x1ab)) / (-0x11bc + -0x1551 + 0x2717);
            if (_0x4bbcce === _0x38099f)
                break;
            else
                _0xd99ce5['push'](_0xd99ce5['shift']());
        } catch (_0x182e73) {
            _0xd99ce5['push'](_0xd99ce5['shift']());
        }
    }
}(_0x7fd1, -0x362ef * 0x1 + 0x38ff8 + 0x6d29d));
function _0x2cf1(_0x4b093e, _0x159731) {
    _0x4b093e = _0x4b093e - (0x2217 + -0xec7 + -0x11b6);
    const _0x164b1b = _0x7fd1();
    let _0x2fcc71 = _0x164b1b[_0x4b093e];
    return _0x2fcc71;
}
const {DataTypes} = require(_0x3a5ac6(0x19b)), sequelize = require(_0x3a5ac6(0x1a2) + _0x3a5ac6(0x1b0)), License = sequelize[_0x3a5ac6(0x1a0)](_0x3a5ac6(0x19d), {
        'id': {
            'type': DataTypes[_0x3a5ac6(0x1ad)],
            'defaultValue': DataTypes[_0x3a5ac6(0x19c)],
            'primaryKey': !![]
        },
        'licenseKey': {
            'type': DataTypes[_0x3a5ac6(0x19a)],
            'allowNull': ![]
        },
        'status': {
            'type': DataTypes[_0x3a5ac6(0x1a8)],
            'defaultValue': _0x3a5ac6(0x1af)
        },
        'expiresAt': {
            'type': DataTypes[_0x3a5ac6(0x1a7)],
            'allowNull': ![]
        }
    }, {
        'tableName': _0x3a5ac6(0x1ac),
        'timestamps': !![]
    });
function _0x7fd1() {
    const _0x177849 = [
        '18sdyUXO',
        'DATE',
        'STRING',
        'exports',
        '93516fXaKrd',
        '13286620dkExuk',
        'licenses',
        'UUID',
        '1284512lnFUrd',
        'active',
        'database',
        'TEXT',
        'sequelize',
        'UUIDV4',
        'License',
        '182ikEteC',
        '443655hHmkeE',
        'define',
        '56mAuzzO',
        '../config/',
        '19446EojNPa',
        '970905DFDwXu',
        '693346EreQec'
    ];
    _0x7fd1 = function () {
        return _0x177849;
    };
    return _0x7fd1();
}
module[_0x3a5ac6(0x1a9)] = License;