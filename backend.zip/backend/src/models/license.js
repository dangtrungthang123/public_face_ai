function _0x5bcb(_0x529575, _0x3c93e4) {
    _0x529575 = _0x529575 - (0x80c * -0x2 + 0x6c5 * 0x1 + 0xa84);
    const _0x5a9a98 = _0x36da();
    let _0x5beaa8 = _0x5a9a98[_0x529575];
    return _0x5beaa8;
}
function _0x36da() {
    const _0x564fa7 = [
        '139987ncOJAp',
        'UUIDV4',
        'STRING',
        'sequelize',
        'DATE',
        '47254888dCOIpZ',
        'TEXT',
        'licenses',
        'database',
        'active',
        '../config/',
        '10959840LpAByv',
        'exports',
        'License',
        '12040525NxnDrY',
        'UUID',
        'define',
        '5679384DVZXqT',
        '1723830fqLwff',
        '2037235iPHybz',
        '12gqDiay'
    ];
    _0x36da = function () {
        return _0x564fa7;
    };
    return _0x36da();
}
const _0x17be79 = _0x5bcb;
(function (_0x34419f, _0x2ea010) {
    const _0x208cd8 = _0x5bcb, _0x3ba1a1 = _0x34419f();
    while (!![]) {
        try {
            const _0x2e34b2 = parseInt(_0x208cd8(0x13e)) / (0x22e2 + -0x2652 + -0x1 * -0x371) + -parseInt(_0x208cd8(0x13b)) / (-0x1 * -0x1d3b + 0x718 + 0x2451 * -0x1) + -parseInt(_0x208cd8(0x13a)) / (0x1f0f + 0xebd + 0x1 * -0x2dc9) + parseInt(_0x208cd8(0x13d)) / (0x29 * 0x95 + -0x223a + 0xa61 * 0x1) * (parseInt(_0x208cd8(0x13c)) / (0x235d + 0x283 + 0x371 * -0xb)) + -parseInt(_0x208cd8(0x134)) / (0x1 * 0xc9a + -0xdba * -0x1 + -0x1a4e) + -parseInt(_0x208cd8(0x137)) / (0x727 + 0x37 * -0x7 + 0x59f * -0x1) + parseInt(_0x208cd8(0x143)) / (-0x1717 + -0x4a3 + 0xd1 * 0x22);
            if (_0x2e34b2 === _0x2ea010)
                break;
            else
                _0x3ba1a1['push'](_0x3ba1a1['shift']());
        } catch (_0x7c7bc7) {
            _0x3ba1a1['push'](_0x3ba1a1['shift']());
        }
    }
}(_0x36da, 0x216ff + -0x132464 + 0x1fd06c));
const {DataTypes} = require(_0x17be79(0x141)), sequelize = require(_0x17be79(0x133) + _0x17be79(0x131)), License = sequelize[_0x17be79(0x139)](_0x17be79(0x136), {
        'id': {
            'type': DataTypes[_0x17be79(0x138)],
            'defaultValue': DataTypes[_0x17be79(0x13f)],
            'primaryKey': !![]
        },
        'licenseKey': {
            'type': DataTypes[_0x17be79(0x144)],
            'allowNull': ![]
        },
        'status': {
            'type': DataTypes[_0x17be79(0x140)],
            'defaultValue': _0x17be79(0x132)
        },
        'expiresAt': {
            'type': DataTypes[_0x17be79(0x142)],
            'allowNull': ![]
        }
    }, {
        'tableName': _0x17be79(0x145),
        'timestamps': !![]
    });
module[_0x17be79(0x135)] = License;