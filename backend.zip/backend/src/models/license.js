const _0x4a254e = _0x56e5;
(function (_0x56b066, _0x14f6e1) {
    const _0x22a10e = _0x56e5, _0x5447ff = _0x56b066();
    while (!![]) {
        try {
            const _0x26dc21 = -parseInt(_0x22a10e(0x67)) / (-0x15 * 0xab + 0x1 * -0x97 + -0xe9f * -0x1) + parseInt(_0x22a10e(0x6b)) / (0x1 * 0x14ac + -0xb64 + -0x1 * 0x946) + parseInt(_0x22a10e(0x73)) / (-0x23fd + -0x1 * 0xdfd + -0xbf * -0x43) + parseInt(_0x22a10e(0x72)) / (0x1 * -0x1708 + -0x20b8 + -0x4 * -0xdf1) + -parseInt(_0x22a10e(0x66)) / (0x1835 * -0x1 + -0x5 * -0x10b + 0x1303) + parseInt(_0x22a10e(0x6e)) / (-0x31 * 0x2c + 0x1 * -0x2443 + 0x2fb * 0xf) + parseInt(_0x22a10e(0x78)) / (-0x16 * 0x136 + 0xaf7 + 0xfb4) * (parseInt(_0x22a10e(0x75)) / (0x1ed3 * -0x1 + 0x1 * -0x4f + 0x1f2a));
            if (_0x26dc21 === _0x14f6e1)
                break;
            else
                _0x5447ff['push'](_0x5447ff['shift']());
        } catch (_0x4ecc8d) {
            _0x5447ff['push'](_0x5447ff['shift']());
        }
    }
}(_0x39da, 0x38d19 + -0x1d7d * 0x67 + 0x1182de));
const {DataTypes} = require(_0x4a254e(0x6f)), sequelize = require(_0x4a254e(0x77) + _0x4a254e(0x74)), License = sequelize[_0x4a254e(0x70)](_0x4a254e(0x79), {
        'id': {
            'type': DataTypes[_0x4a254e(0x6d)],
            'defaultValue': DataTypes[_0x4a254e(0x65)],
            'primaryKey': !![]
        },
        'licenseKey': {
            'type': DataTypes[_0x4a254e(0x69)],
            'allowNull': ![]
        },
        'status': {
            'type': DataTypes[_0x4a254e(0x68)],
            'defaultValue': _0x4a254e(0x71)
        },
        'expiresAt': {
            'type': DataTypes[_0x4a254e(0x6c)],
            'allowNull': ![]
        }
    }, {
        'tableName': _0x4a254e(0x76),
        'timestamps': !![]
    });
function _0x56e5(_0x569581, _0x5e6c02) {
    _0x569581 = _0x569581 - (0x1215 * -0x2 + -0x71a + 0x2ba9);
    const _0x59bae3 = _0x39da();
    let _0x5991f9 = _0x59bae3[_0x569581];
    return _0x5991f9;
}
module[_0x4a254e(0x6a)] = License;
function _0x39da() {
    const _0x281984 = [
        'DATE',
        'UUID',
        '2473902INOHhp',
        'sequelize',
        'define',
        'active',
        '2093552rebmyA',
        '934659cRFWTV',
        'database',
        '8ajyREA',
        'licenses',
        '../config/',
        '3413949PjBcJz',
        'License',
        'UUIDV4',
        '1221500AftFJt',
        '956388EMkQsy',
        'STRING',
        'TEXT',
        'exports',
        '137038tUuwXG'
    ];
    _0x39da = function () {
        return _0x281984;
    };
    return _0x39da();
}