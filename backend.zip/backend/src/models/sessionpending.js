const _0x1cbb62 = _0x4394;
(function (_0x57efe0, _0x4c8a0c) {
    const _0x3bba54 = _0x4394, _0x59f0a4 = _0x57efe0();
    while (!![]) {
        try {
            const _0xed9b5d = parseInt(_0x3bba54(0x1c0)) / (0x1e55 + 0x12f3 + -0x3147) * (-parseInt(_0x3bba54(0x1bb)) / (0x2616 + 0x9e5 * -0x1 + -0x965 * 0x3)) + parseInt(_0x3bba54(0x1b4)) / (-0x1223 * -0x1 + 0x35c + -0x157c) * (parseInt(_0x3bba54(0x1bc)) / (-0x8da + 0x1c7d + -0x139f)) + -parseInt(_0x3bba54(0x1ad)) / (0x8a3 + 0x208d + 0x3 * -0xdb9) + -parseInt(_0x3bba54(0x1c4)) / (-0x65 * -0x2b + -0x4 * 0x5cc + 0x1 * 0x63f) + parseInt(_0x3bba54(0x1b0)) / (-0x1b82 + -0x34c + 0x1ed5) + parseInt(_0x3bba54(0x1b6)) / (0xfd7 + -0x1 * -0x1235 + 0x4 * -0x881) * (-parseInt(_0x3bba54(0x1b5)) / (0x13ae + 0x1 * -0x1d23 + 0x97e)) + -parseInt(_0x3bba54(0x1c5)) / (-0x27 + -0xca + 0xfb) * (-parseInt(_0x3bba54(0x1ba)) / (0x13 * -0xd3 + 0x12f1 + -0x33d));
            if (_0xed9b5d === _0x4c8a0c)
                break;
            else
                _0x59f0a4['push'](_0x59f0a4['shift']());
        } catch (_0x2915c2) {
            _0x59f0a4['push'](_0x59f0a4['shift']());
        }
    }
}(_0x4968, 0x46250 + -0x3af34 + 0x23b2e));
function _0x4968() {
    const _0x584ce3 = [
        '../config/',
        'ding',
        '316810EswmyC',
        'UUIDV4',
        'DATE',
        '1630811TuVpbm',
        'UUID',
        'STRING',
        'NOW',
        '1227fATBDs',
        '418599DzpNzu',
        '40xbDZXv',
        'database',
        'sequelize',
        '0\x20=\x20pendin',
        '1562sUfNjP',
        '114902SUpKrT',
        '300UuYEHy',
        'g,\x201\x20=\x20pro',
        'define',
        'INTEGER',
        '3xwbMDx',
        'exports',
        'SessionPen',
        'dings',
        '1049976HLgANB',
        '40260FsdMud',
        'cessed'
    ];
    _0x4968 = function () {
        return _0x584ce3;
    };
    return _0x4968();
}
function _0x4394(_0xccd18b, _0x4e4107) {
    _0xccd18b = _0xccd18b - (0x16 * -0x95 + 0xb2c + -0x5 * -0xa9);
    const _0x5c8cf8 = _0x4968();
    let _0x9c3deb = _0x5c8cf8[_0xccd18b];
    return _0x9c3deb;
}
const {DataTypes} = require(_0x1cbb62(0x1b8)), sequelize = require(_0x1cbb62(0x1ab) + _0x1cbb62(0x1b7)), SessionPending = sequelize[_0x1cbb62(0x1be)](_0x1cbb62(0x1c2) + _0x1cbb62(0x1ac), {
        'id': {
            'type': DataTypes[_0x1cbb62(0x1b1)],
            'defaultValue': DataTypes[_0x1cbb62(0x1ae)],
            'primaryKey': !![]
        },
        'sn': {
            'type': DataTypes[_0x1cbb62(0x1b2)],
            'allowNull': !![]
        },
        'sessionId': {
            'type': DataTypes[_0x1cbb62(0x1b2)],
            'allowNull': ![]
        },
        'boardingPass': {
            'type': DataTypes[_0x1cbb62(0x1b2)],
            'allowNull': !![],
            'defaultValue': null
        },
        'dateCreated': {
            'type': DataTypes[_0x1cbb62(0x1af)],
            'defaultValue': DataTypes[_0x1cbb62(0x1b3)]
        },
        'status': {
            'type': DataTypes[_0x1cbb62(0x1bf)],
            'defaultValue': 0x0,
            'comment': _0x1cbb62(0x1b9) + _0x1cbb62(0x1bd) + _0x1cbb62(0x1c6)
        }
    }, {
        'tableName': _0x1cbb62(0x1c2) + _0x1cbb62(0x1c3),
        'timestamps': !![]
    });
module[_0x1cbb62(0x1c1)] = SessionPending;