function _0x802a() {
    const _0x4a1c31 = [
        'database',
        'INTEGER',
        'g,\x201\x20=\x20pro',
        'NOW',
        'UUID',
        '179424VCeWPZ',
        'cessed',
        'SessionPen',
        '2789889ssbzMs',
        '4nDnFwI',
        'DATE',
        '2724mlvInG',
        'sequelize',
        '102935zfLvQh',
        'define',
        'ding',
        '5048379KFUPyl',
        'UUIDV4',
        'STRING',
        '9303480iQumqa',
        '0\x20=\x20pendin',
        '558lJFwEl',
        '326234UIdpoY',
        'exports',
        '../config/',
        '15595jsWodO',
        'dings'
    ];
    _0x802a = function () {
        return _0x4a1c31;
    };
    return _0x802a();
}
function _0x4cae(_0x2a7441, _0x4f50a3) {
    _0x2a7441 = _0x2a7441 - (-0xbcc + 0xd7 * -0xd + 0x181a);
    const _0x23e70c = _0x802a();
    let _0x1a9a2d = _0x23e70c[_0x2a7441];
    return _0x1a9a2d;
}
const _0x22584c = _0x4cae;
(function (_0x51810a, _0x4e95e3) {
    const _0x242779 = _0x4cae, _0x423f0c = _0x51810a();
    while (!![]) {
        try {
            const _0x5abe38 = -parseInt(_0x242779(0x170)) / (0x2126 + -0x20f * -0x1 + -0x2334) + parseInt(_0x242779(0x179)) / (-0x8 * -0x417 + 0x7 * 0x3c7 + 0x3b27 * -0x1) + parseInt(_0x242779(0x16b)) / (0x21dd * -0x1 + 0x2045 + -0x19b * -0x1) * (parseInt(_0x242779(0x16c)) / (-0x1 * 0x1459 + -0x557 * 0x1 + -0x3ac * -0x7)) + parseInt(_0x242779(0x17c)) / (0x960 + 0x4 * -0xb5 + 0x1 * -0x687) * (-parseInt(_0x242779(0x16e)) / (-0xf3a * 0x1 + -0x15d + 0x109d)) + parseInt(_0x242779(0x173)) / (0x2f2 + -0x1c59 + 0x196e) + parseInt(_0x242779(0x168)) / (0x1296 + -0xbfa * -0x3 + -0x367c) * (parseInt(_0x242779(0x178)) / (-0xd90 + -0x11 * -0x1df + -0x15 * 0xde)) + -parseInt(_0x242779(0x176)) / (0x693 + -0x1ba5 + 0x151c);
            if (_0x5abe38 === _0x4e95e3)
                break;
            else
                _0x423f0c['push'](_0x423f0c['shift']());
        } catch (_0x5ae42b) {
            _0x423f0c['push'](_0x423f0c['shift']());
        }
    }
}(_0x802a, -0x237e2 + 0x84dd4 + -0x6 * -0xe835));
const {DataTypes} = require(_0x22584c(0x16f)), sequelize = require(_0x22584c(0x17b) + _0x22584c(0x163)), SessionPending = sequelize[_0x22584c(0x171)](_0x22584c(0x16a) + _0x22584c(0x172), {
        'id': {
            'type': DataTypes[_0x22584c(0x167)],
            'defaultValue': DataTypes[_0x22584c(0x174)],
            'primaryKey': !![]
        },
        'sn': {
            'type': DataTypes[_0x22584c(0x175)],
            'allowNull': !![]
        },
        'sessionId': {
            'type': DataTypes[_0x22584c(0x175)],
            'allowNull': ![]
        },
        'dateCreated': {
            'type': DataTypes[_0x22584c(0x16d)],
            'defaultValue': DataTypes[_0x22584c(0x166)]
        },
        'status': {
            'type': DataTypes[_0x22584c(0x164)],
            'defaultValue': 0x0,
            'comment': _0x22584c(0x177) + _0x22584c(0x165) + _0x22584c(0x169)
        }
    }, {
        'tableName': _0x22584c(0x16a) + _0x22584c(0x17d),
        'timestamps': !![]
    });
module[_0x22584c(0x17a)] = SessionPending;