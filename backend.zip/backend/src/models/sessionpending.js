const _0x2789a8 = _0xb1f3;
(function (_0x9df1ab, _0x33136c) {
    const _0x52e369 = _0xb1f3, _0x13b3e4 = _0x9df1ab();
    while (!![]) {
        try {
            const _0x5b47d8 = parseInt(_0x52e369(0x192)) / (-0x5a2 + -0x1 * 0x7c3 + 0xd66) + parseInt(_0x52e369(0x190)) / (-0x1ebe + 0x229d + -0x3dd * 0x1) + -parseInt(_0x52e369(0x19a)) / (0x1bf7 * 0x1 + 0x1 * 0x26f + -0x1e63 * 0x1) * (-parseInt(_0x52e369(0x187)) / (-0x1 * -0x1343 + -0x2c * 0xd6 + 0x1189)) + parseInt(_0x52e369(0x19f)) / (-0x85f * -0x1 + -0x3 * -0x127 + 0xbcf * -0x1) + -parseInt(_0x52e369(0x19b)) / (0x2543 + 0xea9 + 0x19f3 * -0x2) + -parseInt(_0x52e369(0x193)) / (0x6 * -0x5e5 + 0x20b9 + 0x2ac) + parseInt(_0x52e369(0x199)) / (0x4ed + -0x1e0c + 0x1927) * (-parseInt(_0x52e369(0x19c)) / (0x137 * -0xf + -0x252b + 0x376d));
            if (_0x5b47d8 === _0x33136c)
                break;
            else
                _0x13b3e4['push'](_0x13b3e4['shift']());
        } catch (_0x1c5ffe) {
            _0x13b3e4['push'](_0x13b3e4['shift']());
        }
    }
}(_0x4825, 0x509 * 0x18d + -0xba863 + 0xa33a2 * 0x1));
function _0x4825() {
    const _0x528372 = [
        '81EmigeR',
        'SessionPen',
        'UUID',
        '3890665rxPVUk',
        'STRING',
        '44EvpWhg',
        '../config/',
        'dings',
        'INTEGER',
        'define',
        'ding',
        'UUIDV4',
        'g,\x201\x20=\x20pro',
        'database',
        '675104VRtwFn',
        'NOW',
        '122128xwloNz',
        '5509581LLtjvd',
        'cessed',
        'DATE',
        'sequelize',
        'exports',
        '0\x20=\x20pendin',
        '125784MFgKjI',
        '71364ErCsoI',
        '927498EfPFIO'
    ];
    _0x4825 = function () {
        return _0x528372;
    };
    return _0x4825();
}
const {DataTypes} = require(_0x2789a8(0x196)), sequelize = require(_0x2789a8(0x188) + _0x2789a8(0x18f)), SessionPending = sequelize[_0x2789a8(0x18b)](_0x2789a8(0x19d) + _0x2789a8(0x18c), {
        'id': {
            'type': DataTypes[_0x2789a8(0x19e)],
            'defaultValue': DataTypes[_0x2789a8(0x18d)],
            'primaryKey': !![]
        },
        'sn': {
            'type': DataTypes[_0x2789a8(0x1a0)],
            'allowNull': !![]
        },
        'sessionId': {
            'type': DataTypes[_0x2789a8(0x1a0)],
            'allowNull': ![]
        },
        'dateCreated': {
            'type': DataTypes[_0x2789a8(0x195)],
            'defaultValue': DataTypes[_0x2789a8(0x191)]
        },
        'status': {
            'type': DataTypes[_0x2789a8(0x18a)],
            'defaultValue': 0x0,
            'comment': _0x2789a8(0x198) + _0x2789a8(0x18e) + _0x2789a8(0x194)
        }
    }, {
        'tableName': _0x2789a8(0x19d) + _0x2789a8(0x189),
        'timestamps': !![]
    });
function _0xb1f3(_0x46f4eb, _0x36cc1a) {
    _0x46f4eb = _0x46f4eb - (-0x7 * -0x1 + 0x1 * -0x245 + 0x3c5);
    const _0xb1c845 = _0x4825();
    let _0x218600 = _0xb1c845[_0x46f4eb];
    return _0x218600;
}
module[_0x2789a8(0x197)] = SessionPending;