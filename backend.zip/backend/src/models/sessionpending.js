function _0x56a9(_0x50ad7b, _0x5dd3aa) {
    _0x50ad7b = _0x50ad7b - (0x1860 + -0x1c8 + -0x15b1);
    const _0x3f1126 = _0x276d();
    let _0x1395b6 = _0x3f1126[_0x50ad7b];
    return _0x1395b6;
}
const _0xa8f6df = _0x56a9;
(function (_0x4182ae, _0x2d2257) {
    const _0x3a8fc7 = _0x56a9, _0x3c578a = _0x4182ae();
    while (!![]) {
        try {
            const _0x3a8f61 = -parseInt(_0x3a8fc7(0xf6)) / (-0x148f * 0x1 + 0x1 * -0x97d + 0x1e0d) + parseInt(_0x3a8fc7(0xf5)) / (0x22f9 + -0xf64 + -0x1393) + parseInt(_0x3a8fc7(0xee)) / (0xc * 0x81 + -0x22bd + 0x1cb4) + -parseInt(_0x3a8fc7(0xf9)) / (-0x240d * -0x1 + 0x1cdf + -0x40e8) * (parseInt(_0x3a8fc7(0xec)) / (0x70 * 0xd + -0x191 + 0x46 * -0xf)) + -parseInt(_0x3a8fc7(0xf4)) / (-0x923 + -0x24c7 + -0x188 * -0x1e) * (parseInt(_0x3a8fc7(0xe8)) / (-0x20b5 + 0x2048 + 0x74)) + parseInt(_0x3a8fc7(0xf0)) / (-0x6ef * -0x1 + 0x1e02 + -0x24e9) + parseInt(_0x3a8fc7(0xe7)) / (-0x1 * -0x2462 + -0x2ba * 0x1 + -0x219f) * (parseInt(_0x3a8fc7(0xf8)) / (0x1 * 0x1802 + 0x168a + -0x2 * 0x1741));
            if (_0x3a8f61 === _0x2d2257)
                break;
            else
                _0x3c578a['push'](_0x3c578a['shift']());
        } catch (_0x3ee963) {
            _0x3c578a['push'](_0x3c578a['shift']());
        }
    }
}(_0x276d, -0xf67ad + 0x4293d * 0x3 + -0x6b9 * -0x199));
function _0x276d() {
    const _0x3965ff = [
        'INTEGER',
        '../config/',
        '24ArZEbb',
        '845692VLyoak',
        '304550QSbCDo',
        'NOW',
        '2780170Rumsdo',
        '3025584nhQLkx',
        'STRING',
        'database',
        'sequelize',
        'exports',
        'DATE',
        'UUIDV4',
        'SessionPen',
        'dings',
        '18PmvMld',
        '1126202HzQppX',
        'cessed',
        'define',
        'ding',
        '5doYFoz',
        '0\x20=\x20pendin',
        '2219115DiWBrs',
        'UUID',
        '3986528Laibrk',
        'g,\x201\x20=\x20pro'
    ];
    _0x276d = function () {
        return _0x3965ff;
    };
    return _0x276d();
}
const {DataTypes} = require(_0xa8f6df(0xfc)), sequelize = require(_0xa8f6df(0xf3) + _0xa8f6df(0xfb)), SessionPending = sequelize[_0xa8f6df(0xea)](_0xa8f6df(0x100) + _0xa8f6df(0xeb), {
        'id': {
            'type': DataTypes[_0xa8f6df(0xef)],
            'defaultValue': DataTypes[_0xa8f6df(0xff)],
            'primaryKey': !![]
        },
        'sn': {
            'type': DataTypes[_0xa8f6df(0xfa)],
            'allowNull': !![]
        },
        'sessionId': {
            'type': DataTypes[_0xa8f6df(0xfa)],
            'allowNull': ![]
        },
        'boardingPass': {
            'type': DataTypes[_0xa8f6df(0xfa)],
            'allowNull': !![],
            'defaultValue': null
        },
        'dateCreated': {
            'type': DataTypes[_0xa8f6df(0xfe)],
            'defaultValue': DataTypes[_0xa8f6df(0xf7)]
        },
        'status': {
            'type': DataTypes[_0xa8f6df(0xf2)],
            'defaultValue': 0x0,
            'comment': _0xa8f6df(0xed) + _0xa8f6df(0xf1) + _0xa8f6df(0xe9)
        }
    }, {
        'tableName': _0xa8f6df(0x100) + _0xa8f6df(0x101),
        'timestamps': !![]
    });
module[_0xa8f6df(0xfd)] = SessionPending;