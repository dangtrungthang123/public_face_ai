const _0x409c1f = _0xfb23;
(function (_0x36e4d6, _0x1315fd) {
    const _0xa1560c = _0xfb23, _0x50c7de = _0x36e4d6();
    while (!![]) {
        try {
            const _0x2303ad = -parseInt(_0xa1560c(0x10b)) / (-0x430 + 0x2369 + 0xd8 * -0x25) * (parseInt(_0xa1560c(0x109)) / (-0x8 * -0x3a6 + 0x81f + -0x254d)) + -parseInt(_0xa1560c(0xfb)) / (0x822 + 0x1888 + -0x20a7) + -parseInt(_0xa1560c(0x100)) / (0x984 + -0x1 * -0x268f + -0x300f) * (-parseInt(_0xa1560c(0xff)) / (0xfc8 + -0xd7e + 0x7 * -0x53)) + -parseInt(_0xa1560c(0x103)) / (-0x4 * 0x293 + -0xd3f * -0x2 + 0xcf * -0x14) * (parseInt(_0xa1560c(0x102)) / (-0x328 + -0x4 * -0x691 + -0x1715)) + parseInt(_0xa1560c(0x110)) / (-0x7a8 + 0x65 * -0x59 + 0x1 * 0x2acd) + parseInt(_0xa1560c(0x104)) / (0x78f + -0x3 * -0x70b + 0x1 * -0x1ca7) + parseInt(_0xa1560c(0x10d)) / (0x1ca6 + 0x21e * -0x1 + -0xd3f * 0x2) * (parseInt(_0xa1560c(0x10e)) / (0x151a + -0x123 + -0x66 * 0x32));
            if (_0x2303ad === _0x1315fd)
                break;
            else
                _0x50c7de['push'](_0x50c7de['shift']());
        } catch (_0x2a51be) {
            _0x50c7de['push'](_0x50c7de['shift']());
        }
    }
}(_0x5ddf, 0x1 * -0xb48aa + -0x5e59c + 0x1b5f94));
function _0x5ddf() {
    const _0x36ef63 = [
        '1004797wBLMho',
        'database',
        '70VQDgzR',
        '95535lNVXvc',
        'Admin',
        '2055632wYmvOL',
        '449223fGHqlL',
        'define',
        'admins',
        'exports',
        '5yquyJY',
        '5037852ZmhQIW',
        'UUIDV4',
        '308eMBpuO',
        '84684ziWmxv',
        '7796916zLbTAt',
        '../config/',
        'STRING',
        'UUID',
        'sequelize',
        '2BjcbIL',
        'admin'
    ];
    _0x5ddf = function () {
        return _0x36ef63;
    };
    return _0x5ddf();
}
const {DataTypes} = require(_0x409c1f(0x108)), sequelize = require(_0x409c1f(0x105) + _0x409c1f(0x10c)), Admin = sequelize[_0x409c1f(0xfc)](_0x409c1f(0x10f), {
        'id': {
            'type': DataTypes[_0x409c1f(0x107)],
            'defaultValue': DataTypes[_0x409c1f(0x101)],
            'primaryKey': !![]
        },
        'username': {
            'type': DataTypes[_0x409c1f(0x106)],
            'allowNull': ![],
            'unique': !![]
        },
        'password': {
            'type': DataTypes[_0x409c1f(0x106)],
            'allowNull': ![]
        },
        'role': {
            'type': DataTypes[_0x409c1f(0x106)],
            'defaultValue': _0x409c1f(0x10a)
        }
    }, {
        'tableName': _0x409c1f(0xfd),
        'timestamps': !![]
    });
function _0xfb23(_0x111f3d, _0x292ece) {
    _0x111f3d = _0x111f3d - (-0x1867 * -0x1 + 0x19e7 + 0x45 * -0xb7);
    const _0x10169b = _0x5ddf();
    let _0x3c3065 = _0x10169b[_0x111f3d];
    return _0x3c3065;
}
module[_0x409c1f(0xfe)] = Admin;