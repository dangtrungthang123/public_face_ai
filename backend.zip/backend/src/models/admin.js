const _0x417434 = _0x27a5;
function _0x27a5(_0x399d02, _0x3f1e61) {
    _0x399d02 = _0x399d02 - (0xb8f + 0x1c7a + -0x2687);
    const _0x38342a = _0x3894();
    let _0x1b9fed = _0x38342a[_0x399d02];
    return _0x1b9fed;
}
(function (_0x56870e, _0x4a7dfd) {
    const _0x2a1f02 = _0x27a5, _0x6c472a = _0x56870e();
    while (!![]) {
        try {
            const _0x58aaaf = -parseInt(_0x2a1f02(0x18e)) / (0xa22 * -0x3 + -0x2 * -0xe84 + 0x27 * 0x9) * (-parseInt(_0x2a1f02(0x18a)) / (-0x226e + 0x176e + 0xb02)) + -parseInt(_0x2a1f02(0x188)) / (-0x63c + 0x7 * 0x131 + -0x86 * 0x4) + parseInt(_0x2a1f02(0x187)) / (0xce1 + -0x204b + 0x136e) * (-parseInt(_0x2a1f02(0x190)) / (0x1 * 0x1af5 + 0xded + 0x3 * -0xd9f)) + -parseInt(_0x2a1f02(0x186)) / (0x2026 * -0x1 + -0x1fa3 + -0x3fcf * -0x1) * (parseInt(_0x2a1f02(0x18c)) / (0x133e + 0xbfa + 0x5 * -0x63d)) + -parseInt(_0x2a1f02(0x191)) / (-0x2625 + 0x16 * -0xc0 + 0x36ad) + -parseInt(_0x2a1f02(0x182)) / (-0x5fb + -0xc11 + 0x1215 * 0x1) * (parseInt(_0x2a1f02(0x184)) / (-0x1fd5 + 0x55 * -0x5e + 0x3f15)) + -parseInt(_0x2a1f02(0x196)) / (0x1 * -0x200f + -0xe3 * 0x10 + 0x96 * 0x4f) * (-parseInt(_0x2a1f02(0x18b)) / (0x1bc * -0x10 + -0x1 * 0x1553 + -0x311f * -0x1));
            if (_0x58aaaf === _0x4a7dfd)
                break;
            else
                _0x6c472a['push'](_0x6c472a['shift']());
        } catch (_0x1866ca) {
            _0x6c472a['push'](_0x6c472a['shift']());
        }
    }
}(_0x3894, -0x1608 + -0x8964e + 0x2225 * 0xb3));
function _0x3894() {
    const _0x156d9f = [
        '84330uKGEZw',
        '7930172ipDXyr',
        '5527707MsxFxZ',
        'UUIDV4',
        '292OSkfLB',
        '12zMSHkv',
        '217Nxjexe',
        'sequelize',
        '1105mSFVlJ',
        'STRING',
        '5vzXQvb',
        '31072gwRkJM',
        '../config/',
        'define',
        'admins',
        'Admin',
        '74554447RTAIxY',
        'UUID',
        'exports',
        '15102657AxQCLN',
        'admin',
        '10nyiIEx',
        'database'
    ];
    _0x3894 = function () {
        return _0x156d9f;
    };
    return _0x3894();
}
const {DataTypes} = require(_0x417434(0x18d)), sequelize = require(_0x417434(0x192) + _0x417434(0x185)), Admin = sequelize[_0x417434(0x193)](_0x417434(0x195), {
        'id': {
            'type': DataTypes[_0x417434(0x197)],
            'defaultValue': DataTypes[_0x417434(0x189)],
            'primaryKey': !![]
        },
        'username': {
            'type': DataTypes[_0x417434(0x18f)],
            'allowNull': ![],
            'unique': !![]
        },
        'password': {
            'type': DataTypes[_0x417434(0x18f)],
            'allowNull': ![]
        },
        'role': {
            'type': DataTypes[_0x417434(0x18f)],
            'defaultValue': _0x417434(0x183)
        }
    }, {
        'tableName': _0x417434(0x194),
        'timestamps': !![]
    });
module[_0x417434(0x198)] = Admin;