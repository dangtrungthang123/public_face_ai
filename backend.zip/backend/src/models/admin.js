function _0xf96d(_0x45d30b, _0x550e58) {
    _0x45d30b = _0x45d30b - (-0x30a * -0x7 + -0x3b * 0xb + 0x1 * -0x120b);
    const _0x6e0c25 = _0x435a();
    let _0x286b5a = _0x6e0c25[_0x45d30b];
    return _0x286b5a;
}
const _0x1060fa = _0xf96d;
(function (_0x570730, _0x535441) {
    const _0x462640 = _0xf96d, _0x584040 = _0x570730();
    while (!![]) {
        try {
            const _0x664c1e = -parseInt(_0x462640(0xc1)) / (-0x431 * 0x1 + -0x5ba + 0x2 * 0x4f6) + parseInt(_0x462640(0xbd)) / (-0x8cb * 0x1 + 0x445 + -0x122 * -0x4) + parseInt(_0x462640(0xb9)) / (0x1 * -0x11f9 + 0x1e41 + 0x15d * -0x9) * (parseInt(_0x462640(0xbc)) / (0xd79 * -0x1 + -0xd48 + 0x59 * 0x4d)) + -parseInt(_0x462640(0xb3)) / (0xf1 * 0x29 + 0x48f + -0x2b23) + parseInt(_0x462640(0xb2)) / (-0x3 * -0xbeb + 0x8b3 + -0x2c6e * 0x1) + parseInt(_0x462640(0xba)) / (0x6cd * -0x1 + 0x30b * -0x6 + 0x1916) * (parseInt(_0x462640(0xb6)) / (-0x3e * -0x94 + -0x9 * 0x403 + -0x19 * -0x3)) + -parseInt(_0x462640(0xb4)) / (0x1 * 0x8a + 0x1426 + -0x14a7);
            if (_0x664c1e === _0x535441)
                break;
            else
                _0x584040['push'](_0x584040['shift']());
        } catch (_0x476fdb) {
            _0x584040['push'](_0x584040['shift']());
        }
    }
}(_0x435a, -0x1abb * -0x14 + -0x1 * 0x7249 + 0xdf86));
function _0x435a() {
    const _0x162fc3 = [
        'database',
        '../config/',
        'define',
        '26916lhyUxk',
        '93290aNXDGI',
        '3139587FrTQkr',
        'admins',
        '8zharPJ',
        'UUIDV4',
        'Admin',
        '33katlkA',
        '691026yYbQYU',
        'exports',
        '114196bqpLhw',
        '330682pRsMku',
        'admin',
        'UUID',
        'STRING',
        '50258RNIhKt',
        'sequelize'
    ];
    _0x435a = function () {
        return _0x162fc3;
    };
    return _0x435a();
}
const {DataTypes} = require(_0x1060fa(0xc2)), sequelize = require(_0x1060fa(0xc4) + _0x1060fa(0xc3)), Admin = sequelize[_0x1060fa(0xc5)](_0x1060fa(0xb8), {
        'id': {
            'type': DataTypes[_0x1060fa(0xbf)],
            'defaultValue': DataTypes[_0x1060fa(0xb7)],
            'primaryKey': !![]
        },
        'username': {
            'type': DataTypes[_0x1060fa(0xc0)],
            'allowNull': ![],
            'unique': !![]
        },
        'password': {
            'type': DataTypes[_0x1060fa(0xc0)],
            'allowNull': ![]
        },
        'role': {
            'type': DataTypes[_0x1060fa(0xc0)],
            'defaultValue': _0x1060fa(0xbe)
        }
    }, {
        'tableName': _0x1060fa(0xb5),
        'timestamps': !![]
    });
module[_0x1060fa(0xbb)] = Admin;