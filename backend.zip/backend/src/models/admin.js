const _0xf44fe4 = _0x40ff;
function _0x40ff(_0x58b0a8, _0x487f5f) {
    _0x58b0a8 = _0x58b0a8 - (-0x2010 + -0x117a + 0x3e5 * 0xd);
    const _0x5da539 = _0x19ab();
    let _0x3b8a4e = _0x5da539[_0x58b0a8];
    return _0x3b8a4e;
}
(function (_0x335b84, _0x3ba641) {
    const _0x433461 = _0x40ff, _0x356798 = _0x335b84();
    while (!![]) {
        try {
            const _0xf105c2 = parseInt(_0x433461(0x120)) / (0x31e * 0xb + 0x18e * -0x3 + -0x1d9f * 0x1) * (parseInt(_0x433461(0x123)) / (-0x1fa8 + 0x58d * -0x5 + 0x3b6b)) + parseInt(_0x433461(0x11a)) / (-0x2199 + 0x27 * -0x99 + 0x38eb) + parseInt(_0x433461(0x121)) / (-0x862 + -0x2337 + 0x2b9d) * (-parseInt(_0x433461(0x129)) / (-0x713 + -0x16f * 0x1 + 0x887)) + parseInt(_0x433461(0x11f)) / (0x1 * 0x12d1 + 0x18 * 0x3f + -0x18b3) * (-parseInt(_0x433461(0x119)) / (-0x1bf * -0x2 + 0x1fa0 + -0x2317)) + parseInt(_0x433461(0x11e)) / (0x24dc + 0x3 * -0xa35 + -0x635 * 0x1) * (-parseInt(_0x433461(0x12a)) / (-0xe00 + -0x2317 + 0x2 * 0x1890)) + -parseInt(_0x433461(0x12c)) / (0xd35 * -0x2 + -0x1e26 + 0x389a) + -parseInt(_0x433461(0x11c)) / (0x2 * -0x3b + -0x1a7c + 0x1afd) * (-parseInt(_0x433461(0x122)) / (0xc43 + 0x9b4 * -0x1 + 0x283 * -0x1));
            if (_0xf105c2 === _0x3ba641)
                break;
            else
                _0x356798['push'](_0x356798['shift']());
        } catch (_0x2dfe98) {
            _0x356798['push'](_0x356798['shift']());
        }
    }
}(_0x19ab, 0x154e9d + 0x78d7 + -0xa7fbe));
function _0x19ab() {
    const _0x24e8b4 = [
        'exports',
        'admins',
        'admin',
        'sequelize',
        '3138295lDkunF',
        '13257873CCgwnH',
        'UUID',
        '8355460NIbubi',
        '../config/',
        'STRING',
        'define',
        '3404443PLmgBT',
        '2324055WfyVqi',
        'database',
        '1908676OenKVX',
        'UUIDV4',
        '8waoOmp',
        '18fwDCUx',
        '2yyABmL',
        '4wIvZsN',
        '228Cjyoaq',
        '1063114qNvYnv',
        'Admin'
    ];
    _0x19ab = function () {
        return _0x24e8b4;
    };
    return _0x19ab();
}
const {DataTypes} = require(_0xf44fe4(0x128)), sequelize = require(_0xf44fe4(0x12d) + _0xf44fe4(0x11b)), Admin = sequelize[_0xf44fe4(0x118)](_0xf44fe4(0x124), {
        'id': {
            'type': DataTypes[_0xf44fe4(0x12b)],
            'defaultValue': DataTypes[_0xf44fe4(0x11d)],
            'primaryKey': !![]
        },
        'username': {
            'type': DataTypes[_0xf44fe4(0x117)],
            'allowNull': ![],
            'unique': !![]
        },
        'password': {
            'type': DataTypes[_0xf44fe4(0x117)],
            'allowNull': ![]
        },
        'role': {
            'type': DataTypes[_0xf44fe4(0x117)],
            'defaultValue': _0xf44fe4(0x127)
        }
    }, {
        'tableName': _0xf44fe4(0x126),
        'timestamps': !![]
    });
module[_0xf44fe4(0x125)] = Admin;