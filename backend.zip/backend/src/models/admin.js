const _0x5f0959 = _0x4a89;
(function (_0x43d9a6, _0x2a91e1) {
    const _0x3bed41 = _0x4a89, _0x2c3605 = _0x43d9a6();
    while (!![]) {
        try {
            const _0xddedde = parseInt(_0x3bed41(0x117)) / (0x864 + -0x18d7 + 0x1074) + -parseInt(_0x3bed41(0x111)) / (0xdc2 + 0x140f * 0x1 + -0x1 * 0x21cf) + parseInt(_0x3bed41(0x11b)) / (-0x8f8 + 0xdcd * -0x1 + 0x18 * 0xf3) * (-parseInt(_0x3bed41(0x113)) / (0x1 * -0x6f + 0x13c7 + -0x1354)) + -parseInt(_0x3bed41(0x118)) / (0x16ad + -0x11fb * 0x1 + -0x1 * 0x4ad) + parseInt(_0x3bed41(0x11e)) / (-0x1 * -0x2305 + -0x216e + -0x1 * 0x191) + parseInt(_0x3bed41(0x120)) / (-0x9 * 0x362 + 0x6 * -0x38b + 0x33bb) + parseInt(_0x3bed41(0x115)) / (-0x7 * -0x2f9 + -0x1b * 0x43 + -0x1a * 0x87);
            if (_0xddedde === _0x2a91e1)
                break;
            else
                _0x2c3605['push'](_0x2c3605['shift']());
        } catch (_0x47e32e) {
            _0x2c3605['push'](_0x2c3605['shift']());
        }
    }
}(_0x1426, 0x8 * 0xbc19 + -0x3 * -0x2725 + -0x14f77));
const {DataTypes} = require(_0x5f0959(0x112)), sequelize = require(_0x5f0959(0x11f) + _0x5f0959(0x11c)), Admin = sequelize[_0x5f0959(0x10e)](_0x5f0959(0x114), {
        'id': {
            'type': DataTypes[_0x5f0959(0x119)],
            'defaultValue': DataTypes[_0x5f0959(0x11a)],
            'primaryKey': !![]
        },
        'username': {
            'type': DataTypes[_0x5f0959(0x10f)],
            'allowNull': ![],
            'unique': !![]
        },
        'password': {
            'type': DataTypes[_0x5f0959(0x10f)],
            'allowNull': ![]
        },
        'role': {
            'type': DataTypes[_0x5f0959(0x10f)],
            'defaultValue': _0x5f0959(0x110)
        }
    }, {
        'tableName': _0x5f0959(0x11d),
        'timestamps': !![]
    });
module[_0x5f0959(0x116)] = Admin;
function _0x4a89(_0x2ff554, _0x48491d) {
    _0x2ff554 = _0x2ff554 - (0x1025 + 0x164 * -0x7 + -0x1 * 0x55b);
    const _0x382cc4 = _0x1426();
    let _0x1850e8 = _0x382cc4[_0x2ff554];
    return _0x1850e8;
}
function _0x1426() {
    const _0x366ae1 = [
        'UUID',
        'UUIDV4',
        '8985PJRsKb',
        'database',
        'admins',
        '814848jdHrFN',
        '../config/',
        '2709063xDEBzQ',
        'define',
        'STRING',
        'admin',
        '167526ELcByB',
        'sequelize',
        '456HlAbQY',
        'Admin',
        '1282280dlrnkF',
        'exports',
        '108523BCAmeJ',
        '185120AfeJcR'
    ];
    _0x1426 = function () {
        return _0x366ae1;
    };
    return _0x1426();
}