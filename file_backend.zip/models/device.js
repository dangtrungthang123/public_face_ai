const _0x115261 = _0x1c00;
function _0x1c00(_0x281583, _0x28f042) {
    _0x281583 = _0x281583 - (0xa9f + -0x1bd2 + -0x9 * -0x212);
    const _0x325245 = _0xf5df();
    let _0x23d562 = _0x325245[_0x281583];
    return _0x23d562;
}
(function (_0x463a8b, _0x3743e7) {
    const _0x4d6d18 = _0x1c00, _0xfe14c1 = _0x463a8b();
    while (!![]) {
        try {
            const _0x31b387 = parseInt(_0x4d6d18(0x178)) / (-0x1 * -0x385 + -0xb2e + 0x7aa) + -parseInt(_0x4d6d18(0x185)) / (0x6dd + -0x1c4 * 0x9 + 0x909) + -parseInt(_0x4d6d18(0x17e)) / (0xf86 + -0x1cbb + -0x18 * -0x8d) + -parseInt(_0x4d6d18(0x179)) / (-0x1c2d * 0x1 + -0x839 + -0x4f * -0x76) + -parseInt(_0x4d6d18(0x17d)) / (0x5a6 + -0x913 * -0x1 + 0xeb4 * -0x1) * (-parseInt(_0x4d6d18(0x17f)) / (-0xa83 * 0x3 + -0x5 * 0x3ee + 0x3335 * 0x1)) + parseInt(_0x4d6d18(0x171)) / (0x1e2f + -0x1 * 0xd5b + -0xb * 0x187) * (parseInt(_0x4d6d18(0x172)) / (0x1070 + -0x163d * -0x1 + -0x26a5)) + parseInt(_0x4d6d18(0x183)) / (0x2 * 0xd53 + -0x15ca + 0x41 * -0x13);
            if (_0x31b387 === _0x3743e7)
                break;
            else
                _0xfe14c1['push'](_0xfe14c1['shift']());
        } catch (_0x7d80f5) {
            _0xfe14c1['push'](_0xfe14c1['shift']());
        }
    }
}(_0xf5df, -0x45a8a + -0x47e01 + 0x5 * 0x29805));
const {DataTypes} = require(_0x115261(0x17b)), sequelize = require(_0x115261(0x16f) + _0x115261(0x17c)), Device = sequelize[_0x115261(0x174)](_0x115261(0x181), {
        'sn': {
            'type': DataTypes[_0x115261(0x175)],
            'primaryKey': !![],
            'allowNull': ![]
        },
        'name': {
            'type': DataTypes[_0x115261(0x175)],
            'defaultValue': _0x115261(0x173)
        },
        'status': {
            'type': DataTypes[_0x115261(0x184)](_0x115261(0x177), _0x115261(0x180)),
            'defaultValue': _0x115261(0x180)
        },
        'last_seen': {
            'type': DataTypes[_0x115261(0x17a)],
            'defaultValue': DataTypes[_0x115261(0x182)]
        },
        'ip_address': {
            'type': DataTypes[_0x115261(0x175)],
            'allowNull': !![]
        }
    }, {
        'tableName': _0x115261(0x176),
        'timestamps': !![]
    });
module[_0x115261(0x170)] = Device;
function _0xf5df() {
    const _0x354acb = [
        'offline',
        'Device',
        'NOW',
        '5862276KZyDmb',
        'ENUM',
        '865788qxmSlY',
        '../config/',
        'exports',
        '114149UygwWJ',
        '40tijpQf',
        'New\x20Device',
        'define',
        'STRING',
        'devices',
        'online',
        '313429GOytcY',
        '1128664zZajtZ',
        'DATE',
        'sequelize',
        'database',
        '1115CjlsAx',
        '313593tDpXwg',
        '1170CAkdXy'
    ];
    _0xf5df = function () {
        return _0x354acb;
    };
    return _0xf5df();
}