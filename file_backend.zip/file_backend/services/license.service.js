function _0x4e13() {
    const _0x5bd07b = [
        'kPwzh',
        'verify',
        'No\x20active\x20',
        'DKmwJ',
        'IoaMa',
        'Invalid\x20li',
        'wMeeW',
        'key-manage',
        'exports',
        'active',
        'cWPkE',
        'verifyLice',
        'toString',
        'parse',
        'sha256',
        'from',
        'sSdVT',
        'wPBFH',
        'licenseKey',
        '40ijYRmi',
        'inactive',
        'license\x20fo',
        'License\x20Ve',
        'und',
        'createSign',
        'sign',
        'crypto',
        'JqZkr',
        '799468QboULF',
        '\x20Error:',
        'oKRuK',
        'utf8',
        'create',
        'Key',
        '484797XJuImJ',
        'pired',
        'eLicense',
        'message',
        'expiresAt',
        'getPrivate',
        'saveLicens',
        'stringify',
        'getPublicK',
        'update',
        '6167091efSxYh',
        'ature',
        'License\x20ex',
        '200948LIRSpb',
        'cense\x20sign',
        'findOne',
        '602597VZFlHT',
        '../config/',
        'error',
        'hKJTO',
        'base64',
        '404958trrMIl',
        'rkBDu',
        '3281824jSQRhI',
        'nseData',
        'createVeri',
        'rification',
        'PwVjN',
        '../models/',
        'jrhfg',
        'end',
        'signLicens',
        'license',
        'checkActiv'
    ];
    _0x4e13 = function () {
        return _0x5bd07b;
    };
    return _0x4e13();
}
const _0x3fd341 = _0x2784;
(function (_0x3bd2d6, _0x2c9d3f) {
    const _0x1da860 = _0x2784, _0x39a101 = _0x3bd2d6();
    while (!![]) {
        try {
            const _0x23f151 = -parseInt(_0x1da860(0x1ed)) / (-0x103 + -0x21fd * 0x1 + 0x67 * 0x57) + parseInt(_0x1da860(0x21b)) / (-0x6 * -0x520 + -0x117c * 0x1 + -0xd42) + -parseInt(_0x1da860(0x221)) / (0x2 * -0x1ee + 0x2536 + -0x2157) + -parseInt(_0x1da860(0x1ea)) / (-0xff + -0x1c * -0xce + -0x1 * 0x1585) * (-parseInt(_0x1da860(0x212)) / (0x2278 + -0xeb4 * 0x1 + -0x3f3 * 0x5)) + parseInt(_0x1da860(0x1f2)) / (0x22b5 + 0x57 * -0x33 + -0x115a) + parseInt(_0x1da860(0x22b)) / (0x3 * -0x7b3 + -0x74f + 0x1e6f) + -parseInt(_0x1da860(0x1f4)) / (0xb0d + 0x22b8 + -0x2dbd);
            if (_0x23f151 === _0x2c9d3f)
                break;
            else
                _0x39a101['push'](_0x39a101['shift']());
        } catch (_0x45fe4a) {
            _0x39a101['push'](_0x39a101['shift']());
        }
    }
}(_0x4e13, 0x1175fc + -0xd5e1d + 0x4b101 * 0x1));
function _0x2784(_0x4d6125, _0x52c386) {
    _0x4d6125 = _0x4d6125 - (-0x4 * 0x42e + -0x2220 + -0x1a6 * -0x20);
    const _0x459199 = _0x4e13();
    let _0x481a37 = _0x459199[_0x4d6125];
    return _0x481a37;
}
const crypto = require(_0x3fd341(0x219)), License = require(_0x3fd341(0x1f9) + _0x3fd341(0x1fd)), KeyManager = require(_0x3fd341(0x1ee) + _0x3fd341(0x206) + 'r');
class LicenseService {
    static [_0x3fd341(0x229) + 'ey']() {
        const _0x1b044b = _0x3fd341;
        return KeyManager[_0x1b044b(0x229) + 'ey']();
    }
    static [_0x3fd341(0x226) + _0x3fd341(0x220)]() {
        const _0x3b0b6e = _0x3fd341;
        return KeyManager[_0x3b0b6e(0x226) + _0x3b0b6e(0x220)]();
    }
    static [_0x3fd341(0x20a) + _0x3fd341(0x1f5)](_0x2fd61b) {
        const _0x44edb1 = _0x3fd341, _0x4d7c0a = {
                'kPwzh': _0x44edb1(0x1f1),
                'cWPkE': _0x44edb1(0x21e),
                'wPBFH': _0x44edb1(0x20d),
                'hKJTO': _0x44edb1(0x204) + _0x44edb1(0x1eb) + _0x44edb1(0x1e8),
                'oKRuK': function (_0x4cee4f, _0x431167) {
                    return _0x4cee4f < _0x431167;
                },
                'rkBDu': _0x44edb1(0x1e9) + _0x44edb1(0x222),
                'sSdVT': _0x44edb1(0x215) + _0x44edb1(0x1f7) + _0x44edb1(0x21c)
            };
        try {
            const _0x180d95 = this[_0x44edb1(0x229) + 'ey'](), _0x8500f5 = JSON[_0x44edb1(0x20c)](Buffer[_0x44edb1(0x20e)](_0x2fd61b, _0x4d7c0a[_0x44edb1(0x1ff)])[_0x44edb1(0x20b)](_0x4d7c0a[_0x44edb1(0x209)])), {
                    data: _0x47566d,
                    signature: _0x47d1c7
                } = _0x8500f5, _0x46ee8d = crypto[_0x44edb1(0x1f6) + 'fy'](_0x4d7c0a[_0x44edb1(0x210)]);
            _0x46ee8d[_0x44edb1(0x22a)](JSON[_0x44edb1(0x228)](_0x47566d)), _0x46ee8d[_0x44edb1(0x1fb)]();
            const _0x12aaf3 = _0x46ee8d[_0x44edb1(0x200)](_0x180d95, _0x47d1c7, _0x4d7c0a[_0x44edb1(0x1ff)]);
            if (!_0x12aaf3)
                throw new Error(_0x4d7c0a[_0x44edb1(0x1f0)]);
            const _0x577885 = new Date(_0x47566d[_0x44edb1(0x225)]);
            if (_0x4d7c0a[_0x44edb1(0x21d)](_0x577885, new Date()))
                throw new Error(_0x4d7c0a[_0x44edb1(0x1f3)]);
            return {
                'isValid': !![],
                'expiresAt': _0x577885,
                'data': _0x47566d
            };
        } catch (_0x4a24ab) {
            return console[_0x44edb1(0x1ef)](_0x4d7c0a[_0x44edb1(0x20f)], _0x4a24ab[_0x44edb1(0x224)]), {
                'isValid': ![],
                'error': _0x4a24ab[_0x44edb1(0x224)]
            };
        }
    }
    static [_0x3fd341(0x1fc) + 'e'](_0x4fe577) {
        const _0x1d8bd1 = _0x3fd341, _0x3b0e8f = {
                'DKmwJ': _0x1d8bd1(0x20d),
                'jrhfg': _0x1d8bd1(0x1f1)
            }, _0x59a5fa = this[_0x1d8bd1(0x226) + _0x1d8bd1(0x220)](), _0x2d7e89 = crypto[_0x1d8bd1(0x217)](_0x3b0e8f[_0x1d8bd1(0x202)]);
        _0x2d7e89[_0x1d8bd1(0x22a)](JSON[_0x1d8bd1(0x228)](_0x4fe577)), _0x2d7e89[_0x1d8bd1(0x1fb)]();
        const _0xb5f363 = _0x2d7e89[_0x1d8bd1(0x218)](_0x59a5fa, _0x3b0e8f[_0x1d8bd1(0x1fa)]);
        return Buffer[_0x1d8bd1(0x20e)](JSON[_0x1d8bd1(0x228)]({
            'data': _0x4fe577,
            'signature': _0xb5f363
        }))[_0x1d8bd1(0x20b)](_0x3b0e8f[_0x1d8bd1(0x1fa)]);
    }
    static async [_0x3fd341(0x227) + 'e'](_0xe6760a, _0xca50d6) {
        const _0x1d3850 = _0x3fd341, _0x33eccb = {
                'JqZkr': _0x1d3850(0x213),
                'PwVjN': _0x1d3850(0x208)
            };
        return await License[_0x1d3850(0x22a)]({ 'status': _0x33eccb[_0x1d3850(0x21a)] }, { 'where': { 'status': _0x33eccb[_0x1d3850(0x1f8)] } }), await License[_0x1d3850(0x21f)]({
            'licenseKey': _0xe6760a,
            'expiresAt': _0xca50d6,
            'status': _0x33eccb[_0x1d3850(0x1f8)]
        });
    }
    static async [_0x3fd341(0x1fe) + _0x3fd341(0x223)]() {
        const _0x26af3a = _0x3fd341, _0x5b7db1 = {
                'wMeeW': _0x26af3a(0x208),
                'IoaMa': _0x26af3a(0x201) + _0x26af3a(0x214) + _0x26af3a(0x216)
            }, _0x34b3e8 = await License[_0x26af3a(0x1ec)]({ 'where': { 'status': _0x5b7db1[_0x26af3a(0x205)] } });
        if (!_0x34b3e8)
            return {
                'isValid': ![],
                'error': _0x5b7db1[_0x26af3a(0x203)]
            };
        return this[_0x26af3a(0x20a) + _0x26af3a(0x1f5)](_0x34b3e8[_0x26af3a(0x211)]);
    }
}
module[_0x3fd341(0x207)] = LicenseService;