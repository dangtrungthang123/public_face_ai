const _0xe8895e = _0x5be7;
(function (_0x539abf, _0x592310) {
    const _0x48eec5 = _0x5be7, _0x197c9d = _0x539abf();
    while (!![]) {
        try {
            const _0x20302c = -parseInt(_0x48eec5(0x187)) / (0x184c + -0x31f * 0x7 + -0x272) * (parseInt(_0x48eec5(0x194)) / (0x2d3 * 0x1 + 0xed7 * 0x2 + -0x207f * 0x1)) + -parseInt(_0x48eec5(0x166)) / (-0x1b57 + 0x1f40 + -0x3e6) * (-parseInt(_0x48eec5(0x17f)) / (-0x1 * -0x2353 + -0x2 * 0x7c1 + 0x13cd * -0x1)) + -parseInt(_0x48eec5(0x174)) / (0x10 * -0x247 + -0x1 * -0x5bf + 0x1 * 0x1eb6) + parseInt(_0x48eec5(0x183)) / (0x1 * 0x209 + -0x6a2 * -0x2 + -0xf47) + parseInt(_0x48eec5(0x193)) / (-0x1885 + 0x8a8 + 0xfe4) + parseInt(_0x48eec5(0x188)) / (-0x46d * 0x7 + -0x25 * -0x92 + 0x9e9) * (parseInt(_0x48eec5(0x180)) / (0x1b67 + -0x1 * 0x2092 + -0x3 * -0x1bc)) + -parseInt(_0x48eec5(0x19a)) / (-0x2 * -0xb57 + -0x5 * -0xe3 + 0xef * -0x1d) * (parseInt(_0x48eec5(0x16a)) / (-0x4cb + 0xa5a * -0x2 + -0xcc5 * -0x2));
            if (_0x20302c === _0x592310)
                break;
            else
                _0x197c9d['push'](_0x197c9d['shift']());
        } catch (_0x513a72) {
            _0x197c9d['push'](_0x197c9d['shift']());
        }
    }
}(_0x35c6, 0x3ce1 * -0x39 + -0x11022f * -0x1 + -0x1 * -0x77632));
const crypto = require(_0xe8895e(0x190)), License = require(_0xe8895e(0x195) + _0xe8895e(0x15a)), KeyManager = require(_0xe8895e(0x15d) + _0xe8895e(0x16f) + 'r');
function _0x35c6() {
    const _0x117a90 = [
        'License\x20Ve',
        'getPublicK',
        'checkActiv',
        'license',
        'iZjLW',
        'nseData',
        '../config/',
        'message',
        'license\x20fo',
        'jbRjA',
        'create',
        'zAbMi',
        'No\x20active\x20',
        'rification',
        'verifyLice',
        '198SAtyDG',
        'saveLicens',
        'utf8',
        'XEflD',
        '3441031iSezlq',
        'end',
        'createSign',
        'License\x20ex',
        'parse',
        'key-manage',
        'Gnpuj',
        'active',
        'oNcwE',
        'cense\x20sign',
        '2220585boIsDD',
        'from',
        'verify',
        'lpWZs',
        'MmTdR',
        'gUTnZ',
        'und',
        'error',
        'vAJOZ',
        'base64',
        'ature',
        '39304vnNGtk',
        '2092878Rylhoh',
        'Invalid\x20li',
        'exports',
        '4058988MbQYyP',
        'expiresAt',
        'KqUWL',
        'Key',
        '23857JXdfkz',
        '24EvjoGv',
        'sign',
        'toString',
        'findOne',
        'update',
        'licenseKey',
        'sha256',
        'createVeri',
        'crypto',
        'getPrivate',
        'tdMST',
        '1157408RRJlki',
        '60QuHRxN',
        '../models/',
        'pired',
        '\x20Error:',
        'jdONl',
        'stringify',
        '10rUfxRH',
        'inactive',
        'signLicens',
        'eLicense'
    ];
    _0x35c6 = function () {
        return _0x117a90;
    };
    return _0x35c6();
}
class LicenseService {
    static [_0xe8895e(0x158) + 'ey']() {
        const _0x431c14 = _0xe8895e;
        return KeyManager[_0x431c14(0x158) + 'ey']();
    }
    static [_0xe8895e(0x191) + _0xe8895e(0x186)]() {
        const _0x485f68 = _0xe8895e;
        return KeyManager[_0x485f68(0x191) + _0x485f68(0x186)]();
    }
    static [_0xe8895e(0x165) + _0xe8895e(0x15c)](_0x372b49) {
        const _0x2aa710 = _0xe8895e, _0x4ced01 = {
                'jdONl': _0x2aa710(0x17d),
                'iZjLW': _0x2aa710(0x168),
                'oNcwE': _0x2aa710(0x18e),
                'jbRjA': _0x2aa710(0x181) + _0x2aa710(0x173) + _0x2aa710(0x17e),
                'zAbMi': function (_0x3cf156, _0x411f2c) {
                    return _0x3cf156 < _0x411f2c;
                },
                'lpWZs': _0x2aa710(0x16d) + _0x2aa710(0x196),
                'tdMST': _0x2aa710(0x19e) + _0x2aa710(0x164) + _0x2aa710(0x197)
            };
        try {
            const _0x209e9f = this[_0x2aa710(0x158) + 'ey'](), _0x571e48 = JSON[_0x2aa710(0x16e)](Buffer[_0x2aa710(0x175)](_0x372b49, _0x4ced01[_0x2aa710(0x198)])[_0x2aa710(0x18a)](_0x4ced01[_0x2aa710(0x15b)])), {
                    data: _0x5ba0fd,
                    signature: _0x3037a8
                } = _0x571e48, _0x36c79a = crypto[_0x2aa710(0x18f) + 'fy'](_0x4ced01[_0x2aa710(0x172)]);
            _0x36c79a[_0x2aa710(0x18c)](JSON[_0x2aa710(0x199)](_0x5ba0fd)), _0x36c79a[_0x2aa710(0x16b)]();
            const _0x3e4807 = _0x36c79a[_0x2aa710(0x176)](_0x209e9f, _0x3037a8, _0x4ced01[_0x2aa710(0x198)]);
            if (!_0x3e4807)
                throw new Error(_0x4ced01[_0x2aa710(0x160)]);
            const _0x581d51 = new Date(_0x5ba0fd[_0x2aa710(0x184)]);
            if (_0x4ced01[_0x2aa710(0x162)](_0x581d51, new Date()))
                throw new Error(_0x4ced01[_0x2aa710(0x177)]);
            return {
                'isValid': !![],
                'expiresAt': _0x581d51,
                'data': _0x5ba0fd
            };
        } catch (_0x27aceb) {
            return console[_0x2aa710(0x17b)](_0x4ced01[_0x2aa710(0x192)], _0x27aceb[_0x2aa710(0x15e)]), {
                'isValid': ![],
                'error': _0x27aceb[_0x2aa710(0x15e)]
            };
        }
    }
    static [_0xe8895e(0x19c) + 'e'](_0x2b5fb6) {
        const _0x5133f0 = _0xe8895e, _0x4f0804 = {
                'XEflD': _0x5133f0(0x18e),
                'Gnpuj': _0x5133f0(0x17d)
            }, _0x496751 = this[_0x5133f0(0x191) + _0x5133f0(0x186)](), _0x1216df = crypto[_0x5133f0(0x16c)](_0x4f0804[_0x5133f0(0x169)]);
        _0x1216df[_0x5133f0(0x18c)](JSON[_0x5133f0(0x199)](_0x2b5fb6)), _0x1216df[_0x5133f0(0x16b)]();
        const _0x4c574f = _0x1216df[_0x5133f0(0x189)](_0x496751, _0x4f0804[_0x5133f0(0x170)]);
        return Buffer[_0x5133f0(0x175)](JSON[_0x5133f0(0x199)]({
            'data': _0x2b5fb6,
            'signature': _0x4c574f
        }))[_0x5133f0(0x18a)](_0x4f0804[_0x5133f0(0x170)]);
    }
    static async [_0xe8895e(0x167) + 'e'](_0x28a772, _0x14a8cc) {
        const _0x4dfa65 = _0xe8895e, _0x1d078d = {
                'MmTdR': _0x4dfa65(0x19b),
                'KqUWL': _0x4dfa65(0x171)
            };
        return await License[_0x4dfa65(0x18c)]({ 'status': _0x1d078d[_0x4dfa65(0x178)] }, { 'where': { 'status': _0x1d078d[_0x4dfa65(0x185)] } }), await License[_0x4dfa65(0x161)]({
            'licenseKey': _0x28a772,
            'expiresAt': _0x14a8cc,
            'status': _0x1d078d[_0x4dfa65(0x185)]
        });
    }
    static async [_0xe8895e(0x159) + _0xe8895e(0x19d)]() {
        const _0x1475e2 = _0xe8895e, _0xf8119 = {
                'gUTnZ': _0x1475e2(0x171),
                'vAJOZ': _0x1475e2(0x163) + _0x1475e2(0x15f) + _0x1475e2(0x17a)
            }, _0x3528c6 = await License[_0x1475e2(0x18b)]({ 'where': { 'status': _0xf8119[_0x1475e2(0x179)] } });
        if (!_0x3528c6)
            return {
                'isValid': ![],
                'error': _0xf8119[_0x1475e2(0x17c)]
            };
        return this[_0x1475e2(0x165) + _0x1475e2(0x15c)](_0x3528c6[_0x1475e2(0x18d)]);
    }
}
function _0x5be7(_0x406695, _0x3ab63e) {
    _0x406695 = _0x406695 - (0x2278 * -0x1 + 0x2 * -0xe0e + -0x1ff6 * -0x2);
    const _0x3cc27e = _0x35c6();
    let _0x36168c = _0x3cc27e[_0x406695];
    return _0x36168c;
}
module[_0xe8895e(0x182)] = LicenseService;