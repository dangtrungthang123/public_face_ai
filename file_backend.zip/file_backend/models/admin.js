const _0x5de88f = _0x410c;
function _0x410c(_0x39b196, _0x3e50dc) {
    _0x39b196 = _0x39b196 - (0x4 * -0x419 + 0x18d2 + -0x78f);
    const _0x4af828 = _0x51a8();
    let _0x45a9fc = _0x4af828[_0x39b196];
    return _0x45a9fc;
}
(function (_0x4df2b6, _0x1bee25) {
    const _0x31f293 = _0x410c, _0x3f882c = _0x4df2b6();
    while (!![]) {
        try {
            const _0x423acd = parseInt(_0x31f293(0xe4)) / (-0x15ab + -0x8 * 0x331 + 0x2f34) * (-parseInt(_0x31f293(0xf1)) / (0xc8d + 0x9d * -0x3a + 0x1707)) + parseInt(_0x31f293(0xed)) / (-0x2a2 * -0x1 + -0x108e + 0xdef) + parseInt(_0x31f293(0xe9)) / (-0x2 * -0x304 + -0xe5 * 0x2b + -0xd5 * -0x27) * (-parseInt(_0x31f293(0xf0)) / (0x1e5b * -0x1 + -0x1068 + 0x2ec8)) + parseInt(_0x31f293(0xe3)) / (0x6b * 0x1 + 0x5ae + 0x1 * -0x613) + parseInt(_0x31f293(0xea)) / (0x1d64 + 0x9e7 + 0x9d1 * -0x4) + -parseInt(_0x31f293(0xef)) / (0x3 * 0xb15 + -0xd4b * -0x1 + -0x2e82) + parseInt(_0x31f293(0xeb)) / (0x1253 * 0x1 + 0x65 * 0x48 + -0x1759 * 0x2);
            if (_0x423acd === _0x1bee25)
                break;
            else
                _0x3f882c['push'](_0x3f882c['shift']());
        } catch (_0x58b47b) {
            _0x3f882c['push'](_0x3f882c['shift']());
        }
    }
}(_0x51a8, 0x8355b + 0x4511 * 0x9 + -0x13cc0));
function _0x51a8() {
    const _0x2bd77f = [
        'UUID',
        '4360194zUrBgr',
        '1JayPTH',
        'database',
        'exports',
        'admins',
        'sequelize',
        '4MzsfPW',
        '1589854eVcsfn',
        '5485869TxluNv',
        '../config/',
        '1814598eRbtiv',
        'define',
        '2568096RAAtGO',
        '1543055tRzdUV',
        '1845234HEOmIf',
        'Admin',
        'admin',
        'UUIDV4',
        'STRING'
    ];
    _0x51a8 = function () {
        return _0x2bd77f;
    };
    return _0x51a8();
}
const {DataTypes} = require(_0x5de88f(0xe8)), sequelize = require(_0x5de88f(0xec) + _0x5de88f(0xe5)), Admin = sequelize[_0x5de88f(0xee)](_0x5de88f(0xf2), {
        'id': {
            'type': DataTypes[_0x5de88f(0xe2)],
            'defaultValue': DataTypes[_0x5de88f(0xe0)],
            'primaryKey': !![]
        },
        'username': {
            'type': DataTypes[_0x5de88f(0xe1)],
            'allowNull': ![],
            'unique': !![]
        },
        'password': {
            'type': DataTypes[_0x5de88f(0xe1)],
            'allowNull': ![]
        },
        'role': {
            'type': DataTypes[_0x5de88f(0xe1)],
            'defaultValue': _0x5de88f(0xdf)
        }
    }, {
        'tableName': _0x5de88f(0xe7),
        'timestamps': !![]
    });
module[_0x5de88f(0xe6)] = Admin;