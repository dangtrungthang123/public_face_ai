function _0x34ed(_0x397992, _0x59afb6) {
    _0x397992 = _0x397992 - (0x14f8 + -0x14bf * 0x1 + 0xdd);
    const _0x16b7f7 = _0xda37();
    let _0x4d81ea = _0x16b7f7[_0x397992];
    return _0x4d81ea;
}
const _0x536f4f = _0x34ed;
(function (_0x3541c5, _0x4878c3) {
    const _0x559622 = _0x34ed, _0x5ad990 = _0x3541c5();
    while (!![]) {
        try {
            const _0x12e885 = parseInt(_0x559622(0x11f)) / (0x2663 + 0x2192 * -0x1 + -0x7 * 0xb0) + parseInt(_0x559622(0x127)) / (0x1348 * 0x1 + 0x1b8c + -0x2ed2) + -parseInt(_0x559622(0x125)) / (-0x46c + 0x1 * 0x2b3 + 0x1bc) + -parseInt(_0x559622(0x11d)) / (0x101 + 0x1e15 + -0x1f12) + parseInt(_0x559622(0x123)) / (-0x115 * -0xe + -0x1 * 0x5db + -0x946) + -parseInt(_0x559622(0x122)) / (-0x7a5 + -0x2151 + 0x28fc) + parseInt(_0x559622(0x118)) / (-0x8f3 + 0x214a + 0x30a * -0x8) * (-parseInt(_0x559622(0x116)) / (-0x14e7 + 0x1b3d + -0x64e));
            if (_0x12e885 === _0x4878c3)
                break;
            else
                _0x5ad990['push'](_0x5ad990['shift']());
        } catch (_0xdf6a4a) {
            _0x5ad990['push'](_0x5ad990['shift']());
        }
    }
}(_0xda37, -0x1396 * -0x7d + 0xcf866 + -0x53 * 0x22f7));
const {DataTypes} = require(_0x536f4f(0x121)), sequelize = require(_0x536f4f(0x11e) + _0x536f4f(0x11c)), Admin = sequelize[_0x536f4f(0x119)](_0x536f4f(0x11a), {
        'id': {
            'type': DataTypes[_0x536f4f(0x117)],
            'defaultValue': DataTypes[_0x536f4f(0x11b)],
            'primaryKey': !![]
        },
        'username': {
            'type': DataTypes[_0x536f4f(0x126)],
            'allowNull': ![],
            'unique': !![]
        },
        'password': {
            'type': DataTypes[_0x536f4f(0x126)],
            'allowNull': ![]
        },
        'role': {
            'type': DataTypes[_0x536f4f(0x126)],
            'defaultValue': _0x536f4f(0x128)
        }
    }, {
        'tableName': _0x536f4f(0x124),
        'timestamps': !![]
    });
module[_0x536f4f(0x120)] = Admin;
function _0xda37() {
    const _0x4e7527 = [
        '310506wYQCPd',
        'STRING',
        '733888jKcnXW',
        'admin',
        '721592rKWMDC',
        'UUID',
        '21PqkRcl',
        'define',
        'Admin',
        'UUIDV4',
        'database',
        '2295452uTMKKH',
        '../config/',
        '1291280eLzQmi',
        'exports',
        'sequelize',
        '8413578ORJWkD',
        '7129200uVEJki',
        'admins'
    ];
    _0xda37 = function () {
        return _0x4e7527;
    };
    return _0xda37();
}