const _0x25e656 = _0x317b;
(function (_0x2800f9, _0x4bd1b6) {
    const _0x26cfde = _0x317b, _0x4e44bb = _0x2800f9();
    while (!![]) {
        try {
            const _0x25d818 = -parseInt(_0x26cfde(0xa7)) / (0xa68 + -0x26a1 + -0x2 * -0xe1d) + parseInt(_0x26cfde(0xa3)) / (-0x217a + 0x2206 + 0x8a * -0x1) * (parseInt(_0x26cfde(0xa2)) / (-0x2507 * -0x1 + -0x20ba + -0x44a)) + -parseInt(_0x26cfde(0xb8)) / (0x217f + -0x1ef3 * 0x1 + -0x288) * (-parseInt(_0x26cfde(0xaf)) / (-0x12a7 + 0x2076 + -0xdca)) + parseInt(_0x26cfde(0xae)) / (-0x25af * 0x1 + -0x6d8 + 0x1 * 0x2c8d) + parseInt(_0x26cfde(0xb2)) / (0x20db + -0xc9e + -0xd * 0x18e) * (parseInt(_0x26cfde(0xb1)) / (-0x1536 + -0x45 * 0x30 + 0x7 * 0x4e2)) + parseInt(_0x26cfde(0xa9)) / (0x1cc9 * -0x1 + -0x25f7 * -0x1 + -0x925 * 0x1) * (-parseInt(_0x26cfde(0xa4)) / (-0x1c82 + -0x2293 + -0x3f1f * -0x1)) + parseInt(_0x26cfde(0xa5)) / (-0x422 * -0x1 + 0x1 * -0x117f + 0xd68) * (-parseInt(_0x26cfde(0xb0)) / (0x1075 + 0x1 * -0x442 + -0xc27));
            if (_0x25d818 === _0x4bd1b6)
                break;
            else
                _0x4e44bb['push'](_0x4e44bb['shift']());
        } catch (_0x2744e0) {
            _0x4e44bb['push'](_0x4e44bb['shift']());
        }
    }
}(_0x2293, 0x1 * 0x3d8ab + 0x51 * 0x11 + -0x33 * 0x28f));
const {DataTypes} = require(_0x25e656(0xb6)), sequelize = require(_0x25e656(0xba) + _0x25e656(0xaa)), License = sequelize[_0x25e656(0xb7)](_0x25e656(0xb3), {
        'id': {
            'type': DataTypes[_0x25e656(0xac)],
            'defaultValue': DataTypes[_0x25e656(0xad)],
            'primaryKey': !![]
        },
        'licenseKey': {
            'type': DataTypes[_0x25e656(0xab)],
            'allowNull': ![]
        },
        'status': {
            'type': DataTypes[_0x25e656(0xa8)],
            'defaultValue': _0x25e656(0xb4)
        },
        'expiresAt': {
            'type': DataTypes[_0x25e656(0xa6)],
            'allowNull': ![]
        }
    }, {
        'tableName': _0x25e656(0xb9),
        'timestamps': !![]
    });
function _0x2293() {
    const _0x1e70b9 = [
        '../config/',
        '126915smHDhm',
        '2UDHdqd',
        '90620yULlBx',
        '11ryvEXn',
        'DATE',
        '48000PosKoW',
        'STRING',
        '432qgyYSq',
        'database',
        'TEXT',
        'UUID',
        'UUIDV4',
        '1131324HQyoTO',
        '1002860swkfPP',
        '2393244EgXtXJ',
        '8qFRseK',
        '1893199zVjjqZ',
        'License',
        'active',
        'exports',
        'sequelize',
        'define',
        '8lcSaiD',
        'licenses'
    ];
    _0x2293 = function () {
        return _0x1e70b9;
    };
    return _0x2293();
}
function _0x317b(_0x22423a, _0x2b7f6b) {
    _0x22423a = _0x22423a - (-0x148e + 0x1b3b * 0x1 + 0x5b * -0x11);
    const _0x37cecd = _0x2293();
    let _0xcba9d9 = _0x37cecd[_0x22423a];
    return _0xcba9d9;
}
module[_0x25e656(0xb5)] = License;