const _0x26a05e = _0x3307;
(function (_0x7d8a3f, _0x2b7ac3) {
    const _0x2ae706 = _0x3307, _0x1e6e7b = _0x7d8a3f();
    while (!![]) {
        try {
            const _0x549253 = parseInt(_0x2ae706(0x1b0)) / (-0x1 * 0x2293 + -0x7d * 0x3 + -0x1 * -0x240b) + parseInt(_0x2ae706(0x1a8)) / (0x1ea7 + -0x833 * 0x1 + -0x1672) + -parseInt(_0x2ae706(0x1aa)) / (0x7b7 * 0x3 + 0x534 + -0x27 * 0xba) * (parseInt(_0x2ae706(0x1b4)) / (0x20 * 0x28 + -0x27e + 0x1d * -0x16)) + parseInt(_0x2ae706(0x1b8)) / (-0x2461 + -0xfb * 0x1f + 0x42cb * 0x1) + -parseInt(_0x2ae706(0x1b3)) / (0x1408 + 0x127 * -0x15 + -0x431 * -0x1) + parseInt(_0x2ae706(0x1b9)) / (0x1674 + 0x14ac + -0x2b19) * (-parseInt(_0x2ae706(0x1b2)) / (-0x11ca + -0x822 + 0x19f4)) + parseInt(_0x2ae706(0x1b1)) / (0x1 * -0x248b + 0x51f + 0x1 * 0x1f75);
            if (_0x549253 === _0x2b7ac3)
                break;
            else
                _0x1e6e7b['push'](_0x1e6e7b['shift']());
        } catch (_0x58b56e) {
            _0x1e6e7b['push'](_0x1e6e7b['shift']());
        }
    }
}(_0x4cea, -0x3 * 0x1c5dd + -0x48907 * 0x1 + -0x1 * -0xcc45b));
const {DataTypes} = require(_0x26a05e(0x1ad)), sequelize = require(_0x26a05e(0x1b5) + _0x26a05e(0x1ab)), License = sequelize[_0x26a05e(0x1ae)](_0x26a05e(0x1a4), {
        'id': {
            'type': DataTypes[_0x26a05e(0x1ac)],
            'defaultValue': DataTypes[_0x26a05e(0x1b7)],
            'primaryKey': !![]
        },
        'licenseKey': {
            'type': DataTypes[_0x26a05e(0x1a5)],
            'allowNull': ![]
        },
        'status': {
            'type': DataTypes[_0x26a05e(0x1af)],
            'defaultValue': _0x26a05e(0x1a7)
        },
        'expiresAt': {
            'type': DataTypes[_0x26a05e(0x1a9)],
            'allowNull': ![]
        }
    }, {
        'tableName': _0x26a05e(0x1a6),
        'timestamps': !![]
    });
function _0x4cea() {
    const _0x5e003b = [
        'License',
        'TEXT',
        'licenses',
        'active',
        '381886MOYMrf',
        'DATE',
        '212379RzRorU',
        'database',
        'UUID',
        'sequelize',
        'define',
        'STRING',
        '236014qyFARZ',
        '913977ohVnga',
        '347848rqhiYt',
        '1818324fmROKb',
        '4urDCiP',
        '../config/',
        'exports',
        'UUIDV4',
        '616040CsGOEO',
        '14wbZpow'
    ];
    _0x4cea = function () {
        return _0x5e003b;
    };
    return _0x4cea();
}
function _0x3307(_0x228c15, _0x289959) {
    _0x228c15 = _0x228c15 - (-0x10d3 + 0x1 * -0x1d68 + -0x2b * -0x11d);
    const _0x42c7ca = _0x4cea();
    let _0x9a4445 = _0x42c7ca[_0x228c15];
    return _0x9a4445;
}
module[_0x26a05e(0x1b6)] = License;