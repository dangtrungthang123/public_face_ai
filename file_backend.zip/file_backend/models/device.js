const _0x1b93ab = _0x4575;
function _0x4575(_0x83fe6a, _0x61acce) {
    _0x83fe6a = _0x83fe6a - (0x22 * -0x28 + 0x91 * -0x2f + -0x1 * -0x2131);
    const _0x516cda = _0x3f34();
    let _0x2aa516 = _0x516cda[_0x83fe6a];
    return _0x2aa516;
}
(function (_0xc38a91, _0x335490) {
    const _0x40e0cd = _0x4575, _0x4f5598 = _0xc38a91();
    while (!![]) {
        try {
            const _0xebc37b = parseInt(_0x40e0cd(0x142)) / (-0x1191 + -0x1 * 0x1861 + 0x29f3 * 0x1) * (-parseInt(_0x40e0cd(0x15b)) / (0x1 * -0x207d + 0x52 * -0x45 + 0x3699)) + -parseInt(_0x40e0cd(0x158)) / (-0x2 * -0x116b + -0x17 * -0xaf + -0x328c) + -parseInt(_0x40e0cd(0x14a)) / (-0x9e2 + -0x1cde + -0x676 * -0x6) * (parseInt(_0x40e0cd(0x154)) / (-0x1757 * -0x1 + 0x4 * 0x45e + -0x28ca)) + parseInt(_0x40e0cd(0x148)) / (-0x2 * 0x1163 + -0x12 * 0xc5 + 0x30a6) * (parseInt(_0x40e0cd(0x157)) / (-0x141e + 0x2315 + -0xef0)) + -parseInt(_0x40e0cd(0x144)) / (0x132 * 0x9 + -0xc01 + 0x147) * (parseInt(_0x40e0cd(0x145)) / (-0x16a1 + -0x1011 + 0x26bb)) + parseInt(_0x40e0cd(0x152)) / (0xc9 + 0x146 * 0xf + -0x13d9 * 0x1) + -parseInt(_0x40e0cd(0x156)) / (0x1081 + -0x2f1 + -0xd85) * (-parseInt(_0x40e0cd(0x14d)) / (-0xae1 * 0x1 + -0x2267 + 0x2d54 * 0x1));
            if (_0xebc37b === _0x335490)
                break;
            else
                _0x4f5598['push'](_0x4f5598['shift']());
        } catch (_0x5d77cf) {
            _0x4f5598['push'](_0x4f5598['shift']());
        }
    }
}(_0x3f34, 0x121 * -0xc47 + -0x4 * 0x58888 + 0x313e83 * 0x1));
const {DataTypes} = require(_0x1b93ab(0x14e)), sequelize = require(_0x1b93ab(0x151) + _0x1b93ab(0x14b)), Device = sequelize[_0x1b93ab(0x149)](_0x1b93ab(0x143), {
        'sn': {
            'type': DataTypes[_0x1b93ab(0x15a)],
            'primaryKey': !![],
            'allowNull': ![]
        },
        'name': {
            'type': DataTypes[_0x1b93ab(0x15a)],
            'defaultValue': _0x1b93ab(0x159)
        },
        'status': {
            'type': DataTypes[_0x1b93ab(0x14f)](_0x1b93ab(0x155), _0x1b93ab(0x14c)),
            'defaultValue': _0x1b93ab(0x14c)
        },
        'last_seen': {
            'type': DataTypes[_0x1b93ab(0x150)],
            'defaultValue': DataTypes[_0x1b93ab(0x147)]
        },
        'ip_address': {
            'type': DataTypes[_0x1b93ab(0x15a)],
            'allowNull': !![]
        }
    }, {
        'tableName': _0x1b93ab(0x153),
        'timestamps': !![]
    });
function _0x3f34() {
    const _0x4a8fed = [
        'New\x20Device',
        'STRING',
        '61242fJWrwg',
        '6xsHIIp',
        'Device',
        '79432SshDos',
        '1251uwNywv',
        'exports',
        'NOW',
        '42qADQrR',
        'define',
        '112UttirI',
        'database',
        'offline',
        '2196756oJIqiZ',
        'sequelize',
        'ENUM',
        'DATE',
        '../config/',
        '5522080XZikfl',
        'devices',
        '16765CurUOY',
        'online',
        '99kGJahN',
        '649187VCIlXL',
        '968427PodnWl'
    ];
    _0x3f34 = function () {
        return _0x4a8fed;
    };
    return _0x3f34();
}
module[_0x1b93ab(0x146)] = Device;